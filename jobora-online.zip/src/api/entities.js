import { base44 } from './base44Client';


export const Job = base44.entities.Job;

export const Application = base44.entities.Application;

export const Subscription = base44.entities.Subscription;

export const EasyApplication = base44.entities.EasyApplication;

export const Message = base44.entities.Message;

export const Notification = base44.entities.Notification;

export const EmployerBadge = base44.entities.EmployerBadge;



// auth sdk:
export const User = base44.auth;