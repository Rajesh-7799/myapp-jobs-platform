import { base44 } from './base44Client';


export const fetchExternalJobs = base44.functions.fetchExternalJobs;

export const fetchMultipleJobSources = base44.functions.fetchMultipleJobSources;

