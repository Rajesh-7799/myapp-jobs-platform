import React from 'react';
import { Sparkles, Search, HelpCircle, Briefcase } from 'lucide-react';

const prompts = [
    {
        icon: Search,
        text: 'Find remote Senior React Developer jobs in the US',
    },
    {
        icon: HelpCircle,
        text: 'Give me 5 interview questions for a Product Manager role',
    },
    {
        icon: Briefcase,
        text: 'What is the status of my application to Google?',
    },
    {
        icon: Sparkles,
        text: 'Help me write a follow-up email after an interview',
    },
];

export default function ExamplePrompts({ onPromptClick }) {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg mb-4">
                <Sparkles className="w-10 h-10 text-white"/>
            </div>
            <h1 className="text-2xl font-bold text-gray-800">JOBORA AI Assistant</h1>
            <p className="text-gray-500 mb-8">Your personal career co-pilot</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl">
                {prompts.map((prompt, index) => (
                    <button
                        key={index}
                        onClick={() => onPromptClick(prompt.text)}
                        className="p-4 border rounded-lg text-left hover:bg-gray-50 transition-colors flex items-start gap-3"
                    >
                        <prompt.icon className="w-4 h-4 text-gray-400 mt-1 flex-shrink-0" />
                        <span className="text-sm font-medium text-gray-700">{prompt.text}</span>
                    </button>
                ))}
            </div>
        </div>
    );
}