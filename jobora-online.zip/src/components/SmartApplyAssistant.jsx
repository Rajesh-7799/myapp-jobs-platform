import React, { useState } from 'react';
import { EasyApplication } from '@/api/entities';
import { User } from '@/api/entities';
import { Message } from '@/api/entities';
import { Notification } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Send, Zap, CheckCircle, AlertCircle, MessageSquare } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { InvokeLLM } from '@/api/integrations';

export default function SmartApplyAssistant({ job, onSuccess, onCancel }) {
    const [currentUser, setCurrentUser] = useState(null);
    const [applicationData, setApplicationData] = useState({
        cover_letter: '',
        message_to_employer: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const [isGeneratingCover, setIsGeneratingCover] = useState(false);
    const [step, setStep] = useState('form'); // 'form', 'success'

    React.useEffect(() => {
        loadUserData();
    }, []);

    const loadUserData = async () => {
        try {
            const user = await User.me();
            setCurrentUser(user);
        } catch (error) {
            console.error("Error loading user data:", error);
        }
    };

    const generateCoverLetter = async () => {
        if (!currentUser) return;
        
        setIsGeneratingCover(true);
        try {
            const prompt = `Generate a professional cover letter for this job application:

Job Details:
- Title: ${job.title}
- Company: ${job.company}
- Location: ${job.location}
- Description: ${job.description}
- Requirements: ${job.requirements || 'Not specified'}

Applicant Profile:
- Name: ${currentUser.full_name}
- Skills: ${currentUser.skills?.join(', ') || 'Not specified'}
- Experience: ${currentUser.experience_years || 'Not specified'} years
- Bio: ${currentUser.bio || 'Not specified'}

Please write a compelling, personalized cover letter that:
1. Shows enthusiasm for the role and company
2. Highlights relevant skills and experience
3. Demonstrates knowledge of the company/role
4. Is professional but engaging
5. Ends with a strong call to action

Keep it concise (3-4 paragraphs) and avoid generic phrases.`;

            const coverLetter = await InvokeLLM({ prompt });
            setApplicationData(prev => ({ ...prev, cover_letter: coverLetter }));
            toast.success("Cover letter generated!");
        } catch (error) {
            console.error("Error generating cover letter:", error);
            toast.error("Failed to generate cover letter");
        } finally {
            setIsGeneratingCover(false);
        }
    };

    const handleSubmitApplication = async () => {
        if (!currentUser) {
            toast.error("User data not loaded");
            return;
        }

        setIsLoading(true);
        try {
            // Create easy application
            const applicationPayload = {
                job_id: job.id,
                job_title: job.title,
                company: job.company,
                applicant_name: currentUser.full_name,
                applicant_email: currentUser.email,
                applicant_phone: currentUser.phone || '',
                resume_url: currentUser.resume_url || '',
                cover_letter: applicationData.cover_letter,
                portfolio_url: currentUser.portfolio_url || '',
                linkedin_url: currentUser.linkedin_url || '',
                skills: currentUser.skills || [],
                experience_years: currentUser.experience_years || 0,
                application_date: new Date().toISOString()
            };

            await EasyApplication.create(applicationPayload);

            // Send message to employer if provided
            if (applicationData.message_to_employer.trim()) {
                const messagePayload = {
                    sender_email: currentUser.email,
                    receiver_email: job.created_by,
                    subject: `Application for ${job.title}`,
                    content: applicationData.message_to_employer,
                    sender_name: currentUser.full_name,
                    sender_type: 'seeker',
                    job_id: job.id,
                    job_title: job.title,
                    message_type: 'job_inquiry'
                };

                await Message.create(messagePayload);
            }

            // Create notification for employer
            try {
                await Notification.create({
                    user_email: job.created_by,
                    title: 'New Job Application',
                    message: `${currentUser.full_name} applied for ${job.title}`,
                    type: 'new_application',
                    related_job_id: job.id,
                    action_url: '/applicants'
                });
            } catch (notifError) {
                console.log("Notification creation failed (non-critical):", notifError);
            }

            setStep('success');
            toast.success("Application submitted successfully!");

        } catch (error) {
            console.error("Error submitting application:", error);
            toast.error("Failed to submit application");
        } finally {
            setIsLoading(false);
        }
    };

    if (step === 'success') {
        return (
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center p-8"
            >
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Application Submitted!</h2>
                <p className="text-gray-600 mb-6">
                    Your application for <strong>{job.title}</strong> at <strong>{job.company}</strong> has been sent successfully.
                </p>
                <div className="space-y-3">
                    <p className="text-sm text-gray-500">What happens next:</p>
                    <div className="bg-blue-50 p-4 rounded-lg text-left">
                        <ul className="text-sm text-gray-700 space-y-1">
                            <li>• The employer will be notified of your application</li>
                            <li>• You can track your application status in your profile</li>
                            <li>• The employer may contact you directly for next steps</li>
                        </ul>
                    </div>
                </div>
                <Button onClick={onSuccess} className="mt-6">
                    Continue Browsing Jobs
                </Button>
            </motion.div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Zap className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Apply to {job.company}</h2>
                <p className="text-gray-600">
                    We'll use your profile information to submit your application instantly
                </p>
            </div>

            {/* Application Preview */}
            <Card>
                <CardHeader>
                    <CardTitle className="text-lg">Application Preview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <p className="font-medium text-gray-700">Name:</p>
                            <p>{currentUser?.full_name || 'Loading...'}</p>
                        </div>
                        <div>
                            <p className="font-medium text-gray-700">Email:</p>
                            <p>{currentUser?.email || 'Loading...'}</p>
                        </div>
                        <div>
                            <p className="font-medium text-gray-700">Phone:</p>
                            <p>{currentUser?.phone || 'Not provided'}</p>
                        </div>
                        <div>
                            <p className="font-medium text-gray-700">Experience:</p>
                            <p>{currentUser?.experience_years ? `${currentUser.experience_years} years` : 'Not specified'}</p>
                        </div>
                    </div>
                    
                    {currentUser?.skills && currentUser.skills.length > 0 && (
                        <div>
                            <p className="font-medium text-gray-700 mb-2">Skills:</p>
                            <div className="flex flex-wrap gap-2">
                                {currentUser.skills.slice(0, 5).map((skill, index) => (
                                    <Badge key={index} variant="outline">{skill}</Badge>
                                ))}
                                {currentUser.skills.length > 5 && (
                                    <Badge variant="outline">+{currentUser.skills.length - 5} more</Badge>
                                )}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            {/* Cover Letter */}
            <Card>
                <CardHeader>
                    <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">Cover Letter</CardTitle>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={generateCoverLetter}
                            disabled={isGeneratingCover}
                        >
                            {isGeneratingCover ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating...</>
                            ) : (
                                <><Zap className="w-4 h-4 mr-2" /> AI Generate</>
                            )}
                        </Button>
                    </div>
                </CardHeader>
                <CardContent>
                    <Textarea
                        placeholder="Write a cover letter or use AI to generate one..."
                        value={applicationData.cover_letter}
                        onChange={(e) => setApplicationData(prev => ({ ...prev, cover_letter: e.target.value }))}
                        rows={8}
                        className="w-full"
                    />
                </CardContent>
            </Card>

            {/* Message to Employer */}
            <Card>
                <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                        <MessageSquare className="w-5 h-5" />
                        Message to Employer (Optional)
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Textarea
                        placeholder="Send a direct message to the employer..."
                        value={applicationData.message_to_employer}
                        onChange={(e) => setApplicationData(prev => ({ ...prev, message_to_employer: e.target.value }))}
                        rows={4}
                        className="w-full"
                    />
                    <p className="text-sm text-gray-500 mt-2">
                        This message will be sent directly to the employer along with your application.
                    </p>
                </CardContent>
            </Card>

            {/* Submit Button */}
            <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={onCancel}>
                    Cancel
                </Button>
                <Button 
                    onClick={handleSubmitApplication} 
                    disabled={isLoading}
                    className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                >
                    {isLoading ? (
                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</>
                    ) : (
                        <><Send className="w-4 h-4 mr-2" /> Submit Application</>
                    )}
                </Button>
            </div>
        </div>
    );
}