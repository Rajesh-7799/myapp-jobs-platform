import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Phone, Mail, MapPin, Building, Crown, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function DirectRecruiterJobs({ jobs, onJobSelect }) {
    const directContactJobs = jobs.filter(job => job.has_direct_contact);

    if (directContactJobs.length === 0) return null;

    return (
        <Card className="mb-6 border-gold-200 bg-gradient-to-r from-yellow-50 to-amber-50">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-yellow-600" />
                    Direct Recruiter Jobs ({directContactJobs.length})
                </CardTitle>
                <p className="text-sm text-gray-600">
                    Jobs with direct recruiter contact - Higher response rates!
                </p>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <AnimatePresence>
                        {directContactJobs.slice(0, 6).map((job) => (
                            <motion.div
                                key={job.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={{ opacity: 0, y: -20 }}
                                className="border border-yellow-200 rounded-lg p-4 bg-white/80 hover:bg-white cursor-pointer transition-all"
                                onClick={() => onJobSelect(job)}
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex-1">
                                        <h3 className="font-semibold text-sm">{job.title}</h3>
                                        <p className="text-xs text-gray-600">{job.company}</p>
                                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-1">
                                            <MapPin className="w-3 h-3" />
                                            {job.location}
                                        </p>
                                    </div>
                                    <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                                        Direct Contact
                                    </Badge>
                                </div>
                                
                                <div className="space-y-1 mb-3">
                                    {job.recruiter_name && (
                                        <p className="text-xs font-medium text-gray-700">
                                            {job.recruiter_name}
                                        </p>
                                    )}
                                    {job.recruiter_email && (
                                        <div className="flex items-center gap-1 text-xs text-blue-600">
                                            <Mail className="w-3 h-3" />
                                            <span className="truncate">{job.recruiter_email}</span>
                                        </div>
                                    )}
                                    {job.recruiter_phone && (
                                        <div className="flex items-center gap-1 text-xs text-green-600">
                                            <Phone className="w-3 h-3" />
                                            <span>{job.recruiter_phone}</span>
                                        </div>
                                    )}
                                </div>

                                <div className="flex justify-between items-center">
                                    {job.job_type && (
                                        <Badge variant="outline" className="text-xs">
                                            {job.job_type}
                                        </Badge>
                                    )}
                                    <Button size="sm" variant="ghost" className="text-xs" asChild>
                                        <a href={job.url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
                                            <ExternalLink className="w-3 h-3" />
                                        </a>
                                    </Button>
                                </div>
                            </motion.div>
                        ))}
                    </AnimatePresence>
                </div>
                
                {directContactJobs.length > 6 && (
                    <div className="text-center mt-4">
                        <Button variant="outline" size="sm">
                            View All {directContactJobs.length} Direct Contact Jobs
                        </Button>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}