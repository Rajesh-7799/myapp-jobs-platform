import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Sparkles, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function SearchSuggestions({ 
    suggestions = [], 
    recentSearches = [], 
    onSuggestionClick, 
    onRecentSearchClick 
}) {
    return (
        <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-4 bg-gray-50 rounded-lg border"
        >
            {/* Recent Searches */}
            {recentSearches.length > 0 && (
                <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                        <Clock className="w-4 h-4 text-gray-500" />
                        <span className="text-sm font-medium text-gray-700">Recent Searches</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {recentSearches.slice(0, 3).map((search, index) => (
                            <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className="h-7 text-xs hover:bg-blue-50 hover:border-blue-300"
                                onClick={() => onRecentSearchClick(search)}
                            >
                                {search.role && search.location 
                                    ? `${search.role} in ${search.location}`
                                    : search.role || search.location
                                }
                            </Button>
                        ))}
                    </div>
                </div>
            )}

            {/* Search Suggestions */}
            {suggestions.length > 0 && (
                <div>
                    <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-purple-500" />
                        <span className="text-sm font-medium text-gray-700">
                            Suggested for You
                        </span>
                        <Badge variant="secondary" className="text-xs">
                            Based on your profile
                        </Badge>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {suggestions.slice(0, 6).map((suggestion, index) => (
                            <Button
                                key={index}
                                variant="ghost"
                                size="sm"
                                className="h-7 text-xs hover:bg-purple-50 hover:text-purple-700"
                                onClick={() => onSuggestionClick(suggestion)}
                            >
                                <TrendingUp className="w-3 h-3 mr-1" />
                                {suggestion}
                            </Button>
                        ))}
                    </div>
                </div>
            )}

            {/* Popular Searches */}
            <div className="mt-4 pt-3 border-t border-gray-200">
                <span className="text-xs text-gray-500 mb-2 block">Popular searches</span>
                <div className="flex flex-wrap gap-2">
                    {['Software Engineer', 'Product Manager', 'Data Scientist', 'UX Designer'].map((popular, index) => (
                        <Button
                            key={index}
                            variant="ghost"
                            size="sm"
                            className="h-6 text-xs text-gray-600 hover:bg-gray-100"
                            onClick={() => onSuggestionClick(popular)}
                        >
                            {popular}
                        </Button>
                    ))}
                </div>
            </div>
        </motion.div>
    );
}