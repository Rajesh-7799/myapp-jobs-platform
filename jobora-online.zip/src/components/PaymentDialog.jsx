import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
    CreditCard, Smartphone, Building2, Loader2, Crown, Check, 
    CheckCircle, ShieldCheck, AlertCircle, Wallet, Apple
} from 'lucide-react';
import { Subscription } from '@/api/entities';
import { User } from '@/api/entities';
import { cn } from "@/lib/utils";

// Card validation utilities
const validateCardNumber = (number) => {
    const cleaned = number.replace(/\s+/g, '');
    if (!/^\d{13,19}$/.test(cleaned)) return false;
    
    // Luhn algorithm
    let sum = 0;
    let alternate = false;
    for (let i = cleaned.length - 1; i >= 0; i--) {
        let n = parseInt(cleaned.charAt(i), 10);
        if (alternate) {
            n *= 2;
            if (n > 9) n = (n % 10) + 1;
        }
        sum += n;
        alternate = !alternate;
    }
    return sum % 10 === 0;
};

const validateExpiry = (expiry) => {
    const match = expiry.match(/^(\d{2})\/(\d{2})$/);
    if (!match) return false;
    
    const month = parseInt(match[1], 10);
    const year = parseInt(`20${match[2]}`, 10);
    const now = new Date();
    const expDate = new Date(year, month - 1);
    
    return month >= 1 && month <= 12 && expDate > now;
};

const validateCVC = (cvc) => /^\d{3,4}$/.test(cvc);

const formatCardNumber = (value) => {
    return value.replace(/\s+/g, '').replace(/(\d{4})/g, '$1 ').trim();
};

const formatExpiry = (value) => {
    return value.replace(/\D/g, '').replace(/(\d{2})(\d)/, '$1/$2');
};

const getCardType = (number) => {
    const cleaned = number.replace(/\s+/g, '');
    if (/^4/.test(cleaned)) return 'visa';
    if (/^5[1-5]/.test(cleaned)) return 'mastercard';
    if (/^3[47]/.test(cleaned)) return 'amex';
    return 'card';
};

export default function PaymentDialog({ isOpen, onClose, pricing, currentUser }) {
    const [paymentStatus, setPaymentStatus] = useState('idle');
    const [selectedPlan, setSelectedPlan] = useState('monthly');
    const [selectedPaymentMethod, setSelectedPaymentMethod] = useState('card');
    const [cardDetails, setCardDetails] = useState({
        number: '',
        expiry: '',
        cvc: '',
        name: ''
    });
    const [validationErrors, setValidationErrors] = useState({});

    const planDetails = {
        weekly: { label: 'Weekly', per: '/week', save: null },
        monthly: { label: 'Monthly', per: '/month', save: 'Save 15%' },
        yearly: { label: 'Yearly', per: '/year', save: 'Best Value - Save 30%' },
    };

    const paymentMethods = [
        { id: 'card', name: 'Credit/Debit Card', icon: CreditCard, description: 'Visa, Mastercard, Amex' },
        { id: 'paypal', name: 'PayPal', icon: Wallet, description: 'Pay with your PayPal account' },
        { id: 'apple', name: 'Apple Pay', icon: Apple, description: 'Touch ID or Face ID' },
        { id: 'google', name: 'Google Pay', icon: Smartphone, description: 'Quick & secure' },
    ];

    const validateForm = () => {
        const errors = {};
        
        if (selectedPaymentMethod === 'card') {
            if (!cardDetails.name.trim()) {
                errors.name = 'Cardholder name is required';
            }
            
            if (!validateCardNumber(cardDetails.number)) {
                errors.number = 'Please enter a valid card number';
            }
            
            if (!validateExpiry(cardDetails.expiry)) {
                errors.expiry = 'Please enter a valid expiry date (MM/YY)';
            }
            
            if (!validateCVC(cardDetails.cvc)) {
                errors.cvc = 'Please enter a valid CVC';
            }
        }
        
        setValidationErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handleCardInputChange = (field, value) => {
        let formattedValue = value;
        
        if (field === 'number') {
            formattedValue = formatCardNumber(value);
        } else if (field === 'expiry') {
            formattedValue = formatExpiry(value);
        } else if (field === 'cvc') {
            formattedValue = value.replace(/\D/g, '').slice(0, 4);
        }
        
        setCardDetails(prev => ({
            ...prev,
            [field]: formattedValue
        }));
        
        // Clear validation error for this field
        if (validationErrors[field]) {
            setValidationErrors(prev => ({
                ...prev,
                [field]: undefined
            }));
        }
    };

    const handlePayment = async () => {
        if (!validateForm()) {
            return;
        }
        
        setPaymentStatus('processing');
        
        // Simulate payment processing
        setTimeout(async () => {
            try {
                const startDate = new Date();
                let endDate = new Date();
                
                switch (selectedPlan) {
                    case 'weekly':
                        endDate.setDate(startDate.getDate() + 7 + 2); 
                        break;
                    case 'yearly':
                        endDate.setFullYear(startDate.getFullYear() + 1);
                        endDate.setDate(endDate.getDate() + 2);
                        break;
                    default:
                        endDate.setMonth(startDate.getMonth() + 1);
                        endDate.setDate(endDate.getDate() + 2);
                        break;
                }
                
                const finalPrice = pricing.isFirstTime ? Math.round(pricing.plans[selectedPlan] * 0.8) : pricing.plans[selectedPlan];

                await Subscription.create({
                    plan_name: 'premium',
                    billing_cycle: selectedPlan,
                    price: finalPrice,
                    currency: pricing.symbol,
                    status: 'trial',
                    start_date: startDate.toISOString().split('T')[0],
                    end_date: endDate.toISOString().split('T')[0],
                });
                
                if (pricing.isFirstTime) {
                    await User.updateMyUserData({ has_subscribed_before: true });
                }
                
                setPaymentStatus('success');

            } catch (error) {
                console.error("Payment failed:", error);
                setPaymentStatus('error');
            }
        }, 2000);
    };

    const isProcessing = paymentStatus === 'processing';
    const finalPrice = pricing.isFirstTime ? Math.round(pricing.plans[selectedPlan] * 0.8) : pricing.plans[selectedPlan];
    const cardType = getCardType(cardDetails.number);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
                {paymentStatus === 'success' ? (
                    <div className="text-center p-6 flex flex-col items-center">
                        <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
                        <DialogTitle className="text-2xl font-bold mb-2">Welcome to Premium!</DialogTitle>
                        <DialogDescription className="text-base text-gray-600 mb-6">
                            You get full access to a new world of opportunities. Your 2-day free trial is now active.
                        </DialogDescription>
                        <Button onClick={() => window.location.reload()} className="w-full bg-green-600 hover:bg-green-700">
                            Start Exploring
                        </Button>
                    </div>
                ) : (
                    <>
                        <DialogHeader>
                            <DialogTitle className="flex items-center gap-2">
                                <Crown className="w-5 h-5 text-purple-600" />
                                Upgrade to Premium
                            </DialogTitle>
                            <DialogDescription>
                                Select a plan and payment method to start your 2-day free trial. Cancel anytime.
                            </DialogDescription>
                        </DialogHeader>

                        {paymentStatus === 'error' && (
                            <Alert variant="destructive">
                                <AlertCircle className="h-4 w-4" />
                                <AlertDescription>
                                    Payment failed. Please check your details and try again.
                                </AlertDescription>
                            </Alert>
                        )}

                        <div className="space-y-6">
                            {/* Plan Selection */}
                            <div>
                                <h4 className="text-sm font-medium mb-3">Choose your plan</h4>
                                <div className="grid grid-cols-3 gap-3">
                                    {Object.keys(planDetails).map((plan) => (
                                        <button
                                            key={plan}
                                            onClick={() => setSelectedPlan(plan)}
                                            className={cn(
                                                "p-4 border rounded-lg text-center transition-all",
                                                selectedPlan === plan ? "bg-blue-100 border-blue-400 ring-2 ring-blue-300" : "bg-gray-50 hover:bg-gray-100"
                                            )}
                                        >
                                            <p className="font-semibold text-sm">{planDetails[plan].label}</p>
                                            <p className="text-lg font-bold">{pricing.symbol}{pricing.plans[plan]}</p>
                                            <p className="text-xs text-gray-500">{planDetails[plan].per}</p>
                                            {planDetails[plan].save && <Badge variant="destructive" className="mt-2 text-xs">{planDetails[plan].save}</Badge>}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            {/* Payment Method Selection */}
                            <div>
                                <h4 className="text-sm font-medium mb-3">Payment method</h4>
                                <div className="grid grid-cols-2 gap-3">
                                    {paymentMethods.map((method) => (
                                        <button
                                            key={method.id}
                                            onClick={() => setSelectedPaymentMethod(method.id)}
                                            className={cn(
                                                "p-3 border rounded-lg text-left transition-all flex items-center gap-3",
                                                selectedPaymentMethod === method.id ? "bg-blue-100 border-blue-400 ring-2 ring-blue-300" : "bg-gray-50 hover:bg-gray-100"
                                            )}
                                        >
                                            <method.icon className="w-5 h-5" />
                                            <div>
                                                <p className="font-semibold text-sm">{method.name}</p>
                                                <p className="text-xs text-gray-500">{method.description}</p>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                            
                            {/* Card Details Form */}
                            {selectedPaymentMethod === 'card' && (
                                <div>
                                    <h4 className="text-sm font-medium mb-3">Card details</h4>
                                    <div className="space-y-4 p-4 border rounded-lg bg-gray-50">
                                        <div>
                                            <div className="relative">
                                                <Input 
                                                    placeholder="1234 5678 9012 3456" 
                                                    value={cardDetails.number} 
                                                    onChange={(e) => handleCardInputChange('number', e.target.value)}
                                                    maxLength={19}
                                                    className={validationErrors.number ? 'border-red-500' : ''}
                                                />
                                                {cardType && (
                                                    <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                                        <CreditCard className="w-5 h-5 text-gray-400" />
                                                    </div>
                                                )}
                                            </div>
                                            {validationErrors.number && (
                                                <p className="text-red-500 text-xs mt-1">{validationErrors.number}</p>
                                            )}
                                        </div>
                                        
                                        <div className="flex gap-3">
                                            <div className="flex-1">
                                                <Input 
                                                    placeholder="MM/YY" 
                                                    value={cardDetails.expiry} 
                                                    onChange={(e) => handleCardInputChange('expiry', e.target.value)}
                                                    maxLength={5}
                                                    className={validationErrors.expiry ? 'border-red-500' : ''}
                                                />
                                                {validationErrors.expiry && (
                                                    <p className="text-red-500 text-xs mt-1">{validationErrors.expiry}</p>
                                                )}
                                            </div>
                                            <div className="flex-1">
                                                <Input 
                                                    placeholder="CVC" 
                                                    value={cardDetails.cvc} 
                                                    onChange={(e) => handleCardInputChange('cvc', e.target.value)}
                                                    maxLength={4}
                                                    className={validationErrors.cvc ? 'border-red-500' : ''}
                                                />
                                                {validationErrors.cvc && (
                                                    <p className="text-red-500 text-xs mt-1">{validationErrors.cvc}</p>
                                                )}
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <Input 
                                                placeholder="John Doe" 
                                                value={cardDetails.name} 
                                                onChange={(e) => handleCardInputChange('name', e.target.value)}
                                                className={validationErrors.name ? 'border-red-500' : ''}
                                            />
                                            {validationErrors.name && (
                                                <p className="text-red-500 text-xs mt-1">{validationErrors.name}</p>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Other Payment Methods */}
                            {selectedPaymentMethod !== 'card' && (
                                <div className="p-6 border rounded-lg bg-blue-50 text-center">
                                    <div className="mb-4">
                                        {paymentMethods.find(m => m.id === selectedPaymentMethod)?.icon && 
                                            React.createElement(paymentMethods.find(m => m.id === selectedPaymentMethod).icon, { className: "w-12 h-12 mx-auto text-blue-600 mb-2" })
                                        }
                                    </div>
                                    <p className="text-sm text-gray-600">
                                        You'll be redirected to {paymentMethods.find(m => m.id === selectedPaymentMethod)?.name} to complete your payment securely.
                                    </p>
                                </div>
                            )}
                        </div>

                        <div className="flex gap-3 pt-6 border-t">
                            <Button variant="outline" onClick={onClose} className="flex-1" disabled={isProcessing}>
                                Cancel
                            </Button>
                            <Button 
                                onClick={handlePayment}
                                disabled={isProcessing}
                                className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                            >
                                {isProcessing ? (
                                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Processing...</>
                                ) : (
                                    `Start Trial & Pay ${pricing.symbol}${finalPrice}`
                                )}
                            </Button>
                        </div>
                        
                        <div className="flex items-center justify-center gap-2 text-xs text-gray-500 text-center">
                            <ShieldCheck className="w-4 h-4" />
                            <span>Secure payment • Auto-renewal • Cancel anytime</span>
                        </div>
                    </>
                )}
            </DialogContent>
        </Dialog>
    );
}