import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Filter, Sparkles } from 'lucide-react';
import { SheetFooter } from '@/components/ui/sheet';

export default function JobFilters({ initialFilters, onApplyFilters, isSubscribed = false }) {
    const defaultFilters = {
        job_type: 'all',
        experience_level: 'all',
        salary_min: '',
        salary_max: '',
        remote_work: 'all',
        company_size: 'all',
        industry: 'all',
        posted_within: 'all'
    };

    const [localFilters, setLocalFilters] = useState(initialFilters || defaultFilters);

    const updateFilter = (key, value) => {
        setLocalFilters(prev => ({ ...prev, [key]: value }));
    };

    const resetFilters = () => {
        setLocalFilters(defaultFilters);
    };
    
    const handleApply = () => {
        onApplyFilters(localFilters);
    };

    const jobTypes = [
        { value: 'all', label: 'All Types' },
        { value: 'Full-time', label: 'Full-time' },
        { value: 'Part-time', label: 'Part-time' },
        { value: 'Contract', label: 'Contract' },
        { value: 'Third-party', label: 'Third-party' },
        { value: 'Internship', label: 'Internship' }
    ];

    const experienceLevels = [
        { value: 'all', label: 'All Levels' },
        { value: 'entry', label: 'Entry Level' },
        { value: 'mid', label: 'Mid Level' },
        { value: 'senior', label: 'Senior Level' },
        { value: 'executive', label: 'Executive' }
    ];

    const remoteOptions = [
        { value: 'all', label: 'All Work Types' },
        { value: 'remote', label: 'Remote Only' },
        { value: 'hybrid', label: 'Hybrid' },
        { value: 'onsite', label: 'On-site Only' }
    ];
    
    const postedWithin = [
        { value: 'all', label: 'All Time' },
        { value: '1', label: 'Past 24 hours' },
        { value: '3', label: 'Past 3 days' },
        { value: '7', label: 'Past week' },
        { value: '30', label: 'Past month' }
    ];
    
    const premiumCompanySizes = [
        { value: 'all', label: 'All Sizes' },
        { value: 'startup', label: 'Startup (1-50)' },
        { value: 'small', label: 'Small (51-200)' },
        { value: 'medium', label: 'Medium (201-1K)' },
        { value: 'large', label: 'Large (1K+)' }
    ];

    const premiumIndustries = [
        { value: 'all', label: 'All Industries' },
        { value: 'technology', label: 'Technology' },
        { value: 'healthcare', label: 'Healthcare' },
        { value: 'finance', label: 'Finance' },
        { value: 'education', label: 'Education' }
    ];


    return (
        <div className="flex flex-col h-full">
            <div className="flex-1 space-y-6 py-4 overflow-y-auto">
                <div>
                    <label className="text-sm font-medium">Job Type</label>
                    <Select value={localFilters.job_type} onValueChange={(v) => updateFilter('job_type', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {jobTypes.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <label className="text-sm font-medium">Experience Level</label>
                    <Select value={localFilters.experience_level} onValueChange={(v) => updateFilter('experience_level', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {experienceLevels.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <label className="text-sm font-medium">Date Posted</label>
                    <Select value={localFilters.posted_within} onValueChange={(v) => updateFilter('posted_within', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {postedWithin.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>
                <div>
                    <label className="text-sm font-medium">Work Setting</label>
                    <Select value={localFilters.remote_work} onValueChange={(v) => updateFilter('remote_work', v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                            {remoteOptions.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                        </SelectContent>
                    </Select>
                </div>

                <div className={`space-y-6 transition-opacity ${!isSubscribed ? 'opacity-50' : ''}`}>
                    <div className="relative">
                        {!isSubscribed && (
                            <div className="absolute inset-0 bg-white/50 dark:bg-gray-800/50 flex items-center justify-center z-10">
                                <Sparkles className="w-5 h-5 text-purple-500" />
                            </div>
                        )}
                         <div>
                            <label className="text-sm font-medium">Salary Range ($)</label>
                            <div className="grid grid-cols-2 gap-2">
                                <Input type="number" placeholder="Min" value={localFilters.salary_min} onChange={(e) => updateFilter('salary_min', e.target.value)} disabled={!isSubscribed} />
                                <Input type="number" placeholder="Max" value={localFilters.salary_max} onChange={(e) => updateFilter('salary_max', e.target.value)} disabled={!isSubscribed} />
                            </div>
                        </div>
                    </div>
                     <div className="relative">
                        {!isSubscribed && (
                            <div className="absolute inset-0 bg-white/50 dark:bg-gray-800/50 z-10"></div>
                        )}
                        <div>
                            <label className="text-sm font-medium">Company Size</label>
                            <Select value={localFilters.company_size} onValueChange={(v) => updateFilter('company_size', v)} disabled={!isSubscribed}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {premiumCompanySizes.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <div className="relative">
                        {!isSubscribed && (
                            <div className="absolute inset-0 bg-white/50 dark:bg-gray-800/50 z-10"></div>
                        )}
                        <div>
                            <label className="text-sm font-medium">Industry</label>
                            <Select value={localFilters.industry} onValueChange={(v) => updateFilter('industry', v)} disabled={!isSubscribed}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {premiumIndustries.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </div>
            </div>

            <SheetFooter>
                <Button variant="ghost" onClick={resetFilters}>Reset</Button>
                <Button onClick={handleApply} className="w-full">Apply Filters</Button>
            </SheetFooter>
        </div>
    );
}