import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Crown } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function UpgradePrompt({ featureName, description }) {
    return (
        <div className="flex-1 flex items-center justify-center h-full p-4">
            <Card className="w-full max-w-lg text-center bg-gradient-to-br from-purple-50 via-white to-blue-50">
                <CardHeader>
                    <div className="mx-auto w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg mb-4">
                        <Crown className="w-7 h-7 text-white" />
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900">Unlock {featureName}</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-600 mb-6">{description}</p>
                    <Button asChild className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                        <Link to={createPageUrl('Profile') + '#subscription'}>
                            <Sparkles className="w-4 h-4 mr-2" />
                            Upgrade to Premium
                        </Link>
                    </Button>
                </CardContent>
            </Card>
        </div>
    );
}