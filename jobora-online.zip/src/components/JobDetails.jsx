
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, MapPin, Building, Sparkles, Loader2, Target, Zap, Crown, Mail, Phone } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { InvokeLLM } from '@/api/integrations';
import ReactMarkdown from 'react-markdown';
import SmartApplyAssistant from './SmartApplyAssistant';
import AIResumeOptimizer from './AIResumeOptimizer';
import { Application } from '@/api/entities';
import { toast } from "sonner";


const AIHelperContent = ({ job, currentUser }) => {
    const [assistantContent, setAssistantContent] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    const generateContent = async () => {
        setIsGenerating(true);
        setAssistantContent('');
        try {
            const result = await InvokeLLM({
                prompt: `You are an expert career coach. A user is applying for the following job.
                Job Title: ${job.title}
                Company: ${job.company}
                Description: ${job.description}
                
                Using the provided resume, generate a tailored application assistance document in Markdown format. Include these sections:
                1.  **Cover Letter Draft:** A concise, professional cover letter draft. Address it to "Hiring Manager".
                2.  **Resume Keywords:** A list of 5-7 keywords from the job description that the applicant should ensure are on their resume.
                3.  **Potential Interview Questions:** A list of 3-4 insightful questions based on the role and company.`,
                file_urls: currentUser?.resume_url ? [currentUser.resume_url] : [], // Only send if resume_url exists
            });
            setAssistantContent(result);
        } catch (error) {
            console.error("Error generating AI content:", error);
            setAssistantContent("Sorry, I couldn't generate assistance for this job. Please try again.");
        } finally {
            setIsGenerating(false);
        }
    };
    
    useEffect(() => {
        if (job && currentUser?.resume_url) { // Ensure job is also available
            generateContent();
        }
    }, [job, currentUser]); // Dependency array should include job and currentUser

    return (
        <div className="max-h-[70vh] overflow-y-auto p-1">
            {isGenerating && (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                    <Loader2 className="w-8 h-8 mb-4 animate-spin text-blue-500" />
                    <p className="font-medium">AI is crafting your application materials...</p>
                    <p className="text-sm text-gray-500">This may take a moment.</p>
                </div>
            )}
            {assistantContent && (
                <div className="prose prose-sm max-w-none">
                    <ReactMarkdown>{assistantContent}</ReactMarkdown>
                </div>
            )}
            {!isGenerating && !assistantContent && !currentUser?.resume_url && (
                <div className="text-center p-8 text-gray-500">
                    Please upload your resume in your <Link to={createPageUrl('Profile')} className="text-blue-500 hover:underline">Profile</Link> to use the AI Application Helper.
                </div>
            )}
            {!isGenerating && !assistantContent && currentUser?.resume_url && (
                 <div className="text-center p-8 text-gray-500">
                    No content generated. Please try again or ensure the job description is sufficient.
                </div>
            )}
        </div>
    );
};


export default function JobDetails({ job, isLoading, currentUser, isSubscribed }) {
    const [showSmartApply, setShowSmartApply] = useState(false);
    const [showAIOptimizer, setShowAIOptimizer] = useState(false);

    const handleApplyAndTrack = async () => {
        if (!job || !currentUser) return;

        try {
            const existingApplications = await Application.filter({
                job_url: job.url,
                created_by: currentUser.email,
            });

            if (existingApplications.length === 0) {
                 await Application.create({
                    job_title: job.title,
                    company: job.company,
                    job_url: job.url,
                    application_date: new Date().toISOString().split('T')[0],
                    status: 'applied',
                    source: job.source || 'Unknown',
                    created_by: currentUser.email, // Associate with current user
                });
                toast.success("Application tracked!", {
                    description: `Your application for '${job.title}' is saved in your profile.`,
                });
            } else {
                 toast.info("Application already tracked", {
                    description: `You can view its status on your profile page.`,
                });
            }

        } catch (error) {
            console.error("Failed to track application:", error);
            toast.error("Couldn't track application", {
                description: "There was an error saving this application.",
            });
        } finally {
            window.open(job.url, '_blank', 'noopener,noreferrer');
        }
    };

    if (isLoading) {
        return (
            <Card className="sticky top-8 shadow-lg animate-pulse">
                <CardHeader>
                    <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2 mt-2"></div>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="h-4 bg-gray-200 rounded w-full"></div>
                    <div className="h-4 bg-gray-200 rounded w-full"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-10 bg-gray-200 rounded w-32 mt-4"></div>
                </CardContent>
            </Card>
        );
    }

    if (!job) {
        return (
            <Card className="sticky top-8 shadow-lg h-[calc(100vh-280px)] flex items-center justify-center">
                <div className="text-center text-gray-500">
                    <p>Select a job to see details</p>
                </div>
            </Card>
        );
    }

    return (
        <div className="space-y-4">
            <Card className="sticky top-8 shadow-lg">
                <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle className="text-xl font-bold text-gray-900">{job.title}</CardTitle>
                            <CardDescription className="text-md text-gray-600 mt-1">{job.company}</CardDescription>
                            
                            {/* Direct Contact Information - More Compact */}
                            {job.has_direct_contact && (
                                <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded-md">
                                    <div className="flex items-center gap-2">
                                        <Crown className="w-3 h-3 text-yellow-600" />
                                        <span className="text-xs font-medium text-yellow-800">Direct Contact</span>
                                    </div>
                                    <div className="mt-1 space-y-1">
                                        {job.recruiter_email && (
                                            <div className="flex items-center gap-1 text-xs text-blue-600">
                                                <Mail className="w-3 h-3" />
                                                <a href={`mailto:${job.recruiter_email}`} className="hover:underline truncate">
                                                    {job.recruiter_email}
                                                </a>
                                            </div>
                                        )}
                                        {job.recruiter_phone && (
                                            <div className="flex items-center gap-1 text-xs text-green-600">
                                                <Phone className="w-3 h-3" />
                                                <a href={`tel:${job.recruiter_phone}`} className="hover:underline">
                                                    {job.recruiter_phone}
                                                </a>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                        
                        {/* Compact Action Buttons */}
                        <div className="flex flex-wrap items-start gap-1">
                             {isSubscribed && currentUser?.resume_url && (
                                <>
                                    <Button 
                                        onClick={() => setShowAIOptimizer(true)}
                                        size="sm" 
                                        variant="outline"
                                        className="h-7 px-2 text-xs"
                                    >
                                        <Sparkles className="w-3 h-3 mr-1" />
                                        Optimize
                                    </Button>
                                    <Button 
                                        onClick={() => setShowSmartApply(true)}
                                        size="sm" 
                                        variant="outline"
                                        className="h-7 px-2 text-xs"
                                    >
                                        <Target className="w-3 h-3 mr-1" />
                                        Smart Apply
                                    </Button>
                                    <Dialog>
                                        <DialogTrigger asChild>
                                            <Button variant="outline" size="sm" className="h-7 px-2 text-xs">
                                                <Sparkles className="w-3 h-3 mr-1" />
                                                AI Help
                                            </Button>
                                        </DialogTrigger>
                                        <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
                                            <DialogHeader>
                                                <DialogTitle className="text-lg">AI Application Assistant</DialogTitle>
                                                <DialogDescription>
                                                    Tailored content for '{job.title}'.
                                                </DialogDescription>
                                            </DialogHeader>
                                            <AIHelperContent job={job} currentUser={currentUser} />
                                        </DialogContent>
                                    </Dialog>
                                </>
                            )}
                            <Button asChild size="sm" variant="outline" className="h-7 px-2">
                                <a href={job.url} target="_blank" rel="noopener noreferrer">
                                    Apply
                                    <ExternalLink className="w-3 h-3 ml-1" />
                                </a>
                            </Button>
                        </div>
                    </div>
                    
                    {/* Compact Badges */}
                    <div className="flex flex-wrap gap-1 mt-3">
                        <Badge variant="outline" className="text-xs h-5"><MapPin className="w-2 h-2 mr-1" /> {job.location}</Badge>
                        {job.job_type && <Badge variant="outline" className="text-xs h-5">{job.job_type}</Badge>}
                        {job.salary_range && <Badge variant="outline" className="text-green-700 text-xs h-5">{job.salary_range}</Badge>}
                        {job.has_direct_contact && (
                            <Badge className="bg-yellow-100 text-yellow-800 text-xs h-5">
                                <Crown className="w-2 h-2 mr-1" />
                                Direct
                            </Badge>
                        )}
                    </div>
                </CardHeader>
                <CardContent className="pt-0">
                    <div className="prose prose-sm max-w-none text-gray-700">
                        <h4 className="text-sm font-semibold mb-2">Summary</h4>
                        <p className="text-sm">{job.description || "No description available."}</p>
                        
                        {/* Legal compliance notice */}
                        <div className="mt-3 p-2 bg-blue-50 border border-blue-200 rounded-md">
                            <p className="text-xs text-blue-700">
                                📋 Brief summary only. View full details on {job.source} →
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Compact AI Tools */}
            {showAIOptimizer && (
                <div className="mt-4">
                    <AIResumeOptimizer 
                        currentUser={currentUser}
                        jobDescription={job.description}
                        jobTitle={job.title}
                        onClose={() => setShowAIOptimizer(false)}
                    />
                </div>
            )}

            {showSmartApply && (
                <div className="mt-4">
                    <SmartApplyAssistant 
                        job={job} 
                        currentUser={currentUser}
                        onClose={() => setShowSmartApply(false)}
                    />
                </div>
            )}
        </div>
    );
}
