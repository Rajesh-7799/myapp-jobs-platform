
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Download, CheckCircle, Zap, X } from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';
import ReactMarkdown from 'react-markdown';
import { motion } from 'framer-motion';

export default function AIResumeOptimizer({ currentUser, jobDescription, jobTitle, onClose }) {
    const [optimizedResume, setOptimizedResume] = useState('');
    const [isOptimizing, setIsOptimizing] = useState(false);
    const [optimizationTips, setOptimizationTips] = useState([]);

    const optimizeResume = async () => {
        if (!currentUser?.resume_url) return;
        
        setIsOptimizing(true);
        setOptimizedResume('');
        setOptimizationTips([]);
        try {
            const result = await InvokeLLM({
                prompt: `You are an expert resume writer specializing in creating ATS-friendly resumes. Your primary goal is to optimize the user's resume to pass through Applicant Tracking Systems (ATS) and rank highly for the target job.

**Target Job:**
- **Title:** ${jobTitle}
- **Description:** ${jobDescription}

**Instructions:**
1.  **Re-write the entire resume** to be perfectly formatted for ATS parsing. Use standard fonts, clear headings (e.g., "Professional Experience," "Skills," "Education"), and avoid complex formatting like tables, columns, or graphics.
2.  **Integrate keywords** from the job description naturally throughout the resume, especially in the summary/profile, skills, and experience sections.
3.  **Quantify achievements** using metrics wherever possible (e.g., "Increased sales by 15%").
4.  **Tailor the professional summary** to mirror the key requirements of the job posting.

**Output Format (Strict Markdown):**

### Optimized ATS Resume
---
[The full, re-written resume content in a clean, single-column text format goes here. Use markdown for simple formatting like bolding and bullet points.]

### Analysis & Key Changes
---
- **ATS Compatibility Score:** [Provide an estimated score from 1-100]
- **Keywords Added:** [List the top 5-7 keywords you integrated]
- **Formatting Notes:** Your resume has been formatted for optimal ATS parsing.
- **Key Improvements:** [Briefly describe 2-3 of the most impactful changes you made, e.g., "Quantified your impact in the 'Project Manager' role."]`,
                file_urls: [currentUser.resume_url]
            });

            setOptimizedResume(result);
            
        } catch (error) {
            console.error("Error optimizing resume:", error);
            setOptimizedResume("Sorry, couldn't optimize your resume. Please try again.");
        } finally {
            setIsOptimizing(false);
        }
    };

    return (
        <Card className="border-purple-200">
            <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-purple-600" />
                        <CardTitle className="text-base">Resume Optimizer</CardTitle>
                    </div>
                    <Button variant="ghost" size="sm" onClick={onClose}>
                        <X className="w-4 h-4" />
                    </Button>
                </div>
            </CardHeader>
            <CardContent className="pt-0">
                <Button 
                    onClick={optimizeResume} 
                    disabled={isOptimizing || !currentUser?.resume_url}
                    size="sm"
                    className="mb-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                    {isOptimizing ? (
                        <>
                            <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                            Optimizing...
                        </>
                    ) : (
                        <>
                            <Sparkles className="w-3 h-3 mr-2" />
                            Optimize Resume
                        </>
                    )}
                </Button>

                {optimizedResume && (
                    <div className="border rounded-lg p-3 bg-white max-h-64 overflow-y-auto">
                        <div className="flex justify-between items-center mb-2">
                            <h4 className="text-sm font-semibold">Optimized Resume</h4>
                            <Button size="sm" variant="outline" className="h-6 px-2 text-xs">
                                <Download className="w-3 h-3 mr-1" />
                                Save
                            </Button>
                        </div>
                        <div className="prose prose-xs max-w-none">
                            <ReactMarkdown>{optimizedResume}</ReactMarkdown>
                        </div>
                    </div>
                )}

                {!currentUser?.resume_url && (
                    <div className="text-center p-4 text-gray-500 bg-gray-50 rounded-lg">
                        Upload your resume in your Profile to use AI optimization
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
