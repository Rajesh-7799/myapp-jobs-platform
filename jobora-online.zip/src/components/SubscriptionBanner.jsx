
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Crown, Sparkles, Zap, Globe, Star, CreditCard, Percent, Briefcase } from 'lucide-react';
import { User } from '@/api/entities';
import PaymentDialog from './PaymentDialog';
import { cn } from "@/lib/utils";


const currencyPricing = {
    USD: { symbol: '$', flag: '🇺🇸', country: 'United States', plans: { weekly: 7, monthly: 20, yearly: 200 } },
    EUR: { symbol: '€', flag: '🇪🇺', country: 'Europe & Ireland', plans: { weekly: 6, monthly: 18, yearly: 180 } },
    GBP: { symbol: '£', flag: '🇬🇧', country: 'United Kingdom', plans: { weekly: 5, monthly: 16, yearly: 160 } },
    INR: { symbol: '₹', flag: '🇮🇳', country: 'India', plans: { weekly: 199, monthly: 500, yearly: 5000 } },
    CAD: { symbol: 'C$', flag: '🇨🇦', country: 'Canada', plans: { weekly: 9, monthly: 25, yearly: 250 } },
    AUD: { symbol: 'A$', flag: '🇦🇺', country: 'Australia', plans: { weekly: 10, monthly: 28, yearly: 280 } },
    JPY: { symbol: '¥', flag: '🇯🇵', country: 'Japan', plans: { weekly: 800, monthly: 2200, yearly: 22000 } },
    BRL: { symbol: 'R$', flag: '🇧🇷', country: 'Brazil', plans: { weekly: 35, monthly: 95, yearly: 950 } },
    MXN: { symbol: '$', flag: '🇲🇽', country: 'Mexico', plans: { weekly: 120, monthly: 350, yearly: 3500 } },
    CNY: { symbol: '¥', flag: '🇨🇳', country: 'China', plans: { weekly: 45, monthly: 130, yearly: 1300 } },
};

const planDetails = {
    weekly: { label: 'Weekly', per: '/week', save: null },
    monthly: { label: 'Monthly', per: '/month', save: 'Save 15%' },
    yearly: { label: 'Yearly', per: '/year', save: 'Best Value - Save 30%' },
};


export default function SubscriptionBanner({ currentUser, isSubscribed }) {
    const [userCurrency, setUserCurrency] = useState('USD');
    const [showPayment, setShowPayment] = useState(false);
    // The plan selector UI is removed, but we keep 'selectedPlan' state for payment dialog logic.
    // Defaulting to 'monthly' as it's a common default.
    const [selectedPlan, setSelectedPlan] = useState('monthly'); 

    const isFirstTimeSubscriber = !currentUser?.has_subscribed_before;


    useEffect(() => {
        detectUserCurrency();
    }, []);

    const detectUserCurrency = () => {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const language = navigator.language || navigator.userLanguage;
        
        if (timezone.includes('London') || timezone.includes('Edinburgh') || language.startsWith('en-GB')) {
            setUserCurrency('GBP');
        } else if (timezone.includes('Dublin') || timezone.includes('Ireland') || language.startsWith('en-IE')) {
            setUserCurrency('EUR');
        } else if (timezone.includes('Kolkata') || language.startsWith('en-IN')) {
            setUserCurrency('INR');
        } else if (timezone.includes('Europe')) {
            setUserCurrency('EUR');
        } else if (timezone.includes('Toronto') || timezone.includes('Vancouver')) {
            setUserCurrency('CAD');
        } else if (timezone.includes('Sydney') || timezone.includes('Melbourne')) {
            setUserCurrency('AUD');
        } else if (timezone.includes('Tokyo')) {
            setUserCurrency('JPY');
        } else if (timezone.includes('Brazil')) {
            setUserCurrency('BRL');
        } else if (timezone.includes('Mexico')) {
            setUserCurrency('MXN');
        } else if (timezone.includes('Shanghai') || timezone.includes('Beijing')) {
            setUserCurrency('CNY');
        }
    };

    const pricing = currencyPricing[userCurrency];
    // selectedPlan is now always 'monthly' by default from state, as the UI selector is removed.
    const originalPrice = pricing.plans[selectedPlan]; 
    const finalPrice = isFirstTimeSubscriber ? Math.round(originalPrice * 0.8) : originalPrice;


    if (isSubscribed) {
        return null;
    }

    return (
        <>
            <Card className="border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50 mb-4">
                <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <div className="flex items-center gap-3">
                            <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shadow-md flex-shrink-0">
                                <Briefcase className="w-4 h-4 text-white"/>
                            </div>
                            <div>
                                <h3 className="font-semibold text-sm">Unlock Premium Job Search</h3>
                                <p className="text-xs text-gray-600">Advanced filters + AI matching + More job sources + Resume tools</p>
                            </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                            <Select value={userCurrency} onValueChange={setUserCurrency}>
                                <SelectTrigger className="w-32 h-8">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {Object.entries(currencyPricing).map(([currency, data]) => (
                                        <SelectItem key={currency} value={currency}>
                                            {data.flag} {data.symbol}{data.plans.monthly}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            
                            <Button 
                                size="sm"
                                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                                onClick={() => setShowPayment(true)}
                            >
                                <Briefcase className="w-4 h-4 mr-1" />
                                Upgrade Now
                            </Button>
                        </div>
                    </div>
                    
                    {isFirstTimeSubscriber && (
                        <Badge className="mt-2 bg-emerald-100 text-emerald-800 text-xs">
                            <Percent className="w-3 h-3 mr-1"/>
                            20% OFF First-time users
                        </Badge>
                    )}
                </CardContent>
            </Card>

            {showPayment && (
                <PaymentDialog 
                    isOpen={showPayment}
                    onClose={() => setShowPayment(false)}
                    pricing={{
                        ...pricing,
                        finalPrice,
                        originalPrice,
                        isFirstTime: isFirstTimeSubscriber,
                        cycle: selectedPlan
                    }}
                    currentUser={currentUser}
                />
            )}
        </>
    );
}
