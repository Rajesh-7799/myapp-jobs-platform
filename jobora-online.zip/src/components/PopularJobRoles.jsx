import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Briefcase, Code, Palette, BarChart3, Shield, Megaphone, Users } from 'lucide-react';
import { motion } from 'framer-motion';

const jobRoles = [
    { title: 'Software Engineer', icon: Code, color: 'bg-blue-100 text-blue-700 hover:bg-blue-200' },
    { title: 'Product Manager', icon: Users, color: 'bg-purple-100 text-purple-700 hover:bg-purple-200' },
    { title: 'UX Designer', icon: Palette, color: 'bg-pink-100 text-pink-700 hover:bg-pink-200' },
    { title: 'Data Scientist', icon: BarChart3, color: 'bg-green-100 text-green-700 hover:bg-green-200' },
    { title: 'DevOps Engineer', icon: Shield, color: 'bg-orange-100 text-orange-700 hover:bg-orange-200' },
    { title: 'Marketing Manager', icon: Megaphone, color: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200' },
    { title: 'Frontend Developer', icon: Code, color: 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200' },
    { title: 'Sales Representative', icon: TrendingUp, color: 'bg-red-100 text-red-700 hover:bg-red-200' },
];

const remoteRoles = [
    'Remote Software Engineer',
    'Remote Product Manager',
    'Remote UX Designer',
    'Remote Marketing Manager'
];

const experienceLevels = [
    'Entry Level Jobs',
    'Mid Level Positions',
    'Senior Level Roles',
    'Executive Positions'
];

export default function PopularJobRoles({ onRoleClick }) {
    return (
        <div className="space-y-4">
            {/* Popular Job Roles */}
            <div>
                <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className="w-4 h-4 text-gray-600" />
                    <h3 className="text-sm font-semibold text-gray-700">Popular Job Roles</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                    {jobRoles.map((role, index) => (
                        <motion.div
                            key={role.title}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.05 }}
                        >
                            <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => onRoleClick(role.title)}
                                className={`h-8 ${role.color} transition-colors`}
                            >
                                <role.icon className="w-3 h-3 mr-1" />
                                {role.title}
                            </Button>
                        </motion.div>
                    ))}
                </div>
            </div>

            {/* Remote Work Options */}
            <div>
                <div className="flex items-center gap-2 mb-2">
                    <Briefcase className="w-4 h-4 text-gray-600" />
                    <h3 className="text-sm font-semibold text-gray-700">Remote Opportunities</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                    {remoteRoles.map((role, index) => (
                        <Badge
                            key={role}
                            variant="outline"
                            className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 transition-colors text-xs py-1"
                            onClick={() => onRoleClick(role)}
                        >
                            {role}
                        </Badge>
                    ))}
                </div>
            </div>

            {/* Experience Levels */}
            <div>
                <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="w-4 h-4 text-gray-600" />
                    <h3 className="text-sm font-semibold text-gray-700">By Experience Level</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                    {experienceLevels.map((level, index) => (
                        <Badge
                            key={level}
                            variant="secondary"
                            className="cursor-pointer hover:bg-gray-200 transition-colors text-xs py-1"
                            onClick={() => onRoleClick(level)}
                        >
                            {level}
                        </Badge>
                    ))}
                </div>
            </div>
        </div>
    );
}