import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Briefcase, Clock, MapPin, Building } from 'lucide-react';
import { motion } from 'framer-motion';

export default function JobCategories({ jobs, onJobSelect }) {
    // Categorize jobs
    const categories = {
        'Full-time': jobs.filter(job => job.job_type === 'Full-time').slice(0, 4),
        'Remote': jobs.filter(job => job.location?.toLowerCase().includes('remote')).slice(0, 4),
        'Contract': jobs.filter(job => job.job_type === 'Contract').slice(0, 3),
        'Latest': jobs.slice(0, 5)
    };

    const CategorySection = ({ title, jobs, icon: Icon }) => {
        if (jobs.length === 0) return null;
        
        return (
            <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                    <Icon className="w-5 h-5 text-blue-600" />
                    <h3 className="font-semibold text-gray-900">{title}</h3>
                    <Badge variant="outline" className="text-xs">{jobs.length}</Badge>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {jobs.map((job, index) => (
                        <motion.div
                            key={job.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                        >
                            <Card 
                                className="cursor-pointer hover:shadow-md transition-shadow border-l-4 border-l-blue-500"
                                onClick={() => onJobSelect(job)}
                            >
                                <CardContent className="p-4">
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex-1 min-w-0">
                                            <h4 className="font-medium text-sm text-gray-900 truncate">{job.title}</h4>
                                            <p className="text-xs text-gray-600 truncate">{job.company}</p>
                                        </div>
                                        {job.source_logo && (
                                            <img 
                                                src={job.source_logo} 
                                                alt={job.source} 
                                                className="w-5 h-5 object-contain ml-2"
                                                onError={(e) => {
                                                    e.target.src = `https://via.placeholder.com/20x20/4F46E5/FFFFFF?text=${job.source?.charAt(0) || 'J'}`;
                                                }}
                                            />
                                        )}
                                    </div>
                                    
                                    <div className="flex items-center gap-1 text-xs text-gray-500 mb-2">
                                        <MapPin className="w-3 h-3" />
                                        <span className="truncate">{job.location}</span>
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div className="flex gap-1">
                                            {job.job_type && (
                                                <Badge variant="secondary" className="text-xs py-0">
                                                    {job.job_type}
                                                </Badge>
                                            )}
                                            {job.has_direct_contact && (
                                                <Badge className="bg-yellow-100 text-yellow-800 text-xs py-0">
                                                    Direct
                                                </Badge>
                                            )}
                                        </div>
                                        <span className="text-xs text-gray-400">
                                            {new Date(job.created_date).toLocaleDateString()}
                                        </span>
                                    </div>
                                </CardContent>
                            </Card>
                        </motion.div>
                    ))}
                </div>
            </div>
        );
    };

    return (
        <div className="space-y-6">
            <CategorySection title="Full-time Opportunities" jobs={categories['Full-time']} icon={Briefcase} />
            <CategorySection title="Remote Work" jobs={categories['Remote']} icon={MapPin} />
            <CategorySection title="Contract Projects" jobs={categories['Contract']} icon={Clock} />
            <CategorySection title="Latest Postings" jobs={categories['Latest']} icon={Building} />
        </div>
    );
}