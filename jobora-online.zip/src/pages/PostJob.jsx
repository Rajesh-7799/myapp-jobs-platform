
import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Job } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Loader2, Briefcase, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';

export default function PostJobPage() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const editJobId = searchParams.get('edit');
    
    const [isLoading, setIsLoading] = useState(false);
    const [isLoadingJob, setIsLoadingJob] = useState(!!editJobId);
    const [currentUser, setCurrentUser] = useState(null);
    
    const [jobData, setJobData] = useState({
        title: '',
        company: '',
        location: '',
        description: '',
        requirements: '',
        job_type: 'Full-time',
        experience_level: 'mid',
        salary_min: '',
        salary_max: '',
        recruiter_name: '',
        recruiter_email: '',
        recruiter_phone: '',
        has_direct_contact: false,
        easy_apply_enabled: true,
        is_internal: true,
        is_external: false,
        status: 'active'
    });

    useEffect(() => {
        const loadUserData = async () => {
            try {
                const user = await User.me();
                setCurrentUser(user);
                
                // Pre-fill company data if available
                if (user.company_name || user.full_name || user.email) {
                    setJobData(prev => ({
                        ...prev,
                        company: user.company_name || 'Your Company',
                        recruiter_name: user.full_name || user.email.split('@')[0],
                        recruiter_email: user.email,
                        recruiter_phone: user.phone || ''
                    }));
                }
                return user; // Return the user object for immediate use
            } catch (error) {
                console.error("Error loading user data:", error);
                toast.error("Please log in to post a job.");
                navigate(createPageUrl('Home'));
                return null; // Return null if user loading fails
            }
        };

        const loadJobForEditing = async (authenticatedUser) => { // Retain parameter for creator check
            setIsLoadingJob(true);
            try {
                const jobs = await Job.filter({ id: editJobId });
                // Check if job exists and if the authenticated user is the job creator
                if (jobs.length > 0 && jobs[0].created_by === authenticatedUser.email) {
                    const jobToEdit = jobs[0];
                    setJobData({
                        title: jobToEdit.title || '',
                        company: jobToEdit.company || '',
                        location: jobToEdit.location || '',
                        description: jobToEdit.description || '',
                        requirements: jobToEdit.requirements || '',
                        job_type: jobToEdit.job_type || 'Full-time',
                        experience_level: jobToEdit.experience_level || 'mid',
                        // Convert full salary values from DB back to thousands for display
                        salary_min: jobToEdit.salary_min ? jobToEdit.salary_min / 1000 : '',
                        salary_max: jobToEdit.salary_max ? jobToEdit.salary_max / 1000 : '',
                        recruiter_name: jobToEdit.recruiter_name || '',
                        recruiter_email: jobToEdit.recruiter_email || '',
                        recruiter_phone: jobToEdit.recruiter_phone || '',
                        has_direct_contact: jobToEdit.has_direct_contact || false,
                        easy_apply_enabled: jobToEdit.easy_apply_enabled !== false,
                        is_internal: jobToEdit.is_internal !== false,
                        is_external: jobToEdit.is_external || false,
                        status: jobToEdit.status || 'active'
                    });
                } else {
                    toast.error("Job not found or you don't have permission to edit it."); 
                    navigate(createPageUrl('EmployerDashboard'));
                }
            } catch (error) {
                console.error("Error loading job:", error);
                toast.error("Failed to load job data. Please try again."); 
            } finally {
                setIsLoadingJob(false);
            }
        };

        const initPageData = async () => {
            const user = await loadUserData(); // Load user first and ensure it's available.
            
            if (!user) {
                // If user data fails to load (e.g., not logged in), redirect is already handled in loadUserData
                return;
            }

            if (editJobId) {
                // Now that user is definitely loaded, load the job for editing
                loadJobForEditing(user); // Keep passing user for creator check
            }
        };
        initPageData();
    }, [editJobId, navigate]);

    const handleInputChange = (field, value) => {
        setJobData(prev => ({ ...prev, [field]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!jobData.title || !jobData.company || !jobData.location || !jobData.description) {
            toast.error("Please fill in all required fields");
            return;
        }

        setIsLoading(true);
        try {
            const submitData = {
                title: jobData.title,
                company: jobData.company,
                location: jobData.location,
                description: jobData.description,
                requirements: jobData.requirements || '',
                job_type: jobData.job_type,
                experience_level: jobData.experience_level,
                // Convert salary from thousands (input) to full value for backend storage
                salary_min: jobData.salary_min ? Number(jobData.salary_min) * 1000 : null,
                salary_max: jobData.salary_max ? Number(jobData.salary_max) * 1000 : null,
                // Salary range string remains based on thousands, for display purposes in job cards etc.
                salary_range: jobData.salary_min && jobData.salary_max 
                    ? `$${jobData.salary_min}k - $${jobData.salary_max}k`
                    : null,
                recruiter_name: jobData.recruiter_name || '',
                recruiter_email: jobData.recruiter_email || '',
                recruiter_phone: jobData.recruiter_phone || '',
                has_direct_contact: jobData.has_direct_contact,
                easy_apply_enabled: jobData.easy_apply_enabled,
                is_internal: true,
                is_external: false,
                status: 'active',
                source: 'JOBORA',
                url: `${window.location.origin}/apply`,
                views_count: 0,
                applications_count: 0
            };

            let result;
            if (editJobId) {
                result = await Job.update(editJobId, submitData);
                toast.success(`Job "${result.title}" updated!`);
            } else {
                result = await Job.create(submitData);
                toast.success(`Job "${result.title}" posted! You will now be redirected.`);
            }
            
            // Wait a moment then navigate
            setTimeout(() => {
                navigate(createPageUrl('EmployerDashboard'));
            }, 1500); // Increased timeout as per outline
            
        } catch (error) {
            console.error("Error saving job:", error);
            toast.error("Failed to post job. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoadingJob) {
        return (
            <div className="flex justify-center items-center min-h-64">
                <Loader2 className="w-8 h-8 animate-spin" />
                <span className="ml-2">Loading job data...</span>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <Briefcase className="w-6 h-6 text-white" />
                </div>
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">
                        {editJobId ? 'Edit Job Posting' : 'Post a New Job'}
                    </h1>
                    <p className="text-gray-600">
                        {editJobId ? 'Update your job posting details' : 'Share your opportunity with thousands of job seekers'}
                    </p>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Job Details</CardTitle>
                        <CardDescription>Basic information about the position</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="title">Job Title *</Label>
                                <Input
                                    id="title"
                                    value={jobData.title}
                                    onChange={(e) => handleInputChange('title', e.target.value)}
                                    placeholder="e.g. Senior Software Engineer"
                                    required
                                />
                            </div>
                            <div>
                                <Label htmlFor="company">Company Name *</Label>
                                <Input
                                    id="company"
                                    value={jobData.company}
                                    onChange={(e) => handleInputChange('company', e.target.value)}
                                    placeholder="Your company name"
                                    required
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="location">Location *</Label>
                                <Input
                                    id="location"
                                    value={jobData.location}
                                    onChange={(e) => handleInputChange('location', e.target.value)}
                                    placeholder="e.g. San Francisco, CA or Remote"
                                    required
                                />
                            </div>
                            <div>
                                <Label htmlFor="job_type">Job Type</Label>
                                <Select value={jobData.job_type} onValueChange={(value) => handleInputChange('job_type', value)}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Full-time">Full-time</SelectItem>
                                        <SelectItem value="Part-time">Part-time</SelectItem>
                                        <SelectItem value="Contract">Contract</SelectItem>
                                        <SelectItem value="Internship">Internship</SelectItem>
                                        <SelectItem value="Temporary">Temporary</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div>
                            <Label htmlFor="description">Job Description *</Label>
                            <Textarea
                                id="description"
                                value={jobData.description}
                                onChange={(e) => handleInputChange('description', e.target.value)}
                                placeholder="Describe the role, responsibilities, and what makes this opportunity exciting..."
                                rows={5}
                                required
                            />
                        </div>

                        <div>
                            <Label htmlFor="requirements">Requirements & Qualifications</Label>
                            <Textarea
                                id="requirements"
                                value={jobData.requirements}
                                onChange={(e) => handleInputChange('requirements', e.target.value)}
                                placeholder="List the required skills, experience, education, etc."
                                rows={4}
                            />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="experience_level">Experience Level</Label>
                                <Select value={jobData.experience_level} onValueChange={(value) => handleInputChange('experience_level', value)}>
                                    <SelectTrigger>
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="entry">Entry Level</SelectItem>
                                        <SelectItem value="mid">Mid Level</SelectItem>
                                        <SelectItem value="senior">Senior Level</SelectItem>
                                        <SelectItem value="executive">Executive</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Compensation</CardTitle>
                        <CardDescription>Salary information helps attract qualified candidates</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="salary_min">Minimum Salary (in thousands)</Label>
                                <Input
                                    id="salary_min"
                                    type="number"
                                    value={jobData.salary_min}
                                    onChange={(e) => handleInputChange('salary_min', e.target.value)}
                                    placeholder="80"
                                />
                            </div>
                            <div>
                                <Label htmlFor="salary_max">Maximum Salary (in thousands)</Label>
                                <Input
                                    id="salary_max"
                                    type="number"
                                    value={jobData.salary_max}
                                    onChange={(e) => handleInputChange('salary_max', e.target.value)}
                                    placeholder="120"
                                />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Contact Information</CardTitle>
                        <CardDescription>Let candidates know how to reach you</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center space-x-2">
                            <Switch
                                id="direct_contact"
                                checked={jobData.has_direct_contact}
                                onCheckedChange={(checked) => handleInputChange('has_direct_contact', checked)}
                            />
                            <Label htmlFor="direct_contact">Enable direct contact (candidates can reach you directly)</Label>
                        </div>

                        {jobData.has_direct_contact && (
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                                <div>
                                    <Label htmlFor="recruiter_name">Your Name</Label>
                                    <Input
                                        id="recruiter_name"
                                        value={jobData.recruiter_name}
                                        onChange={(e) => handleInputChange('recruiter_name', e.target.value)}
                                        placeholder="John Doe"
                                    />
                                </div>
                                <div>
                                    <Label htmlFor="recruiter_email">Contact Email</Label>
                                    <Input
                                        id="recruiter_email"
                                        type="email"
                                        value={jobData.recruiter_email}
                                        onChange={(e) => handleInputChange('recruiter_email', e.target.value)}
                                        placeholder="john@company.com"
                                    />
                                </div>
                                <div>
                                    <Label htmlFor="recruiter_phone">Phone Number</Label>
                                    <Input
                                        id="recruiter_phone"
                                        value={jobData.recruiter_phone}
                                        onChange={(e) => handleInputChange('recruiter_phone', e.target.value)}
                                        placeholder="+1 (555) 123-4567"
                                    />
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>

                <Card>
                    <CardHeader>
                        <CardTitle>Application Settings</CardTitle>
                        <CardDescription>Configure how candidates can apply</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center space-x-2">
                            <Switch
                                id="easy_apply"
                                checked={jobData.easy_apply_enabled}
                                onCheckedChange={(checked) => handleInputChange('easy_apply_enabled', checked)}
                            />
                            <Label htmlFor="easy_apply">Enable 1-click Easy Apply (recommended)</Label>
                        </div>
                        <p className="text-sm text-gray-600">
                            Easy Apply allows candidates to submit applications instantly using their JOBORA profile information.
                        </p>
                    </CardContent>
                </Card>

                <div className="flex justify-end gap-4">
                    <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => navigate(createPageUrl('EmployerDashboard'))}
                    >
                        Cancel
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                        {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {editJobId ? 'Update Job' : 'Post Job'}
                    </Button>
                </div>
            </form>
        </div>
    );
}
