import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Bell, Globe, Shield, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function SettingsPage() {
    const [user, setUser] = useState(null);
    const [settings, setSettings] = useState({
        notifications_email: true,
        notifications_push: true,
        language: 'en',
        timezone: 'UTC',
        job_alerts: true,
        profile_visibility: 'private'
    });
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        fetchUserSettings();
    }, []);

    const fetchUserSettings = async () => {
        try {
            const currentUser = await User.me();
            setUser(currentUser);
            
            // Load existing settings or use defaults
            const initialSettings = {
                notifications_email: currentUser.notifications_email ?? true,
                notifications_push: currentUser.notifications_push ?? true,
                language: currentUser.language || 'en',
                timezone: currentUser.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone,
                job_alerts: currentUser.job_alerts ?? true,
                profile_visibility: currentUser.profile_visibility || 'private'
            };
            setSettings(initialSettings);

        } catch (error) {
            console.error("Error fetching user settings:", error);
            toast.error("Failed to load settings");
        } finally {
            setIsLoading(false);
        }
    };

    const saveSettings = async () => {
        setIsSaving(true);
        try {
            await User.updateMyUserData(settings);
            toast.success("Settings saved successfully!");
        } catch (error) {
            console.error("Error saving settings:", error);
            toast.error("Failed to save settings");
        } finally {
            setIsSaving(false);
        }
    };

    const updateSetting = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
                    <p className="text-gray-600">Customize your JOBORA experience</p>
                </div>
                <Button 
                    onClick={saveSettings} 
                    disabled={isSaving}
                    className="bg-purple-600 hover:bg-purple-700"
                >
                    {isSaving ? (
                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
                    ) : (
                        'Save Changes'
                    )}
                </Button>
            </div>

            {/* Notification Settings */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Bell className="w-5 h-5 text-blue-600" />
                        Notifications
                    </CardTitle>
                    <CardDescription>
                        Manage how you receive notifications
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium">Email Notifications</p>
                            <p className="text-sm text-gray-500">Receive notifications via email</p>
                        </div>
                        <Switch 
                            checked={settings.notifications_email}
                            onCheckedChange={(checked) => updateSetting('notifications_email', checked)}
                        />
                    </div>
                    
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium">Push Notifications</p>
                            <p className="text-sm text-gray-500">Receive push notifications in your browser</p>
                        </div>
                        <Switch 
                            checked={settings.notifications_push}
                            onCheckedChange={(checked) => updateSetting('notifications_push', checked)}
                        />
                    </div>
                    
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium">Job Alerts</p>
                            <p className="text-sm text-gray-500">Get notified about new job opportunities</p>
                        </div>
                        <Switch 
                            checked={settings.job_alerts}
                            onCheckedChange={(checked) => updateSetting('job_alerts', checked)}
                        />
                    </div>
                </CardContent>
            </Card>

            {/* Privacy Settings */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Shield className="w-5 h-5 text-green-600" />
                        Privacy
                    </CardTitle>
                    <CardDescription>
                        Control your privacy and data settings
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium">Profile Visibility</p>
                            <p className="text-sm text-gray-500">Who can see your profile</p>
                        </div>
                        <Select value={settings.profile_visibility} onValueChange={(value) => updateSetting('profile_visibility', value)}>
                            <SelectTrigger className="w-32">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="private">Private</SelectItem>
                                <SelectItem value="public">Public</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Language & Region */}
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <Globe className="w-5 h-5 text-orange-600" />
                        Language & Region
                    </CardTitle>
                    <CardDescription>
                        Set your language and timezone preferences
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium">Language</p>
                            <p className="text-sm text-gray-500">Choose your preferred language</p>
                        </div>
                        <Select value={settings.language} onValueChange={(value) => updateSetting('language', value)}>
                            <SelectTrigger className="w-32">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="en">English</SelectItem>
                                <SelectItem value="es">Español</SelectItem>
                                <SelectItem value="fr">Français</SelectItem>
                                <SelectItem value="de">Deutsch</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium">Timezone</p>
                            <p className="text-sm text-gray-500">Your current timezone</p>
                        </div>
                        <Badge variant="outline" className="font-mono">
                            {settings.timezone}
                        </Badge>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}