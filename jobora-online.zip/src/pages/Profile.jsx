
import React, { useState, useEffect, useRef } from 'react';
import { User } from '@/api/entities';
import { Application } from '@/api/entities';
import { Subscription } from '@/api/entities';
import { UploadFile, InvokeLLM } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import {
    Upload, FileText, CheckCircle, Loader2, AlertCircle,
    BarChart3, TrendingUp, Eye, Calendar, ExternalLink, Globe2,
    Sparkles, User as UserIcon, Briefcase, DollarSign, Linkedin,
    Crown, BellOff, Redo, Phone, MapPin, GraduationCap, Award,
    Trash2, Star, Download, Plus, LogOut, XCircle, RefreshCw,
    ChevronDown, ChevronRight, Camera, Settings, FileUser
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

export default function ProfilePage() {
    const [user, setUser] = useState(null);
    const [applications, setApplications] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isUploading, setIsUploading] = useState(false);
    const [isEnhancing, setIsEnhancing] = useState(false);
    const [isExtractingProfile, setIsExtractingProfile] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [enhancedResume, setEnhancedResume] = useState('');
    const [profileData, setProfileData] = useState({
        skills: [],
        experience_years: '',
        preferred_job_type: '',
        target_salary: '',
        portfolio_url: '',
        linkedin_url: '',
        profile_visibility: 'private',
        phone: '',
        location: '',
        bio: '',
        education: [],
        certifications: []
    });
    const fileInputRef = useRef(null);
    const avatarInputRef = useRef(null);

    // Expanded sections state
    const [expandedSections, setExpandedSections] = useState({
        dashboard: true, // Start with dashboard expanded
        resume: false,
        profile: false,
        professional: false,
        applications: false,
        subscription: false,
        account: false
    });

    // Account deletion states
    const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [deleteConfirmText, setDeleteConfirmText] = useState('');

    // Subscription management states
    const [currentSubscription, setCurrentSubscription] = useState(null);
    const [isCancelling, setIsCancelling] = useState(false);

    // Avatar upload state
    const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

    useEffect(() => {
        fetchUserAndApplications();
    }, []);

    // Toggle section expansion
    const toggleSection = (section) => {
        setExpandedSections(prev => ({
            ...prev,
            [section]: !prev[section]
        }));
    };

    const fetchUserAndApplications = async () => {
        setIsLoading(true);
        try {
            const currentUser = await User.me();
            // Ensure resumes is always an array, even if backend sends null/undefined
            setUser({ ...currentUser, resumes: currentUser.resumes || [] });

            setProfileData({
                skills: currentUser.skills || [],
                experience_years: currentUser.experience_years || '',
                preferred_job_type: currentUser.preferred_job_type || '',
                target_salary: currentUser.target_salary || '',
                portfolio_url: currentUser.portfolio_url || '',
                linkedin_url: currentUser.linkedin_url || '',
                profile_visibility: currentUser.profile_visibility || 'private',
                phone: currentUser.phone || '',
                location: currentUser.location || '',
                bio: currentUser.bio || '',
                education: currentUser.education || [],
                certifications: currentUser.certifications || []
            });

            const userApplications = await Application.filter({ created_by: currentUser.email });
            setApplications(userApplications);

            // Fetch subscription status
            const subscriptions = await Subscription.filter({ created_by: currentUser.email }, '-created_date');
            if (subscriptions.length > 0) {
                const activeSub = subscriptions.find(s => ['active', 'trial'].includes(s.status) || (s.status === 'cancelled' && new Date(s.end_date) > new Date()));
                setCurrentSubscription(activeSub || subscriptions[0]);
            } else {
                setCurrentSubscription(null);
            }

        } catch (error) {
            console.error("Error fetching data:", error);
            setError("Failed to load profile data.");
            toast.error("Failed to load profile data");
        } finally {
            setIsLoading(false);
        }
    };

    const handleAvatarUpload = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        if (file.size > 2 * 1024 * 1024) { // 2MB limit
            toast.error("Image is too large. Please upload an image smaller than 2MB.");
            return;
        }
        if (!file.type.startsWith('image/')) {
            toast.error("Invalid file type. Please upload an image file.");
            return;
        }

        setIsUploadingAvatar(true);
        try {
            const { file_url } = await UploadFile({ file });
            await User.updateMyUserData({ avatar_url: file_url });
            toast.success("Profile picture updated!");
            await fetchUserAndApplications(); // Re-fetch user data to update avatar
        } catch (error) {
            console.error("Error uploading avatar:", error);
            toast.error("Failed to upload profile picture. Please try again.");
        } finally {
            setIsUploadingAvatar(false);
        }
    };

    const extractProfileFromResume = async (resumeUrl) => {
        if (!resumeUrl) {
            toast.error("No resume selected for profile extraction");
            return;
        }

        setIsExtractingProfile(true);
        try {
            const result = await InvokeLLM({
                prompt: `Extract professional information from this resume and return it in JSON format. Include:
                - skills: array of technical and professional skills
                - location: current location/city
                - phone: phone number if available
                - bio: professional summary/objective (2-3 sentences)
                - education: array of objects with degree, institution, year
                - certifications: array of certification names
                - experience_years: estimated years of experience based on work history

                Return only valid JSON that matches this structure.`,
                file_urls: [resumeUrl],
                response_json_schema: {
                    type: "object",
                    properties: {
                        skills: { type: "array", items: { type: "string" } },
                        location: { type: "string" },
                        phone: { type: "string" },
                        bio: { type: "string" },
                        education: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    degree: { type: "string" },
                                    institution: { type: "string" },
                                    year: { type: "string" }
                                }
                            }
                        },
                        certifications: { type: "array", items: { type: "string" } },
                        experience_years: { type: "number" }
                    }
                }
            });

            if (result) {
                setProfileData(prev => ({
                    ...prev,
                    skills: result.skills || prev.skills,
                    location: result.location || prev.location,
                    phone: result.phone || prev.phone,
                    bio: result.bio || prev.bio,
                    education: result.education || prev.education,
                    certifications: result.certifications || prev.certifications,
                    experience_years: result.experience_years || prev.experience_years
                }));
                toast.success("Profile information extracted from resume!");
            }
        } catch (error) {
            console.error("Error extracting profile:", error);
            toast.error("Failed to extract profile information");
        } finally {
            setIsExtractingProfile(false);
        }
    };

    const handleCancelSubscription = async () => {
        if (!currentSubscription) return;

        setIsCancelling(true);
        try {
            await Subscription.update(currentSubscription.id, { status: 'cancelled' });
            toast.success("Subscription cancelled successfully");
            await fetchUserAndApplications();
        } catch (error) {
            toast.error("Failed to cancel subscription");
            console.error("Error cancelling subscription:", error);
        } finally {
            setIsCancelling(false);
        }
    };

    const handleReactivateSubscription = async () => {
        if (!currentSubscription) return;
        setIsCancelling(true);
        try {
            await Subscription.update(currentSubscription.id, { status: 'active' });
            toast.success("Subscription reactivated!");
            await fetchUserAndApplications();
        } catch (error) {
            toast.error("Failed to reactivate subscription");
            console.error("Error reactivating subscription:", error);
        } finally {
            setIsCancelling(false);
        }
    };

    const handleFileChange = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        if (file.size > 5 * 1024 * 1024) {
            toast.error("File is too large. Please upload a file smaller than 5MB.");
            return;
        }
        if (!['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(file.type)) {
            toast.error("Invalid file type. Please upload a PDF or Word document.");
            return;
        }

        setIsUploading(true);
        try {
            const { file_url } = await UploadFile({ file });

            // Create new resume object
            const newResume = {
                id: Date.now().toString(), // Simple unique ID for frontend, ideally backend generates
                filename: file.name,
                url: file_url,
                upload_date: new Date().toISOString(),
                is_primary: !user?.resumes?.length, // First resume uploaded becomes primary
                file_size: file.size
            };

            // Update user's resumes array
            const currentResumes = user?.resumes || [];
            const updatedResumes = [...currentResumes, newResume];

            await User.updateMyUserData({
                resumes: updatedResumes,
                // Update backward compatibility fields if this is the primary resume
                ...(newResume.is_primary && {
                    resume_url: file_url,
                    resume_filename: file.name
                })
            });

            toast.success("Resume uploaded successfully!");
            await fetchUserAndApplications();
        } catch (err) {
            console.error(err);
            toast.error("Failed to upload resume. Please try again.");
        } finally {
            setIsUploading(false);
        }
    };

    const deleteResume = async (resumeId) => {
        try {
            const currentResumes = user?.resumes || [];
            const resumeToDelete = currentResumes.find(r => r.id === resumeId);
            const updatedResumes = currentResumes.filter(r => r.id !== resumeId);

            let updateData = { resumes: updatedResumes };

            // If we deleted the primary resume, set another as primary
            if (resumeToDelete?.is_primary) {
                if (updatedResumes.length > 0) {
                    updatedResumes[0] = { ...updatedResumes[0], is_primary: true }; // Mark new primary
                    updateData.resume_url = updatedResumes[0].url;
                    updateData.resume_filename = updatedResumes[0].filename;
                } else {
                    updateData.resume_url = null;
                    updateData.resume_filename = null;
                }
            }

            await User.updateMyUserData(updateData);
            toast.success("Resume deleted successfully!");
            await fetchUserAndApplications();
        } catch (error) {
            console.error("Error deleting resume:", error);
            toast.error("Failed to delete resume. Please try again.");
        }
    };

    const setPrimaryResume = async (resumeId) => {
        try {
            const currentResumes = user?.resumes || [];
            const updatedResumes = currentResumes.map(resume => ({
                ...resume,
                is_primary: resume.id === resumeId
            }));

            const primaryResume = updatedResumes.find(r => r.is_primary);

            await User.updateMyUserData({
                resumes: updatedResumes,
                resume_url: primaryResume?.url,
                resume_filename: primaryResume?.filename
            });

            toast.success("Primary resume updated!");
            await fetchUserAndApplications();
        } catch (error) {
            console.error("Error setting primary resume:", error);
            toast.error("Failed to update primary resume.");
        }
    };

    const enhanceResume = async (resumeUrl) => {
        if (!resumeUrl) return;

        setIsEnhancing(true);
        try {
            const result = await InvokeLLM({
                prompt: `Analyze this resume and provide enhancement suggestions. Include:
                1. **Strengths**: What's working well
                2. **Areas for Improvement**: Specific suggestions
                3. **Keyword Optimization**: Industry-relevant keywords to add
                4. **Format Suggestions**: Ways to improve presentation
                5. **Achievement Quantification**: How to better showcase accomplishments

                Be specific and actionable in your recommendations.`,
                file_urls: [resumeUrl]
            });
            setEnhancedResume(result);
            toast.success("Resume analysis complete!");
        } catch (error) {
            console.error("Error enhancing resume:", error);
            setEnhancedResume("Sorry, I couldn't analyze your resume. Please try again.");
            toast.error("Failed to enhance resume. Please try again.");
        } finally {
            setIsEnhancing(false);
        }
    };

    const updateProfile = async () => {
        try {
            await User.updateMyUserData(profileData);
            toast.success("Profile updated successfully!");
            await fetchUserAndApplications();
        } catch (error) {
            toast.error("Failed to update profile. Please try again.");
            console.error("Error updating profile:", error);
        }
    };

    const addSkill = (skill) => {
        if (skill && !profileData.skills.includes(skill)) {
            setProfileData(prev => ({
                ...prev,
                skills: [...prev.skills, skill]
            }));
        }
    };

    const removeSkill = (skillToRemove) => {
        setProfileData(prev => ({
            ...prev,
            skills: prev.skills.filter(skill => skill !== skillToRemove)
        }));
    };

    const addEducation = () => {
        setProfileData(prev => ({
            ...prev,
            education: [...prev.education, { degree: '', institution: '', year: '' }]
        }));
    };

    const updateEducation = (index, field, value) => {
        setProfileData(prev => ({
            ...prev,
            education: prev.education.map((edu, i) =>
                i === index ? { ...edu, [field]: value } : edu
            )
        }));
    };

    const removeEducation = (index) => {
        setProfileData(prev => ({
            ...prev,
            education: prev.education.filter((_, i) => i !== index)
        }));
    };

    const addCertification = (cert) => {
        if (cert && !profileData.certifications.includes(cert)) {
            setProfileData(prev => ({
                ...prev,
                certifications: [...prev.certifications, cert]
            }));
        }
    };

    const removeCertification = (certToRemove) => {
        setProfileData(prev => ({
            ...prev,
            certifications: prev.certifications.filter(cert => cert !== certToRemove)
        }));
    };

    const handleLogout = async () => {
        try {
            await User.logout();
            // User will be redirected to login page automatically
        } catch (error) {
            console.error("Error logging out:", error);
            toast.error("Failed to logout. Please try again.");
        }
    };

    const handleDeleteAccount = async () => {
        if (deleteConfirmText !== 'DELETE') {
            toast.error('Please type "DELETE" to confirm account deletion.');
            return;
        }

        setIsDeleting(true);
        try {
            // Delete associated applications first
            if (applications && applications.length > 0) {
                const deletePromises = applications.map(app => Application.delete(app.id));
                await Promise.all(deletePromises);
                console.log("All user applications deleted.");
            }

            // Then delete user
            await User.delete(user.id);
            toast.success("Account deleted successfully!");
            await User.logout(); // Redirects to login
        } catch (error) {
            console.error("Error deleting account:", error);
            toast.error("Failed to delete account. Please try again.");
        } finally {
            setIsDeleting(false);
        }
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString();
    };

    // Calculate stats
    const totalApplications = applications.length;
    const responseRate = totalApplications > 0 ? Math.round((applications.filter(app => app.status !== 'applied').length / totalApplications) * 100) : 0;
    const interviewRate = totalApplications > 0 ? Math.round((applications.filter(app => app.status === 'interview_scheduled').length / totalApplications) * 100) : 0;

    if (isLoading) {
        return <div className="text-center p-10"><Loader2 className="w-8 h-8 animate-spin mx-auto" /></div>;
    }

    const CollapsibleSection = ({ title, icon: Icon, isExpanded, onToggle, children, badge, color = "text-gray-900" }) => (
        <Card className="mb-4">
            <CardHeader
                className="cursor-pointer hover:bg-gray-50 transition-colors p-4"
                onClick={onToggle}
            >
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <Icon className={`w-5 h-5 ${color}`} />
                        <CardTitle className={`text-lg ${color}`}>{title}</CardTitle>
                        {badge && badge}
                    </div>
                    {isExpanded ? (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                    ) : (
                        <ChevronRight className="w-5 h-5 text-gray-400" />
                    )}
                </div>
            </CardHeader>
            <AnimatePresence>
                {isExpanded && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        style={{ overflow: "hidden" }}
                    >
                        <CardContent className="pt-0">
                            {children}
                        </CardContent>
                    </motion.div>
                )}
            </AnimatePresence>
        </Card>
    );

    return (
        <div className="max-w-6xl mx-auto space-y-6 p-4 md:p-6">
            {/* Header with Avatar */}
            <div className="text-center mb-8">
                <div className="relative inline-block mb-4">
                    <Avatar className="w-32 h-32 mx-auto border-4 border-white shadow-lg">
                        <AvatarImage src={user?.avatar_url} alt={user?.full_name} />
                        <AvatarFallback className="text-3xl bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                            {user?.full_name?.split(' ').map(n => n[0]).join('') || 'U'}
                        </AvatarFallback>
                    </Avatar>
                    <Button
                        size="icon"
                        variant="outline"
                        className="absolute bottom-2 right-2 rounded-full w-8 h-8 bg-white border-2"
                        onClick={() => avatarInputRef.current?.click()}
                        disabled={isUploadingAvatar}
                    >
                        {isUploadingAvatar ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                            <Camera className="w-4 h-4" />
                        )}
                    </Button>
                    <input
                        type="file"
                        ref={avatarInputRef}
                        onChange={handleAvatarUpload}
                        className="hidden"
                        accept="image/*"
                    />
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{user?.full_name}</h1>
                <p className="text-gray-600">{user?.email}</p>
                <div className="flex items-center justify-center gap-3 mt-3">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                            const newVisibility = profileData.profile_visibility === 'public' ? 'private' : 'public';
                            setProfileData(prev => ({
                                ...prev,
                                profile_visibility: newVisibility
                            }));
                            // Auto-save the change
                            User.updateMyUserData({ profile_visibility: newVisibility });
                            toast.success(`Profile is now ${newVisibility}`);
                        }}
                        className={`flex items-center gap-2 transition-all ${
                            profileData.profile_visibility === 'public'
                                ? 'bg-green-50 border-green-300 text-green-700 hover:bg-green-100'
                                : 'bg-gray-50 border-gray-300 text-gray-700 hover:bg-gray-100'
                        }`}
                    >
                        <Globe2 className="w-4 h-4" />
                        {profileData.profile_visibility === 'public' ? 'Public Profile' : 'Private Profile'}
                    </Button>
                </div>
            </div>

            {/* Subscription Management - Condensed */}
            {currentSubscription && (
                <CollapsibleSection
                    title="Premium Subscription"
                    icon={Crown}
                    isExpanded={expandedSections.subscription}
                    onToggle={() => toggleSection('subscription')}
                    color="text-purple-600"
                    badge={
                        <Badge className={`text-xs ${currentSubscription.status === 'active' || currentSubscription.status === 'trial' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                            {currentSubscription.status === 'trial' ? 'Trial' : currentSubscription.status}
                        </Badge>
                    }
                >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
                        <div>
                            <h4 className="font-semibold text-purple-800">Premium Plan Active</h4>
                            <p className="text-sm text-gray-600">
                                {currentSubscription.status === 'cancelled'
                                    ? `Access ends ${new Date(currentSubscription.end_date).toLocaleDateString()}. You can reactivate anytime.`
                                    : `Renews ${new Date(currentSubscription.end_date).toLocaleDateString()}`
                                } • {currentSubscription.currency}{currentSubscription.price}/{currentSubscription.billing_cycle}
                            </p>
                        </div>
                        <div className="flex gap-2">
                            {currentSubscription.status !== 'cancelled' ? (
                                <Button variant="outline" size="sm" onClick={handleCancelSubscription} disabled={isCancelling}>
                                    {isCancelling ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <XCircle className="w-4 h-4 mr-2" />}
                                    Cancel Subscription
                                </Button>
                            ) : (
                                <Button variant="outline" size="sm" onClick={handleReactivateSubscription} disabled={isCancelling} className="text-green-700 border-green-300 hover:bg-green-50">
                                    {isCancelling ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                                    Reactivate
                                </Button>
                            )}
                        </div>
                    </div>
                </CollapsibleSection>
            )}

            {/* Career Dashboard Stats */}
            <CollapsibleSection
                title="Career Dashboard"
                icon={BarChart3}
                isExpanded={expandedSections.dashboard}
                onToggle={() => toggleSection('dashboard')}
                color="text-blue-600"
            >
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Card className="p-4">
                        <div className="flex items-center gap-2">
                            <Briefcase className="w-5 h-5 text-blue-500" />
                            <div>
                                <p className="text-2xl font-bold">{totalApplications}</p>
                                <p className="text-sm text-gray-600">Applications</p>
                            </div>
                        </div>
                    </Card>

                    <Card className="p-4">
                        <div className="flex items-center gap-2">
                            <Eye className="w-5 h-5 text-green-500" />
                            <div>
                                <p className="text-2xl font-bold">{responseRate}%</p>
                                <p className="text-sm text-gray-600">Response Rate</p>
                            </div>
                        </div>
                    </Card>

                    <Card className="p-4">
                        <div className="flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-purple-500" />
                            <div>
                                <p className="text-2xl font-bold">{interviewRate}%</p>
                                <p className="text-sm text-gray-600">Interview Rate</p>
                            </div>
                        </div>
                    </Card>

                    <Card className="p-4">
                        <div className="flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-orange-500" />
                            <div>
                                <p className="text-2xl font-bold">{applications.filter(app => app.status === 'offered').length}</p>
                                <p className="text-sm text-gray-600">Offers</p>
                            </div>
                        </div>
                    </Card>
                </div>
            </CollapsibleSection>

            {/* Resume Management */}
            <CollapsibleSection
                title="Resume Management"
                icon={FileText}
                isExpanded={expandedSections.resume}
                onToggle={() => toggleSection('resume')}
                color="text-green-600"
                badge={
                    <Badge variant="outline" className="text-xs">
                        {user?.resumes?.length || 0} files
                    </Badge>
                }
            >
                <div className="space-y-4">
                    <div className="flex justify-between items-center">
                        <h4 className="font-medium">Your Resumes</h4>
                        <Button onClick={() => fileInputRef.current.click()} disabled={isUploading} size="sm">
                            {isUploading ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Uploading...</>
                            ) : (
                                <><Plus className="w-4 h-4 mr-2"/> Add Resume</>
                            )}
                        </Button>
                    </div>

                    <Input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        className="hidden"
                        accept=".pdf,.doc,.docx"
                    />

                    <div className="space-y-3 max-h-96 overflow-y-auto">
                        {user?.resumes?.length > 0 ? (
                            user.resumes.map((resume) => (
                                <motion.div
                                    key={resume.id}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    className="border rounded-lg p-4 space-y-3"
                                >
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-start gap-3">
                                            <FileText className="w-5 h-5 text-blue-500 mt-0.5" />
                                            <div className="min-w-0">
                                                <div className="flex items-center gap-2">
                                                    <p className="font-medium text-sm truncate">{resume.filename}</p>
                                                    {resume.is_primary && (
                                                        <Badge className="bg-green-100 text-green-800 text-xs">
                                                            <Star className="w-3 h-3 mr-1" />
                                                            Primary
                                                        </Badge>
                                                    )}
                                                </div>
                                                <p className="text-xs text-gray-500">
                                                    {formatFileSize(resume.file_size)} • {formatDate(resume.upload_date)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="flex gap-1">
                                            <Button size="sm" variant="ghost" asChild>
                                                <a href={resume.url} target="_blank" rel="noopener noreferrer">
                                                    <Download className="w-3 h-3" />
                                                </a>
                                            </Button>
                                            <Button
                                                size="sm"
                                                variant="ghost"
                                                onClick={() => deleteResume(resume.id)}
                                                className="text-red-600 hover:text-red-700"
                                                disabled={user.resumes.length === 1}
                                            >
                                                <Trash2 className="w-3 h-3" />
                                            </Button>
                                        </div>
                                    </div>

                                    <div className="flex flex-wrap gap-2">
                                        {!resume.is_primary && (
                                            <Button
                                                size="sm"
                                                variant="outline"
                                                onClick={() => setPrimaryResume(resume.id)}
                                                className="text-xs h-7"
                                            >
                                                <Star className="w-3 h-3 mr-1" />
                                                Set Primary
                                            </Button>
                                        )}
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => enhanceResume(resume.url)}
                                            disabled={isEnhancing}
                                            className="text-xs h-7"
                                        >
                                            {isEnhancing ? (
                                                <><Loader2 className="w-3 h-3 mr-1 animate-spin"/> Analyzing...</>
                                            ) : (
                                                <><Sparkles className="w-3 h-3 mr-1"/> Enhance</>
                                            )}
                                        </Button>
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => extractProfileFromResume(resume.url)}
                                            disabled={isExtractingProfile}
                                            className="text-xs h-7"
                                        >
                                            {isExtractingProfile ? (
                                                <><Loader2 className="w-3 h-3 mr-1 animate-spin"/> Extracting...</>
                                            ) : (
                                                <><UserIcon className="w-3 h-3 mr-1"/> Extract Profile</>
                                            )}
                                        </Button>
                                    </div>
                                </motion.div>
                            ))
                        ) : (
                            <div className="text-center py-8 text-gray-500 border-2 border-dashed border-gray-200 rounded-lg">
                                <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
                                <p>No resumes uploaded yet</p>
                                <p className="text-sm">Upload your first resume to get started</p>
                            </div>
                        )}
                    </div>

                    {enhancedResume && (
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="border rounded-lg p-4 bg-blue-50 max-h-64 overflow-y-auto"
                        >
                            <h4 className="font-semibold mb-2 flex items-center gap-2">
                                <Sparkles className="w-4 h-4 text-blue-600" />
                                AI Enhancement Suggestions
                            </h4>
                            <div className="prose prose-sm max-w-none">
                                <ReactMarkdown>{enhancedResume}</ReactMarkdown>
                            </div>
                        </motion.div>
                    )}
                </div>
            </CollapsibleSection>

            {/* Profile Settings */}
            <CollapsibleSection
                title="Profile Settings"
                icon={Settings}
                isExpanded={expandedSections.profile}
                onToggle={() => toggleSection('profile')}
                color="text-indigo-600"
            >
                <div className="space-y-4">
                    <div className="space-y-3">
                        <div>
                            <label className="text-sm font-medium mb-1 block">Phone Number</label>
                            <div className="relative">
                                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                    type="tel"
                                    value={profileData.phone}
                                    onChange={(e) => setProfileData(prev => ({...prev, phone: e.target.value}))}
                                    placeholder="+1 (555) 123-4567"
                                    className="pl-10"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-1 block">Location</label>
                            <div className="relative">
                                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                    value={profileData.location}
                                    onChange={(e) => setProfileData(prev => ({...prev, location: e.target.value}))}
                                    placeholder="New York, NY"
                                    className="pl-10"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-1 block">LinkedIn URL (Optional)</label>
                            <div className="relative">
                                <Linkedin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input
                                    type="url"
                                    value={profileData.linkedin_url}
                                    onChange={(e) => setProfileData(prev => ({...prev, linkedin_url: e.target.value}))}
                                    placeholder="https://linkedin.com/in/yourprofile"
                                    className="pl-10"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-1 block">Professional Bio</label>
                            <Textarea
                                value={profileData.bio}
                                onChange={(e) => setProfileData(prev => ({...prev, bio: e.target.value}))}
                                placeholder="Brief professional summary..."
                                rows={3}
                            />
                        </div>
                    </div>
                    <Button onClick={updateProfile} className="w-full">
                        Save Profile Settings
                    </Button>
                </div>
            </CollapsibleSection>

            {/* Professional Information */}
            <CollapsibleSection
                title="Professional Information"
                icon={Briefcase}
                isExpanded={expandedSections.professional}
                onToggle={() => toggleSection('professional')}
                color="text-purple-600"
            >
                <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label className="text-sm font-medium mb-1 block">Experience (Years)</label>
                            <Input
                                type="number"
                                value={profileData.experience_years}
                                onChange={(e) => setProfileData(prev => ({...prev, experience_years: Number(e.target.value)}))}
                                placeholder="5"
                            />
                        </div>
                        <div>
                            <label className="text-sm font-medium mb-1 block">Preferred Job Type</label>
                            <Select
                                value={profileData.preferred_job_type}
                                onValueChange={(value) => setProfileData(prev => ({...prev, preferred_job_type: value}))}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Full-time">Full-time</SelectItem>
                                    <SelectItem value="Part-time">Part-time</SelectItem>
                                    <SelectItem value="Contract">Contract</SelectItem>
                                    <SelectItem value="Third-party">Third-party</SelectItem>
                                    <SelectItem value="Internship">Internship</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <label className="text-sm font-medium mb-1 block">Target Salary ($)</label>
                            <Input
                                type="number"
                                value={profileData.target_salary}
                                onChange={(e) => setProfileData(prev => ({...prev, target_salary: Number(e.target.value)}))}
                                placeholder="75000"
                            />
                        </div>
                    </div>

                    <div>
                        <label className="text-sm font-medium mb-1 block">Portfolio URL</label>
                        <Input
                            type="url"
                            value={profileData.portfolio_url}
                            onChange={(e) => setProfileData(prev => ({...prev, portfolio_url: e.target.value}))}
                            placeholder="https://myportfolio.com"
                        />
                    </div>

                    {/* Skills Section */}
                    <div>
                        <label className="text-sm font-medium mb-1 block">Skills</label>
                        <div className="flex flex-wrap gap-2 mb-2">
                            {profileData.skills.map((skill, index) => (
                                <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeSkill(skill)}>
                                    {skill} ×
                                </Badge>
                            ))}
                        </div>
                        <Input
                            placeholder="Add a skill and press Enter"
                            onKeyPress={(e) => {
                                if (e.key === 'Enter') {
                                    addSkill(e.target.value);
                                    e.target.value = '';
                                }
                            }}
                        />
                    </div>

                    {/* Education Section */}
                    <div>
                        <div className="flex items-center justify-between mb-2">
                            <label className="text-sm font-medium">Education</label>
                            <Button type="button" variant="outline" size="sm" onClick={addEducation}>
                                <GraduationCap className="w-4 h-4 mr-2" />
                                Add Education
                            </Button>
                        </div>
                        <div className="space-y-3">
                            {profileData.education.map((edu, index) => (
                                <div key={index} className="grid grid-cols-3 gap-2 p-3 border rounded-lg">
                                    <Input
                                        placeholder="Degree"
                                        value={edu.degree}
                                        onChange={(e) => updateEducation(index, 'degree', e.target.value)}
                                    />
                                    <Input
                                        placeholder="Institution"
                                        value={edu.institution}
                                        onChange={(e) => updateEducation(index, 'institution', e.target.value)}
                                    />
                                    <div className="flex gap-2">
                                        <Input
                                            placeholder="Year"
                                            value={edu.year}
                                            onChange={(e) => updateEducation(index, 'year', e.target.value)}
                                        />
                                        <Button
                                            type="button"
                                            variant="outline"
                                            size="icon"
                                            onClick={() => removeEducation(index)}
                                        >
                                            ×
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Certifications Section */}
                    <div>
                        <label className="text-sm font-medium mb-1 block">Certifications</label>
                        <div className="flex flex-wrap gap-2 mb-2">
                            {profileData.certifications.map((cert, index) => (
                                <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeCertification(cert)}>
                                    <Award className="w-3 h-3 mr-1" />
                                    {cert} ×
                                </Badge>
                            ))}
                        </div>
                        <Input
                            placeholder="Add a certification and press Enter"
                            onKeyPress={(e) => {
                                if (e.key === 'Enter') {
                                    addCertification(e.target.value);
                                    e.target.value = '';
                                }
                            }}
                        />
                    </div>

                    <Button onClick={updateProfile} className="w-full">
                        Save Professional Info
                    </Button>
                </div>
            </CollapsibleSection>

            {/* Recent Applications */}
            <CollapsibleSection
                title="Recent Applications"
                icon={FileUser}
                isExpanded={expandedSections.applications}
                onToggle={() => toggleSection('applications')}
                color="text-orange-600"
                badge={
                    <Badge variant="outline" className="text-xs">
                        {totalApplications} total
                    </Badge>
                }
            >
                {applications.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                        <Briefcase className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p>No applications yet. Start applying to jobs!</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {applications.slice(0, 10).map((app) => (
                            <div key={app.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 border rounded-lg">
                                <div className="mb-2 sm:mb-0">
                                    <h4 className="font-medium">{app.job_title}</h4>
                                    <p className="text-sm text-gray-600">{app.company}</p>
                                    <p className="text-xs text-gray-500">{app.application_date}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Badge variant={
                                        app.status === 'offered' ? 'default' :
                                        app.status === 'interview_scheduled' ? 'secondary' :
                                        app.status === 'rejected' ? 'destructive' : 'outline'
                                    }>
                                        {app.status.replace('_', ' ')}
                                    </Badge>
                                    {app.job_url && (
                                        <Button size="sm" variant="ghost" asChild>
                                            <a href={app.job_url} target="_blank" rel="noopener noreferrer">
                                                <ExternalLink className="w-4 h-4" />
                                            </a>
                                        </Button>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </CollapsibleSection>

            {/* Account Settings */}
            <CollapsibleSection
                title="Account Settings"
                icon={Settings}
                isExpanded={expandedSections.account}
                onToggle={() => toggleSection('account')}
                color="text-red-600"
            >
                <div className="space-y-3">
                    {/* Logout Section */}
                    <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                        <div className="flex items-center gap-3">
                            <LogOut className="w-5 h-5 text-gray-600" />
                            <div>
                                <h4 className="font-medium">Sign Out</h4>
                                <p className="text-sm text-gray-500">Log out of your account</p>
                            </div>
                        </div>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={handleLogout}
                        >
                            Logout
                        </Button>
                    </div>

                    {/* Delete Account Section */}
                    <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg hover:bg-red-50 transition-colors">
                        <div className="flex items-center gap-3">
                            <Trash2 className="w-5 h-5 text-red-500" />
                            <div>
                                <h4 className="font-medium text-red-700">Delete Account</h4>
                                <p className="text-sm text-red-600">Permanently remove your data</p>
                            </div>
                        </div>

                        {!showDeleteConfirmation ? (
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setShowDeleteConfirmation(true)}
                                className="border-red-300 text-red-600 hover:bg-red-50"
                            >
                                Delete
                            </Button>
                        ) : (
                            <div className="flex items-center gap-2">
                                <Input
                                    value={deleteConfirmText}
                                    onChange={(e) => setDeleteConfirmText(e.target.value)}
                                    placeholder="Type DELETE"
                                    className="w-24 h-8 text-xs border-red-300"
                                />
                                <Button
                                    variant="destructive"
                                    size="sm"
                                    onClick={handleDeleteAccount}
                                    disabled={isDeleting || deleteConfirmText !== 'DELETE'}
                                    className="h-8"
                                >
                                    {isDeleting ? (
                                        <Loader2 className="w-4 h-4 animate-spin" />
                                    ) : (
                                        'Confirm'
                                    )}
                                </Button>
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => {
                                        setShowDeleteConfirmation(false);
                                        setDeleteConfirmText('');
                                    }}
                                    disabled={isDeleting}
                                    className="h-8"
                                >
                                    Cancel
                                </Button>
                            </div>
                        )}
                    </div>
                </div>
            </CollapsibleSection>
        </div>
    );
}
