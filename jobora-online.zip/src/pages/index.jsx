import Layout from "./Layout.jsx";

import Home from "./Home";

import Profile from "./Profile";

import AIAssistant from "./AIAssistant";

import Messages from "./Messages";

import Notifications from "./Notifications";

import Settings from "./Settings";

import RecruiterChat from "./RecruiterChat";

import RoleSelection from "./RoleSelection";

import EmployerDashboard from "./EmployerDashboard";

import PostJob from "./PostJob";

import Applicants from "./Applicants";

import EmployerProfile from "./EmployerProfile";

import EmployerMessages from "./EmployerMessages";

import EmployerNotifications from "./EmployerNotifications";

import HomePage from "./HomePage";

import AdminScraper from "./AdminScraper";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Profile: Profile,
    
    AIAssistant: AIAssistant,
    
    Messages: Messages,
    
    Notifications: Notifications,
    
    Settings: Settings,
    
    RecruiterChat: RecruiterChat,
    
    RoleSelection: RoleSelection,
    
    EmployerDashboard: EmployerDashboard,
    
    PostJob: PostJob,
    
    Applicants: Applicants,
    
    EmployerProfile: EmployerProfile,
    
    EmployerMessages: EmployerMessages,
    
    EmployerNotifications: EmployerNotifications,
    
    HomePage: HomePage,
    
    AdminScraper: AdminScraper,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/AIAssistant" element={<AIAssistant />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/RecruiterChat" element={<RecruiterChat />} />
                
                <Route path="/RoleSelection" element={<RoleSelection />} />
                
                <Route path="/EmployerDashboard" element={<EmployerDashboard />} />
                
                <Route path="/PostJob" element={<PostJob />} />
                
                <Route path="/Applicants" element={<Applicants />} />
                
                <Route path="/EmployerProfile" element={<EmployerProfile />} />
                
                <Route path="/EmployerMessages" element={<EmployerMessages />} />
                
                <Route path="/EmployerNotifications" element={<EmployerNotifications />} />
                
                <Route path="/HomePage" element={<HomePage />} />
                
                <Route path="/AdminScraper" element={<AdminScraper />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}