import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, DownloadCloud, CheckCircle, AlertTriangle } from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';
import { Job } from '@/api/entities';
import { toast } from 'sonner';

export default function AdminScraperPage() {
    const [isLoading, setIsLoading] = useState(false);
    const [importResult, setImportResult] = useState(null);

    const handleImport = async () => {
        setIsLoading(true);
        setImportResult(null);
        toast.info("Starting job import... The AI is reading the website, this may take a moment.");

        try {
            const result = await InvokeLLM({
                add_context_from_internet: true,
                prompt: `Analyze the content of the website https://jobora.online and extract all available job listings. For each job, provide its title, company name, location, a brief description, and the direct URL to the job details page.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        jobs: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    title: { type: "string" },
                                    company: { type: "string" },
                                    location: { type: "string" },
                                    description: { type: "string" },
                                    url: { type: "string", format: "uri" }
                                },
                                required: ["title", "company", "location", "description", "url"]
                            }
                        }
                    },
                    required: ["jobs"]
                }
            });

            if (!result || !result.jobs || result.jobs.length === 0) {
                throw new Error("The AI could not find any jobs on the specified website.");
            }

            const jobsToCreate = result.jobs.map(scrapedJob => ({
                ...scrapedJob,
                source: 'Jobora.online (Scraped)',
                is_external: true,
                is_internal: false,
                status: 'active',
                easy_apply_enabled: false,
            }));

            await Job.bulkCreate(jobsToCreate);
            
            setImportResult({ success: true, count: jobsToCreate.length });
            toast.success(`Successfully imported ${jobsToCreate.length} jobs!`);

        } catch (error) {
            console.error("Job import failed:", error);
            setImportResult({ success: false, message: error.message });
            toast.error("Job import failed", {
                description: "The AI could not extract jobs. The site structure may have changed or it might be temporarily unavailable.",
            });
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-2xl mx-auto">
            <Card>
                <CardHeader>
                    <CardTitle>Job Importer</CardTitle>
                    <CardDescription>
                        Use our AI-powered tool to pull job listings from external websites and add them to your database.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="p-4 border rounded-lg bg-gray-50">
                        <h4 className="font-semibold text-gray-800">Target Website:</h4>
                        <a href="https://jobora.online" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                            https://jobora.online
                        </a>
                    </div>
                    
                    <Button onClick={handleImport} disabled={isLoading} className="w-full">
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Importing... Please Wait
                            </>
                        ) : (
                            <>
                                <DownloadCloud className="mr-2 h-4 w-4" />
                                Start Import
                            </>
                        )}
                    </Button>

                    {importResult && (
                        <div className={`p-4 rounded-md flex items-start gap-3 ${importResult.success ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
                            {importResult.success ? <CheckCircle className="h-5 w-5 mt-0.5" /> : <AlertTriangle className="h-5 w-5 mt-0.5" />}
                            <div>
                                <h5 className="font-semibold">{importResult.success ? 'Import Successful' : 'Import Failed'}</h5>
                                <p className="text-sm">
                                    {importResult.success 
                                        ? `Added ${importResult.count} new jobs to the database. They are now live.`
                                        : `Error: ${importResult.message}`
                                    }
                                </p>
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}