
import React, { useState, useEffect } from 'react';
import { Job } from '@/api/entities';
import { User } from '@/api/entities';
import { Subscription } from '@/api/entities';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Search, X, MapPin, Briefcase, Crown, AlertCircle, TrendingUp, Clock, Filter } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';

import JobDetails from '../components/JobDetails';
import JobFilters from '../components/JobFilters';
import DirectRecruiterJobs from '../components/DirectRecruiterJobs';
import SubscriptionBanner from '../components/SubscriptionBanner';

// Source logos
const sourceLogos = {
    
};

export default function HomePage() {
    const [searchTerm, setSearchTerm] = useState('');
    const [searchLocation, setSearchLocation] = useState('');
    const [jobs, setJobs] = useState([]);
    const [selectedJob, setSelectedJob] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [searchError, setSearchError] = useState(null);
    const [searchExpanded, setSearchExpanded] = useState(false);
    const [locationExpanded, setLocationExpanded] = useState(false);
    const [isFiltersOpen, setIsFiltersOpen] = useState(false);
    const [recentSearches, setRecentSearches] = useState([]);
    const [suggestions, setSuggestions] = useState([]);
    const [locationSuggestions, setLocationSuggestions] = useState([]);
    const [currentUser, setCurrentUser] = useState(null);
    const [isSubscribed, setIsSubscribed] = useState(false);

    const navigate = useNavigate();
    const location = useLocation();

    // Default job search suggestions
    const defaultJobSuggestions = [
        'Software Engineer', 'Product Manager', 'Data Scientist', 'UX Designer',
        'Frontend Developer', 'Backend Developer', 'DevOps Engineer', 'Marketing Manager',
        'Sales Representative', 'Business Analyst', 'Project Manager', 'Full Stack Developer'
    ];

    // Default location suggestions
    const defaultLocationSuggestions = [
        'New York, NY', 'San Francisco, CA', 'Los Angeles, CA', 'Chicago, IL',
        'Austin, TX', 'Seattle, WA', 'Boston, MA', 'Denver, CO', 
        'Remote', 'Hybrid', 'Atlanta, GA', 'Miami, FL'
    ];

    const [filters, setFilters] = useState({
        job_type: 'all',
        experience_level: 'all'
    });

    useEffect(() => {
        loadInitialData();
        loadRecentSearches();
        generateSmartSuggestions();
    }, []);

    const loadInitialData = async () => {
        setIsLoading(true);
        try {
            const user = await User.me();
            setCurrentUser(user);

            if (user) {
                const subscriptions = await Subscription.filter({ created_by: user.email }, '-created_date', 1);
                const hasActiveSub = subscriptions.some(s => ['active', 'trial'].includes(s.status));
                setIsSubscribed(hasActiveSub);
            }
            
            await loadDiverseJobs();
            
        } catch (error) {
            console.error("Error loading initial data:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const generateSmartSuggestions = async () => {
        try {
            // Get user's skills and experience to generate personalized suggestions
            const user = await User.me();
            if (user?.skills?.length > 0) {
                const skillBasedSuggestions = user.skills.slice(0, 4).map(skill => 
                    `${skill} Developer`
                );
                setSuggestions([...new Set([...skillBasedSuggestions, ...defaultJobSuggestions.slice(0, 8)])]);
            } else {
                setSuggestions(defaultJobSuggestions.slice(0, 12));
            }
            
            setLocationSuggestions(defaultLocationSuggestions);
        } catch (error) {
            console.error("Error generating smart suggestions:", error);
            setSuggestions(defaultJobSuggestions.slice(0, 12));
            setLocationSuggestions(defaultLocationSuggestions);
        }
    };

    const loadDiverseJobs = async () => {
        setIsLoading(true);
        try {
            console.log("Starting to load jobs...");
            
            // Try to load all available jobs with active status
            const allJobs = await Job.filter({ status: 'active' }, '-created_date', 100);
            console.log("Loaded jobs:", allJobs.length, allJobs);
            
            if (allJobs.length === 0) {
                console.log("No active jobs found, trying to load all jobs...");
                // If no active jobs, try loading all jobs
                const allJobsAnyStatus = await Job.list('-created_date', 100);
                console.log("All jobs (any status):", allJobsAnyStatus.length);
                
                if (allJobsAnyStatus.length === 0) {
                    setJobs([]);
                    setSearchError("No job postings found. Click 'Load Sample Jobs' to add some test data.");
                    return;
                } else {
                    const jobsWithLogos = allJobsAnyStatus.map(job => ({
                        ...job,
                        source_logo: sourceLogos[job.source] || `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${job.source?.charAt(0) || 'J'}`
                    }));
                    setJobs(jobsWithLogos);
                    if (jobsWithLogos.length > 0) {
                        setSelectedJob(jobsWithLogos[0]);
                    }
                    setSearchError(null);
                    return;
                }
            }
            
            const jobsWithLogos = allJobs.map(job => ({
                ...job,
                source_logo: sourceLogos[job.source] || `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${job.source?.charAt(0) || 'J'}`
            }));

            setJobs(jobsWithLogos);
            if (jobsWithLogos.length > 0) {
                setSelectedJob(jobsWithLogos[0]);
            }
            setSearchError(null);
            
        } catch (error) {
            console.error("Error loading jobs:", error);
            setJobs([]);
            setSearchError(`Failed to load jobs: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    const createSampleJobs = async () => {
        setIsLoading(true);
        setSearchError(null);
        try {
            console.log("Creating sample jobs...");
            
            const sampleJobs = [
                {
                    title: "Senior Software Engineer",
                    company: "TechCorp Solutions",
                    location: "San Francisco, CA",
                    description: "We're looking for a passionate Senior Software Engineer to join our growing team. You'll work on cutting-edge applications using React, Node.js, and AWS.",
                    url: "https://techcorp.com/careers/senior-software-engineer",
                    source: "LinkedIn",
                    job_type: "Full-time",
                    salary_range: "$120k - $160k",
                    status: "active",
                    is_internal: false,
                    is_external: true,
                    easy_apply_enabled: false
                },
                {
                    title: "Product Manager",
                    company: "StartupXYZ",
                    location: "New York, NY", 
                    description: "Join our fast-growing startup as a Product Manager. Lead product strategy, work with engineering teams, and drive user growth.",
                    url: "https://startupxyz.com/jobs/product-manager",
                    source: "Indeed",
                    job_type: "Full-time",
                    salary_range: "$100k - $140k",
                    status: "active",
                    is_internal: false,
                    is_external: true,
                    easy_apply_enabled: false
                },
                {
                    title: "UX Designer",
                    company: "Design Studio Pro",
                    location: "Remote",
                    description: "Creative UX Designer needed for remote position. Design user interfaces for web and mobile applications.",
                    url: "https://designstudiopro.com/careers/ux-designer",
                    source: "Glassdoor",
                    job_type: "Full-time",
                    salary_range: "$80k - $110k",
                    status: "active",
                    is_internal: false,
                    is_external: true,
                    easy_apply_enabled: false
                },
                {
                    title: "Frontend Developer",
                    company: "WebDev Agency",
                    location: "Austin, TX",
                    description: "Frontend Developer role focusing on React and TypeScript. Build responsive web applications.",
                    url: "https://webdevagency.com/careers/frontend-developer",
                    source: "Monster",
                    job_type: "Full-time",
                    salary_range: "$75k - $100k",
                    status: "active",
                    is_internal: false,
                    is_external: true,
                    easy_apply_enabled: false
                },
                {
                    title: "Data Scientist",
                    company: "AI Innovations Inc",
                    location: "Boston, MA",
                    description: "Data Scientist position focusing on machine learning and predictive analytics. Python and SQL experience required.",
                    url: "https://aiinnovations.com/jobs/data-scientist",
                    source: "LinkedIn",
                    job_type: "Full-time",
                    salary_range: "$110k - $150k",
                    status: "active",
                    is_internal: false,
                    is_external: true,
                    easy_apply_enabled: false
                }
            ];

            for (const jobData of sampleJobs) {
                try {
                    console.log("Creating job:", jobData.title);
                    await Job.create(jobData);
                    console.log("Successfully created:", jobData.title);
                } catch (error) {
                    console.error("Error creating job:", jobData.title, error);
                }
            }
            
            console.log("Finished creating sample jobs, reloading...");
            await loadDiverseJobs();
            
        } catch (error) {
            console.error("Error creating sample jobs:", error);
            setSearchError(`Failed to create sample jobs: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    const handleSearch = async (e) => {
        e.preventDefault();
        setIsSearching(true);
        setSearchError(null);
        setSearchExpanded(false);
        setLocationExpanded(false);

        if (!searchTerm && !searchLocation && filters.job_type === 'all' && filters.experience_level === 'all') {
            await loadDiverseJobs();
            setIsSearching(false);
            return;
        }

        const query = {};

        if (searchTerm) {
            query.title = searchTerm;
        }
        if (searchLocation) {
            query.location = searchLocation;
        }

        if (filters.job_type !== 'all') {
            query.job_type = filters.job_type;
        }
        if (filters.experience_level !== 'all') {
            query.experience_level = filters.experience_level;
        }

        try {
            const searchResults = await Job.filter(query, '-created_date', 50);
            
            const jobsWithLogos = searchResults.map(job => ({
                ...job,
                source_logo: sourceLogos[job.source] || `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${job.source?.charAt(0) || 'J'}`
            }));
            
            setJobs(jobsWithLogos);
            if (jobsWithLogos.length > 0) {
                setSelectedJob(jobsWithLogos[0]);
                setSearchError(null);
            } else {
                setSelectedJob(null);
                setSearchError("No jobs found matching your criteria. Try different keywords or clear filters.");
            }
            saveRecentSearch(searchTerm, searchLocation);
        } catch (error) {
            console.error("Error searching jobs:", error);
            setJobs([]);
            setSelectedJob(null);
            setSearchError("An error occurred during search. Please try again.");
        } finally {
            setIsSearching(false);
        }
    };

    const handleJobClick = (job) => {
        setSelectedJob(job);
    };

    const clearSearch = () => {
        setSearchTerm('');
        setSearchLocation('');
        setSearchError(null);
        setSearchExpanded(false);
        setLocationExpanded(false);
        setFilters({ job_type: 'all', experience_level: 'all' });
        loadDiverseJobs();
    };

    const saveRecentSearch = (term, location) => {
        if (!term && !location) return;
        const newSearch = { term, location, timestamp: new Date().toISOString() };
        let updatedSearches = [newSearch, ...recentSearches.filter(s => !(s.term === term && s.location === location))];
        updatedSearches = updatedSearches.slice(0, 5);
        setRecentSearches(updatedSearches);
        localStorage.setItem('recentSearches', JSON.stringify(updatedSearches));
    };

    const loadRecentSearches = () => {
        const storedSearches = localStorage.getItem('recentSearches');
        if (storedSearches) {
            setRecentSearches(JSON.parse(storedSearches));
        }
    };

    const handleJobSearchFocus = () => {
        setSearchExpanded(true);
        setLocationExpanded(false);
    };

    const handleLocationSearchFocus = () => {
        setLocationExpanded(true);
        setSearchExpanded(false);
    };

    const handleSuggestionClick = (suggestion) => {
        setSearchTerm(suggestion);
        setSearchExpanded(false);
        if (searchLocation || suggestion) {
            setTimeout(() => {
                const form = document.querySelector('form');
                if (form) {
                    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                }
            }, 100);
        }
    };

    const handleLocationSuggestionClick = (location) => {
        setSearchLocation(location);
        setLocationExpanded(false);
        if (searchTerm || location) {
            setTimeout(() => {
                const form = document.querySelector('form');
                if (form) {
                    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                }
            }, 100);
        }
    };

    const handleApplyFilters = async (newFilters) => {
        setFilters(newFilters);
        setIsFiltersOpen(false);
        
        setIsSearching(true);
        setSearchError(null);
        
        const query = {};
        if (searchTerm) query.title = searchTerm;
        if (searchLocation) query.location = searchLocation;
        if (newFilters.job_type !== 'all') query.job_type = newFilters.job_type;
        if (newFilters.experience_level !== 'all') query.experience_level = newFilters.experience_level;
        
        try {
            const searchResults = await Job.filter(query, '-created_date', 50);
            const jobsWithLogos = searchResults.map(job => ({
                ...job,
                source_logo: sourceLogos[job.source] || `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${job.source?.charAt(0) || 'J'}`
            }));
            setJobs(jobsWithLogos);
            if (jobsWithLogos.length > 0) {
                setSelectedJob(jobsWithLogos[0]);
            } else {
                setSelectedJob(null);
                setSearchError("No jobs found matching your criteria.");
            }
        } catch (error) {
            console.error("Error applying filters:", error);
            setJobs([]);
            setSelectedJob(null);
            setSearchError("An error occurred while applying filters.");
        } finally {
            setIsSearching(false);
        }
    };

    const highlightMatch = (text, term) => {
        if (!term) return text;
        const parts = text.split(new RegExp(`(${term})`, 'gi'));
        return (
            <span>
                {parts.map((part, i) =>
                    part.toLowerCase() === term.toLowerCase() ? <strong key={i}>{part}</strong> : part
                )}
            </span>
        );
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {!isSubscribed && currentUser && (
                <SubscriptionBanner currentUser={currentUser} />
            )}

            <header className="bg-white shadow-sm p-4 sticky top-0 z-20">
                <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center gap-4">
                    <form onSubmit={handleSearch} className="flex flex-col sm:flex-row w-full gap-3">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                            <Input
                                type="text"
                                placeholder="Job title, keywords, or company"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                onFocus={handleJobSearchFocus}
                                className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            />
                            {searchTerm && (
                                <button
                                    type="button"
                                    onClick={() => setSearchTerm('')}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                >
                                    <X size={18} />
                                </button>
                            )}

                            <AnimatePresence>
                                {searchExpanded && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        transition={{ duration: 0.1 }}
                                        className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-64 overflow-y-auto z-20"
                                    >
                                        {recentSearches.length > 0 && (
                                            <div className="p-3 border-b border-gray-100">
                                                <p className="text-xs font-medium text-gray-500 mb-2">Recent Searches</p>
                                                {recentSearches.slice(0, 3).map((searchItem, index) => (
                                                    <button
                                                        key={index}
                                                        type="button"
                                                        onClick={() => handleSuggestionClick(searchItem.term)}
                                                        className="flex items-center gap-2 w-full text-left px-2 py-1 hover:bg-gray-50 rounded text-sm"
                                                    >
                                                        <Clock className="w-3 h-3 text-gray-400" />
                                                        {searchItem.term} {searchItem.location && `(${searchItem.location})`}
                                                    </button>
                                                ))}
                                            </div>
                                        )}
                                        <div className="p-3">
                                            <p className="text-xs font-medium text-gray-500 mb-2">Popular Jobs</p>
                                            {suggestions.map((suggestion, index) => (
                                                <button
                                                    key={index}
                                                    type="button"
                                                    onClick={() => handleSuggestionClick(suggestion)}
                                                    className="flex items-center gap-2 w-full text-left px-2 py-1 hover:bg-gray-50 rounded text-sm"
                                                >
                                                    <TrendingUp className="w-3 h-3 text-green-500" />
                                                    {suggestion}
                                                </button>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>

                        <div className="relative flex-1">
                            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                            <Input
                                type="text"
                                placeholder="Location (e.g., New York, Remote)"
                                value={searchLocation}
                                onChange={(e) => setSearchLocation(e.target.value)}
                                onFocus={handleLocationSearchFocus}
                                className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            />
                            {searchLocation && (
                                <button
                                    type="button"
                                    onClick={() => setSearchLocation('')}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                >
                                    <X size={18} />
                                </button>
                            )}

                            <AnimatePresence>
                                {locationExpanded && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        transition={{ duration: 0.1 }}
                                        className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-64 overflow-y-auto z-20"
                                    >
                                        <div className="p-3">
                                            <p className="text-xs font-medium text-gray-500 mb-2">Popular Locations</p>
                                            {locationSuggestions.map((loc, index) => (
                                                <button
                                                    key={index}
                                                    type="button"
                                                    onClick={() => handleLocationSuggestionClick(loc)}
                                                    className="flex items-center gap-2 w-full text-left px-2 py-1 hover:bg-gray-50 rounded text-sm"
                                                >
                                                    <MapPin className="w-3 h-3 text-blue-500" />
                                                    {loc}
                                                </button>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>

                        <Button type="submit" className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md flex items-center justify-center" disabled={isSearching}>
                            {isSearching ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                            Search
                        </Button>
                        <Sheet open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
                            <SheetTrigger asChild>
                                <Button variant="outline" className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md flex items-center justify-center">
                                    <Filter className="mr-2 h-4 w-4" /> Filters
                                </Button>
                            </SheetTrigger>
                            <SheetContent className="w-[350px] sm:w-[400px]">
                                <SheetHeader>
                                    <SheetTitle>Filter Jobs</SheetTitle>
                                    <SheetDescription>
                                        Refine your search to find the perfect job.
                                    </SheetDescription>
                                </SheetHeader>
                                <JobFilters 
                                    initialFilters={filters}
                                    onApplyFilters={handleApplyFilters}
                                    isSubscribed={isSubscribed}
                                />
                            </SheetContent>
                        </Sheet>
                        {(searchTerm || searchLocation || filters.job_type !== 'all' || filters.experience_level !== 'all') && (
                            <Button type="button" variant="ghost" onClick={clearSearch} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md flex items-center justify-center">
                                <X className="mr-2 h-4 w-4" /> Clear
                            </Button>
                        )}
                    </form>
                </div>

                {(searchExpanded || locationExpanded) && (
                    <div 
                        className="fixed inset-0 z-10" 
                        onClick={() => {
                            setSearchExpanded(false);
                            setLocationExpanded(false);
                        }}
                    />
                )}
            </header>

            <main className="flex-1 max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row gap-6 w-full">
                <div className="w-full lg:w-1/4 space-y-6 hidden lg:block">
                    {currentUser && jobs.length > 0 && <DirectRecruiterJobs jobs={jobs} onJobSelect={handleJobClick} />}
                </div>

                <div className="w-full lg:w-3/5 flex flex-col lg:flex-row gap-6">
                    <div className="w-full lg:w-2/5 xl:w-1/2 bg-white rounded-lg shadow-md p-4 overflow-y-auto max-h-[calc(100vh-160px)]">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xl font-bold text-gray-800">Job Listings</h2>
                            <Badge variant="outline" className="text-xs">
                                {jobs.length} jobs
                            </Badge>
                        </div>
                        
                        {isLoading ? (
                            <div className="flex justify-center items-center h-64">
                                <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
                                <span className="ml-2 text-gray-600">Loading jobs...</span>
                            </div>
                        ) : searchError ? (
                            <div className="text-center py-8 text-red-500 flex flex-col items-center">
                                <AlertCircle className="h-12 w-12 mb-2" />
                                <p className="text-lg font-semibold">{searchError}</p>
                                <div className="flex gap-2 mt-4">
                                    <Button onClick={loadDiverseJobs} variant="outline" disabled={isLoading}>
                                        {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                                        Refresh Jobs
                                    </Button>
                                    <Button onClick={createSampleJobs} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={isLoading}>
                                        {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                                        Load Sample Jobs
                                    </Button>
                                </div>
                            </div>
                        ) : jobs.length === 0 ? (
                            <div className="text-center py-8 text-gray-500 flex flex-col items-center">
                                <Search className="h-12 w-12 mb-2" />
                                <p className="text-lg font-semibold">No jobs available</p>
                                <p className="text-sm mb-4">Let's add some sample jobs to get started!</p>
                                <Button onClick={createSampleJobs} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={isLoading}>
                                    {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                                    Load Sample Jobs
                                </Button>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {jobs.map((job) => (
                                    <Card
                                        key={job.id}
                                        className={`cursor-pointer hover:shadow-lg transition-shadow duration-200 ${selectedJob?.id === job.id ? 'border-2 border-indigo-500 bg-indigo-50' : 'border border-gray-200'}`}
                                        onClick={() => handleJobClick(job)}
                                    >
                                        <CardContent className="p-4">
                                            <div className="flex items-start mb-2">
                                                <img src={job.source_logo} alt={job.source} className="w-6 h-6 mr-3 object-contain rounded" />
                                                <div className="flex-1 min-w-0">
                                                    <h3 className="text-lg font-semibold text-gray-900 truncate">{highlightMatch(job.title, searchTerm)}</h3>
                                                    <p className="text-sm text-gray-600 truncate">{job.company}</p>
                                                </div>
                                            </div>
                                            <div className="flex items-center text-gray-500 text-sm mb-2">
                                                <MapPin className="mr-1 flex-shrink-0" size={16} /> 
                                                <span className="truncate">{highlightMatch(job.location, searchLocation)}</span>
                                                <Briefcase className="ml-4 mr-1 flex-shrink-0" size={16} /> 
                                                <span className="truncate">{job.job_type}</span>
                                            </div>
                                            <div className="flex flex-wrap gap-2 mb-3">
                                                {job.has_direct_contact && (
                                                    <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                                                        <Crown className="w-3 h-3 mr-1" />
                                                        Direct Contact
                                                    </Badge>
                                                )}
                                                {job.salary_range && (
                                                    <Badge variant="outline" className="bg-green-100 text-green-700 text-xs">
                                                        {job.salary_range}
                                                    </Badge>
                                                )}
                                            </div>
                                            <p className="text-sm text-gray-700 line-clamp-2">{job.description}</p>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className="w-full lg:w-3/5 xl:w-1/2 bg-white rounded-lg shadow-md overflow-hidden">
                        {selectedJob ? (
                            <JobDetails job={selectedJob} sourceLogos={sourceLogos} currentUser={currentUser} isSubscribed={isSubscribed} />
                        ) : (
                            <div className="flex items-center justify-center h-full text-gray-500">
                                {isLoading ? (
                                    <Loader2 className="h-12 w-12 animate-spin text-indigo-600" />
                                ) : (
                                    <div className="text-center">
                                        <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                                        <p className="text-lg">Select a job to view details</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
}
