import React, { useState, useEffect } from 'react';
import { Notification } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Bell, BellOff, Briefcase, MessageSquare, Users, Award, TrendingUp, Trash2, Settings } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function EmployerNotificationsPage() {
    const [notifications, setNotifications] = useState([]);
    const [settings, setSettings] = useState({
        newApplications: true,
        messages: true,
        jobViews: true,
        badgeEarned: true,
        milestones: true,
        emailNotifications: true
    });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadNotifications();
    }, []);

    const loadNotifications = async () => {
        setIsLoading(true);
        try {
            const user = await User.me();
            const userNotifications = await Notification.filter({ user_email: user.email }, '-created_date');
            setNotifications(userNotifications);
        } catch (error) {
            console.error("Error loading notifications:", error);
            toast.error("Failed to load notifications");
        } finally {
            setIsLoading(false);
        }
    };

    const markAsRead = async (id) => {
        try {
            await Notification.update(id, { is_read: true });
            setNotifications(prev => 
                prev.map(notif => 
                    notif.id === id ? { ...notif, is_read: true } : notif
                )
            );
        } catch (error) {
            console.error("Error marking notification as read:", error);
        }
    };

    const deleteNotification = async (id) => {
        try {
            await Notification.delete(id);
            setNotifications(prev => prev.filter(notif => notif.id !== id));
            toast.success('Notification deleted');
        } catch (error) {
            console.error("Error deleting notification:", error);
            toast.error("Failed to delete notification");
        }
    };

    const markAllAsRead = async () => {
        try {
            const unreadNotifications = notifications.filter(n => !n.is_read);
            for (const notif of unreadNotifications) {
                await Notification.update(notif.id, { is_read: true });
            }
            setNotifications(prev => prev.map(notif => ({ ...notif, is_read: true })));
            toast.success('All notifications marked as read');
        } catch (error) {
            console.error("Error marking all as read:", error);
            toast.error("Failed to mark all as read");
        }
    };

    const updateSetting = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
        toast.success('Notification settings updated');
    };

    const getNotificationIcon = (type) => {
        switch (type) {
            case 'new_application': return Users;
            case 'new_message': return MessageSquare;
            case 'job_viewed': return TrendingUp;
            case 'badge_earned': return Award;
            case 'milestone': return TrendingUp;
            default: return Bell;
        }
    };

    const getTypeColor = (type) => {
        switch (type) {
            case 'new_application': return 'bg-green-100 text-green-800';
            case 'new_message': return 'bg-blue-100 text-blue-800';
            case 'job_viewed': return 'bg-purple-100 text-purple-800';
            case 'badge_earned': return 'bg-yellow-100 text-yellow-800';
            case 'milestone': return 'bg-orange-100 text-orange-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const unreadCount = notifications.filter(n => !n.is_read).length;

    if (isLoading) {
        return <div className="text-center p-10">Loading notifications...</div>;
    }

    return (
        <div className="min-h-screen bg-gray-50 p-4">
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
                        {unreadCount > 0 && (
                            <Badge className="bg-red-100 text-red-800">
                                {unreadCount} unread
                            </Badge>
                        )}
                    </div>
                    <Button onClick={markAllAsRead} variant="outline">
                        Mark all as read
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Notifications List */}
                    <div className="lg:col-span-2 space-y-3">
                        {notifications.length > 0 ? (
                            notifications.map((notif) => {
                                const IconComponent = getNotificationIcon(notif.type);
                                return (
                                    <motion.div
                                        key={notif.id}
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                    >
                                        <Card className={`${notif.is_read ? 'opacity-75' : ''} hover:shadow-md transition-shadow`}>
                                            <CardContent className="p-4">
                                                <div className="flex items-start justify-between">
                                                    <div className="flex items-start gap-3">
                                                        <div className={`p-2 rounded-lg ${getTypeColor(notif.type)}`}>
                                                            <IconComponent className="w-4 h-4" />
                                                        </div>
                                                        <div className="flex-1">
                                                            <h3 className={`font-medium ${notif.is_read ? 'text-gray-600' : 'text-gray-900'}`}>
                                                                {notif.title}
                                                            </h3>
                                                            <p className="text-sm text-gray-600 mt-1">{notif.message}</p>
                                                            <span className="text-xs text-gray-400 mt-2 block">
                                                                {new Date(notif.created_date).toLocaleString()}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        {!notif.is_read && (
                                                            <Button
                                                                size="sm"
                                                                variant="ghost"
                                                                onClick={() => markAsRead(notif.id)}
                                                            >
                                                                Mark as read
                                                            </Button>
                                                        )}
                                                        <Button
                                                            size="sm"
                                                            variant="ghost"
                                                            onClick={() => deleteNotification(notif.id)}
                                                            className="text-red-600 hover:text-red-700"
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    </motion.div>
                                );
                            })
                        ) : (
                            <Card>
                                <CardContent className="p-8 text-center">
                                    <BellOff className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                                    <p className="text-gray-500">No notifications yet</p>
                                    <p className="text-sm text-gray-400 mt-1">You'll be notified about applications, messages, and achievements</p>
                                </CardContent>
                            </Card>
                        )}
                    </div>

                    {/* Settings Panel */}
                    <div className="lg:col-span-1">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Settings className="w-5 h-5" />
                                    Notification Settings
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">New Applications</p>
                                            <p className="text-sm text-gray-500">When someone applies to your jobs</p>
                                        </div>
                                        <Switch
                                            checked={settings.newApplications}
                                            onCheckedChange={(checked) => updateSetting('newApplications', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Messages</p>
                                            <p className="text-sm text-gray-500">New messages from job seekers</p>
                                        </div>
                                        <Switch
                                            checked={settings.messages}
                                            onCheckedChange={(checked) => updateSetting('messages', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Job Views</p>
                                            <p className="text-sm text-gray-500">When your jobs get viewed</p>
                                        </div>
                                        <Switch
                                            checked={settings.jobViews}
                                            onCheckedChange={(checked) => updateSetting('jobViews', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Badge Earned</p>
                                            <p className="text-sm text-gray-500">Achievement notifications</p>
                                        </div>
                                        <Switch
                                            checked={settings.badgeEarned}
                                            onCheckedChange={(checked) => updateSetting('badgeEarned', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Milestones</p>
                                            <p className="text-sm text-gray-500">Important milestones</p>
                                        </div>
                                        <Switch
                                            checked={settings.milestones}
                                            onCheckedChange={(checked) => updateSetting('milestones', checked)}
                                        />
                                    </div>
                                    
                                    <div className="border-t pt-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Email Notifications</p>
                                                <p className="text-sm text-gray-500">Receive via email</p>
                                            </div>
                                            <Switch
                                                checked={settings.emailNotifications}
                                                onCheckedChange={(checked) => updateSetting('emailNotifications', checked)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}