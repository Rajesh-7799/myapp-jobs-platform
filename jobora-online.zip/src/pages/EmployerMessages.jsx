import React, { useState, useEffect } from 'react';
import { Message } from '@/api/entities';
import { User } from '@/api/entities';
import { Job } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Search, Send, MessageSquare, Briefcase, User as UserIcon, Mail, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

export default function EmployerMessagesPage() {
    const [conversations, setConversations] = useState([]);
    const [selectedConversation, setSelectedConversation] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [currentUser, setCurrentUser] = useState(null);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setIsLoading(true);
        try {
            const user = await User.me();
            setCurrentUser(user);

            // Load all messages where current user is receiver (employer receiving from job seekers)
            const receivedMessages = await Message.filter({ receiver_email: user.email });
            
            // Group messages by sender to create conversations
            const conversationMap = new Map();
            
            for (const message of receivedMessages) {
                const conversationKey = message.sender_email;
                
                if (!conversationMap.has(conversationKey)) {
                    conversationMap.set(conversationKey, {
                        participant_email: message.sender_email,
                        participant_name: message.sender_name,
                        participant_type: message.sender_type,
                        last_message: message.content,
                        last_message_time: message.created_date,
                        unread_count: message.is_read ? 0 : 1,
                        job_title: message.job_title || 'General Inquiry'
                    });
                } else {
                    const existing = conversationMap.get(conversationKey);
                    // Update with more recent message
                    if (new Date(message.created_date) > new Date(existing.last_message_time)) {
                        existing.last_message = message.content;
                        existing.last_message_time = message.created_date;
                        existing.job_title = message.job_title || existing.job_title;
                    }
                    // Count unread messages
                    if (!message.is_read) {
                        existing.unread_count++;
                    }
                }
            }

            const conversationsList = Array.from(conversationMap.values()).sort(
                (a, b) => new Date(b.last_message_time) - new Date(a.last_message_time)
            );
            
            setConversations(conversationsList);

        } catch (error) {
            console.error("Error loading messages:", error);
            toast.error("Failed to load messages");
        } finally {
            setIsLoading(false);
        }
    };

    const loadConversationMessages = async (participantEmail) => {
        try {
            // Load all messages between current user and selected participant
            const sent = await Message.filter({ 
                sender_email: currentUser.email, 
                receiver_email: participantEmail 
            });
            const received = await Message.filter({ 
                sender_email: participantEmail, 
                receiver_email: currentUser.email 
            });

            const allMessages = [...sent, ...received].sort(
                (a, b) => new Date(a.created_date) - new Date(b.created_date)
            );

            setMessages(allMessages);

            // Mark received messages as read
            for (const message of received) {
                if (!message.is_read) {
                    await Message.update(message.id, { is_read: true });
                }
            }

            // Update conversation unread count
            setConversations(prev => prev.map(conv => 
                conv.participant_email === participantEmail 
                    ? { ...conv, unread_count: 0 }
                    : conv
            ));

        } catch (error) {
            console.error("Error loading conversation:", error);
            toast.error("Failed to load conversation");
        }
    };

    const handleSendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !selectedConversation) return;

        try {
            const messageData = {
                sender_email: currentUser.email,
                receiver_email: selectedConversation.participant_email,
                content: newMessage.trim(),
                sender_name: currentUser.full_name,
                sender_type: 'employer',
                subject: `Re: ${selectedConversation.job_title}`,
                job_title: selectedConversation.job_title,
                message_type: 'general'
            };

            await Message.create(messageData);
            
            // Add message to current conversation
            setMessages(prev => [...prev, {
                ...messageData,
                created_date: new Date().toISOString(),
                id: Date.now().toString()
            }]);

            setNewMessage('');
            toast.success("Message sent!");

        } catch (error) {
            console.error("Error sending message:", error);
            toast.error("Failed to send message");
        }
    };

    const filteredConversations = conversations.filter(conv =>
        conv.participant_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        conv.job_title.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (isLoading) {
        return <div className="text-center p-10">Loading messages...</div>;
    }

    return (
        <div className="h-[calc(100vh-120px)] flex bg-white rounded-lg border overflow-hidden">
            {/* Conversations List */}
            <div className="w-1/3 border-r bg-gray-50 flex flex-col">
                <div className="p-4 border-b bg-white">
                    <div className="flex items-center gap-2 mb-3">
                        <MessageSquare className="w-5 h-5 text-blue-600" />
                        <h2 className="font-semibold text-gray-900">Messages from Job Seekers</h2>
                    </div>
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <Input
                            placeholder="Search conversations..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                    {filteredConversations.length === 0 ? (
                        <div className="p-8 text-center text-gray-500">
                            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>No messages yet</p>
                            <p className="text-sm">Job seekers will appear here when they message you</p>
                        </div>
                    ) : (
                        filteredConversations.map((conv) => (
                            <motion.div
                                key={conv.participant_email}
                                whileHover={{ backgroundColor: "#f8fafc" }}
                                onClick={() => {
                                    setSelectedConversation(conv);
                                    loadConversationMessages(conv.participant_email);
                                }}
                                className={`p-4 cursor-pointer border-b transition-colors ${
                                    selectedConversation?.participant_email === conv.participant_email 
                                        ? 'bg-blue-50 border-blue-200' 
                                        : 'hover:bg-gray-50'
                                }`}
                            >
                                <div className="flex items-start gap-3">
                                    <Avatar className="w-10 h-10">
                                        <AvatarImage src="" alt={conv.participant_name} />
                                        <AvatarFallback>
                                            {conv.participant_name.split(' ').map(n => n[0]).join('')}
                                        </AvatarFallback>
                                    </Avatar>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between mb-1">
                                            <h3 className="font-semibold text-sm text-gray-900 truncate">
                                                {conv.participant_name}
                                            </h3>
                                            {conv.unread_count > 0 && (
                                                <Badge className="bg-blue-600 text-white text-xs h-5 w-5 p-0 flex items-center justify-center rounded-full">
                                                    {conv.unread_count}
                                                </Badge>
                                            )}
                                        </div>
                                        <p className="text-xs text-gray-600 mb-1 flex items-center gap-1">
                                            <Briefcase className="w-3 h-3" />
                                            {conv.job_title}
                                        </p>
                                        <p className="text-xs text-gray-500 truncate">{conv.last_message}</p>
                                        <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                                            <Clock className="w-3 h-3" />
                                            {new Date(conv.last_message_time).toLocaleDateString()}
                                        </p>
                                    </div>
                                </div>
                            </motion.div>
                        ))
                    )}
                </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 flex flex-col">
                {selectedConversation ? (
                    <>
                        {/* Chat Header */}
                        <div className="p-4 border-b bg-white flex items-center gap-3">
                            <Avatar className="w-10 h-10">
                                <AvatarImage src="" alt={selectedConversation.participant_name} />
                                <AvatarFallback>
                                    {selectedConversation.participant_name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                            </Avatar>
                            <div>
                                <h3 className="font-semibold text-gray-900">{selectedConversation.participant_name}</h3>
                                <p className="text-sm text-gray-500 flex items-center gap-1">
                                    <UserIcon className="w-3 h-3" />
                                    Job Seeker • {selectedConversation.job_title}
                                </p>
                            </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                            <AnimatePresence>
                                {messages.map((message) => (
                                    <motion.div
                                        key={message.id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className={`flex ${message.sender_email === currentUser.email ? 'justify-end' : 'justify-start'}`}
                                    >
                                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                            message.sender_email === currentUser.email
                                                ? 'bg-blue-600 text-white' 
                                                : 'bg-white text-gray-800 border'
                                        }`}>
                                            <p className="text-sm">{message.content}</p>
                                            <p className={`text-xs mt-1 ${
                                                message.sender_email === currentUser.email ? 'text-blue-100' : 'text-gray-500'
                                            }`}>
                                                {new Date(message.created_date).toLocaleTimeString([], { 
                                                    hour: '2-digit', 
                                                    minute: '2-digit' 
                                                })}
                                            </p>
                                        </div>
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>

                        {/* Message Input */}
                        <div className="p-4 border-t bg-white">
                            <form onSubmit={handleSendMessage} className="flex gap-2">
                                <Textarea
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    placeholder="Type your reply..."
                                    onKeyPress={(e) => {
                                        if (e.key === 'Enter' && !e.shiftKey) {
                                            e.preventDefault();
                                            handleSendMessage(e);
                                        }
                                    }}
                                    className="flex-1 resize-none"
                                    rows={2}
                                />
                                <Button 
                                    type="submit"
                                    disabled={!newMessage.trim()}
                                    className="bg-blue-600 hover:bg-blue-700"
                                >
                                    <Send className="w-4 h-4" />
                                </Button>
                            </form>
                        </div>
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center bg-gray-50">
                        <div className="text-center text-gray-500">
                            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p className="text-lg font-medium">Select a conversation</p>
                            <p className="text-sm">Choose a job seeker to start messaging</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}