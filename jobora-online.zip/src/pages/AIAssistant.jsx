import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Send, Sparkles, Loader2, MessageSquare, ChevronRight } from 'lucide-react';
import { agentSDK } from '@/agents';
import { InvokeLLM } from '@/api/integrations';
import MessageBubble from '../components/agent/MessageBubble';
import ExamplePrompts from '../components/agent/ExamplePrompts';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { Subscription } from '@/api/entities';
import UpgradePrompt from '../components/UpgradePrompt';


export default function AIAssistantPage() {
    const [conversation, setConversation] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [isResponding, setIsResponding] = useState(false);
    const [relatedQuestions, setRelatedQuestions] = useState([]);
    const messagesEndRef = useRef(null);
    const inputRef = useRef(null);
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const checkSubscription = async () => {
            try {
                const user = await User.me();
                if (user) {
                    const subscriptions = await Subscription.filter({ created_by: user.email }, '-created_date', 1);
                    const hasActiveSub = subscriptions.some(s => ['active', 'trial'].includes(s.status));
                    setIsSubscribed(hasActiveSub);
                }
            } catch (error) {
                console.error("Error checking subscription:", error);
                setIsSubscribed(false);
            } finally {
                setIsLoading(false);
            }
        };

        checkSubscription();
    }, []);

    useEffect(() => {
        if (!conversation?.id) return;
        
        const unsubscribe = agentSDK.subscribeToConversation(conversation.id, (data) => {
            setMessages(data.messages);
        });

        return () => unsubscribe();
    }, [conversation?.id]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isResponding]);

    const generateRelatedQuestions = async () => {
        const lastAssistantMessage = messages.findLast(m => m.role === 'assistant');
        const lastUserMessage = messages.findLast(m => m.role === 'user');

        if (!lastAssistantMessage?.content || !lastUserMessage?.content) {
            setIsResponding(false);
            return;
        }

        try {
            const result = await InvokeLLM({
                prompt: `Based on this user query and AI response, generate 3 short, relevant follow-up questions the user might ask next.
                User Query: "${lastUserMessage.content}"
                AI Response: "${lastAssistantMessage.content.substring(0, 200)}..."
                Return a JSON object with a "questions" array of strings. The questions should be concise and actionable.`,
                response_json_schema: {
                    type: "object",
                    properties: {
                        questions: {
                            type: "array",
                            items: { type: "string" }
                        }
                    }
                }
            });
            setRelatedQuestions(result.questions || []);
        } catch (error) {
            console.error("Error generating related questions:", error);
            setRelatedQuestions([]);
        } finally {
            setIsResponding(false);
        }
    };

    const handleSendMessage = async (content) => {
        const messageContent = content || newMessage;
        if (!messageContent.trim()) return;

        setNewMessage('');
        setRelatedQuestions([]);
        setIsResponding(true);

        let currentConv = conversation;
        if (!currentConv) {
            currentConv = await agentSDK.createConversation({
                agent_name: "JobAssistant",
                metadata: { name: `Job Assistant Chat - ${new Date().toLocaleString()}` }
            });
            setConversation(currentConv);
        }

        const userMessage = { role: 'user', content: messageContent };
        setMessages(prev => [...prev, userMessage]);

        await agentSDK.addMessage(currentConv, userMessage);
        
        setTimeout(() => {
            generateRelatedQuestions();
        }, 2000);
    };

    const handleFormSubmit = (e) => {
        e.preventDefault();
        handleSendMessage();
    };
    
    const handlePromptClick = (prompt) => {
        inputRef.current?.focus();
        handleSendMessage(prompt);
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-full pt-16">
                <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
            </div>
        );
    }

    if (!isSubscribed) {
        return (
            <UpgradePrompt 
                featureName="AI Career Assistant"
                description="Get personalized career advice, interview preparation, and job search help from our advanced AI. Upgrade to Premium to start chatting."
            />
        );
    }

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Full-width header */}
            <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
                <div className="max-w-none px-6 py-4">
                    <div className="flex items-center gap-3">
                        <Sparkles className="w-6 h-6 text-purple-600" />
                        <h1 className="text-xl font-semibold text-gray-900">AI Career Assistant</h1>
                        <div className="text-sm text-gray-500">Your personal job search companion</div>
                    </div>
                </div>
            </div>

            {/* Main chat area - full width with proper scrolling */}
            <div className="flex flex-col h-screen">
                <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6" style={{ paddingBottom: '120px' }}>
                    <div className="max-w-4xl mx-auto">
                        <AnimatePresence>
                            {messages.length > 0 ? (
                                messages.map((msg, index) => (
                                   msg.role !== 'system' && (
                                    <motion.div
                                        key={index}
                                        layout
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        className="mb-6"
                                    >
                                        <MessageBubble message={msg} />
                                    </motion.div>
                                   )
                                ))
                            ) : (
                                <div className="min-h-[60vh] flex items-center justify-center">
                                    <ExamplePrompts onPromptClick={handlePromptClick} />
                                </div>
                            )}
                        </AnimatePresence>

                        {isResponding && (
                            <motion.div 
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                className="flex justify-start mb-6"
                            >
                                <div className="flex items-center gap-3 text-purple-600">
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                    <span className="text-sm">AI is thinking...</span>
                                </div>
                            </motion.div>
                        )}

                        {!isResponding && relatedQuestions.length > 0 && (
                            <motion.div 
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="flex flex-col items-start gap-3 mb-6 ml-14"
                            >
                                <p className="text-sm text-gray-600 font-medium">💡 People also ask:</p>
                                <div className="flex flex-wrap gap-2">
                                    {relatedQuestions.map((q, i) => (
                                        <Button 
                                            key={i} 
                                            variant="outline" 
                                            size="sm" 
                                            className="h-auto py-2 px-3 text-sm hover:bg-purple-50 hover:border-purple-300"
                                            onClick={() => handleSendMessage(q)}
                                        >
                                            {q}
                                        </Button>
                                    ))}
                                </div>
                            </motion.div>
                        )}

                        <div ref={messagesEndRef} />
                    </div>
                </div>

                {/* Fixed input at bottom */}
                <div className="fixed bottom-16 md:bottom-4 left-0 right-0 bg-white border-t border-gray-200 px-6 py-4 z-20">
                    <div className="max-w-4xl mx-auto">
                        <form onSubmit={handleFormSubmit} className="flex gap-3">
                            <Input
                                ref={inputRef}
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                placeholder="Ask me anything about your job search, interviews, applications..."
                                className="flex-1 h-12 text-base"
                                disabled={isResponding && messages.length > 0}
                            />
                            <Button 
                                type="submit" 
                                disabled={!newMessage.trim() || (isResponding && messages.length > 0)} 
                                size="lg"
                                className="h-12 px-6 bg-purple-600 hover:bg-purple-700"
                            >
                                <Send className="w-5 h-5" />
                            </Button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
}