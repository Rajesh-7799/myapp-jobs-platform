

import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Briefcase, User as UserIcon, Loader2, MessageSquare, Menu, X, Search, Mail, Bell, Users, Building, LogOut, Plus, LogIn } from 'lucide-react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from 'sonner';

const seekerNavItems = [
    { name: "Search", href: createPageUrl("Home"), icon: Search },
    { name: "Messages", href: createPageUrl("Messages"), icon: Mail },
    { name: "Profile", href: createPageUrl("Profile"), icon: UserIcon },
    { name: "AI Chat", href: createPageUrl("AIAssistant"), icon: MessageSquare },
];

const employerNavItems = [
    { name: "Dashboard", href: createPageUrl("EmployerDashboard"), icon: Briefcase },
    { name: "Post a Job", href: createPageUrl("PostJob"), icon: Plus },
    { name: "Applicants", href: createPageUrl("Applicants"), icon: Users },
    { name: "Messages", href: createPageUrl("EmployerMessages"), icon: Mail },
    { name: "Profile", href: createPageUrl("EmployerProfile"), icon: Building },
];

const AppLoader = () => (
    <motion.div
        key="loader"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0, transition: { duration: 0.3 } }}
        className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 z-[100]"
    >
        <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3, type: 'spring', stiffness: 120 }}
        >
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg mb-4">
                <Briefcase className="w-10 h-10 text-white"/>
            </div>
        </motion.div>
        <motion.h1
            initial={{ y: 10, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            className="text-2xl font-bold text-gray-900 tracking-tight mb-1"
        >
            JOBORA
        </motion.h1>
        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
    </motion.div>
);

export default function Layout({ children, currentPageName }) {
    const location = useLocation();
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [currentUser, setCurrentUser] = useState(null);

    useEffect(() => {
        const checkAuthAndRedirect = async () => {
            const protectedPages = new Set([
                'EmployerDashboard',
                'PostJob',
                'Applicants',
                'EmployerMessages',
                'EmployerProfile',
                'Messages', // Assuming seeker messages are also protected
                'Profile', // Assuming seeker profile is also protected
                'AIAssistant', // Assuming AI Chat is also protected
                'Notifications', // Assuming seeker notifications are also protected
                'RecruiterChat', // Assuming recruiter chat is also protected
                'EmployerNotifications' // Assuming employer notifications are also protected
            ]);

            try {
                const user = await User.me();
                setCurrentUser(user);

                // Only redirect to role selection if user is authenticated and missing account_type
                if (!user.account_type && currentPageName !== 'RoleSelection') {
                    navigate(createPageUrl('RoleSelection'));
                }
            } catch (error) {
                // Not authenticated
                setCurrentUser(null);

                // Only require login for protected pages
                if (protectedPages.has(currentPageName)) {
                    User.loginWithRedirect(window.location.href);
                    return;
                }
                // Allow public pages (like Home - which is "Search") to render without redirect
            } finally {
                setTimeout(() => setIsLoading(false), 200); 
            }
        };

        checkAuthAndRedirect();
    }, [currentPageName, navigate]);

    // Allow role selection page to render without authentication
    if (currentPageName === 'RoleSelection') {
        return <>{children}</>;
    }
    
    const navItems = currentUser?.account_type === 'employer' ? employerNavItems : seekerNavItems;

    const mobileMenuItems = [
        ...(currentUser?.account_type === 'employer'
            ? [{ name: "Notifications", href: createPageUrl("EmployerNotifications"), icon: Bell }]
            : [
                { name: "Notifications", href: createPageUrl("Notifications"), icon: Bell },
                { name: "Recruiter Conversations", href: createPageUrl("RecruiterChat"), icon: Users }
            ]
        ),
        ...(currentUser 
            ? [{ name: "Logout", onClick: () => User.logout(), icon: LogOut }] 
            : [{ name: "Login", onClick: () => User.login(), icon: LogIn }]
        )
    ];

    const handleRoleSwitch = async () => {
        if (!currentUser) return; // Guard against calling on null user
        const newRole = currentUser.account_type === 'employer' ? 'seeker' : 'employer';
        try {
            await User.updateMyUserData({ account_type: newRole });
            setCurrentUser({ ...currentUser, account_type: newRole });
            
            // Navigate to appropriate dashboard
            if (newRole === 'employer') {
                navigate(createPageUrl('EmployerDashboard'));
            } else {
                navigate(createPageUrl('Home'));
            }
        } catch (error) {
            console.error('Error switching roles:', error);
        }
    };

    return (
        <AnimatePresence mode="wait">
            {isLoading ? ( // Changed condition to just isLoading
                <AppLoader />
            ) : (
                <motion.div
                    key="app-content"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.3 }}
                    className="min-h-screen bg-gray-50 font-sans pb-16 md:pb-0"
                >
                    <Toaster position="top-center" richColors />

                    {/* Top Header */}
                    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
                        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                            <div className="flex justify-between items-center py-3">
                                <Link to={createPageUrl(currentUser?.account_type === 'employer' ? 'EmployerDashboard' : 'Home')} className="flex items-center gap-3">
                                    <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center shadow-md">
                                        <Briefcase className="w-5 h-5 text-white"/>
                                    </div>
                                    <h1 className="text-xl font-bold text-gray-900 tracking-tight">JOBORA</h1>
                                </Link>
                                
                                {/* Navigation */}
                                <nav className="hidden md:flex items-center gap-2">
                                    {navItems.map((item) => (
                                        <Link
                                            key={item.name}
                                            to={item.href}
                                            className={`flex items-center gap-2 text-sm font-medium transition-colors px-3 py-2 rounded-lg ${
                                                location.pathname === item.href
                                                    ? 'text-blue-600 bg-blue-50'
                                                    : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'
                                            }`}
                                        >
                                            <item.icon className="w-4 h-4" />
                                            <span>{item.name}</span>
                                        </Link>
                                    ))}
                                    
                                    {currentUser ? (
                                        <Button
                                            variant="outline"
                                            size="sm"
                                            onClick={handleRoleSwitch}
                                            className="flex items-center gap-2"
                                        >
                                            {currentUser?.account_type === 'employer' ? (
                                                <><Search className="w-4 h-4" /> Job Seeker</>
                                            ) : (
                                                <><Building className="w-4 h-4" /> Employer</>
                                            )}
                                        </Button>
                                    ) : (
                                        <Button size="sm" onClick={() => User.login()}>
                                            <LogIn className="w-4 h-4 mr-2" />
                                            Login / Sign Up
                                        </Button>
                                    )}
                                    
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                                        className="h-9 w-9 text-gray-600 hover:bg-gray-100"
                                    >
                                        {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
                                    </Button>
                                </nav>

                                {/* Mobile Menu Button */}
                                <div className="md:hidden flex items-center gap-2">
                                    {!currentUser && (
                                        <Button size="sm" onClick={() => User.login()}>Login</Button>
                                    )}
                                    <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                                        className="h-9 w-9 text-gray-600 hover:bg-gray-100"
                                    >
                                        {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
                                    </Button>
                                </div>
                            </div>

                            {/* Mobile Menu Dropdown */}
                            <AnimatePresence>
                                {mobileMenuOpen && (
                                    <motion.div
                                        initial={{ opacity: 0, height: 0 }}
                                        animate={{ opacity: 1, height: 'auto' }}
                                        exit={{ opacity: 0, height: 0 }}
                                        transition={{ duration: 0.2 }}
                                        className="border-t overflow-hidden bg-gray-50"
                                    >
                                        <div className="py-3">
                                            <nav className="flex flex-col space-y-1">
                                                {currentUser && ( // Only show role switch button if logged in
                                                    <button
                                                        onClick={() => { handleRoleSwitch(); setMobileMenuOpen(false); }}
                                                        className="flex items-center gap-3 text-sm font-medium transition-colors px-3 py-2 rounded-lg mx-3 text-gray-600 hover:text-gray-900 hover:bg-white text-left"
                                                    >
                                                        {currentUser?.account_type === 'employer' ? (
                                                            <><Search className="w-4 h-4" /> Switch to Job Seeker</>
                                                        ) : (
                                                            <><Building className="w-4 h-4" /> Switch to Employer</>
                                                        )}
                                                    </button>
                                                )}
                                                
                                                {mobileMenuItems.map((item) => (
                                                    item.href ? (
                                                    <Link
                                                        key={item.name}
                                                        to={item.href}
                                                        onClick={() => setMobileMenuOpen(false)}
                                                        className={`flex items-center gap-3 text-sm font-medium transition-colors px-3 py-2 rounded-lg mx-3 ${
                                                            location.pathname === item.href
                                                                ? 'text-blue-600 bg-blue-50'
                                                                : 'text-gray-600 hover:text-gray-900 hover:bg-white'
                                                        }`}
                                                    >
                                                        <item.icon className="w-4 h-4" />
                                                        <span>{item.name}</span>
                                                    </Link>
                                                    ) : (
                                                    <button
                                                        key={item.name}
                                                        onClick={() => { item.onClick(); setMobileMenuOpen(false); }}
                                                        className="flex items-center gap-3 text-sm font-medium transition-colors px-3 py-2 rounded-lg mx-3 text-gray-600 hover:text-gray-900 hover:bg-white text-left"
                                                    >
                                                        <item.icon className="w-4 h-4" />
                                                        <span>{item.name}</span>
                                                    </button>
                                                    )
                                                ))}
                                            </nav>
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </header>

                    {/* Main Content */}
                    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                        {children}
                    </main>

                    {/* Mobile Bottom Navigation */}
                    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 md:hidden z-50">
                        <div className={`grid h-16 ${navItems.length === 4 ? 'grid-cols-4' : 'grid-cols-5'}`}>
                            {navItems.map((item) => (
                                <Link
                                    key={item.name}
                                    to={item.href}
                                    className={`flex flex-col items-center justify-center gap-1 transition-colors ${
                                        location.pathname === item.href
                                            ? 'text-blue-600 bg-blue-50'
                                            : 'text-gray-400 hover:text-gray-600 active:bg-gray-50'
                                    }`}
                                >
                                    <item.icon className={`w-5 h-5`} />
                                    <span className={`text-xs font-medium`}>
                                        {item.name}
                                    </span>
                                </Link>
                            ))}
                        </div>
                    </nav>
                </motion.div>
            )}
        </AnimatePresence>
    );
}

