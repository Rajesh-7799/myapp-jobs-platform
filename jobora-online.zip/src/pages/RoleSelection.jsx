
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Briefcase, Building, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';

export default function RoleSelectionPage() {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);

    const handleRoleSelect = async (role) => {
        setIsLoading(true);
        try {
            const user = await User.me();
            await User.update(user.id, { account_type: role });
            toast.success(`Welcome! Your profile is set up as an ${role}.`);
            // Navigate to the appropriate dashboard
            if (role === 'employer') {
                navigate(createPageUrl('EmployerDashboard'));
            } else {
                navigate(createPageUrl('Home'));
            }
        } catch (error) {
            console.error("Error setting user role:", error);
            toast.error("Could not set up your profile. Please try again.");
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
            <div className="max-w-4xl w-full text-center">
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Welcome to JOBORA</h1>
                <p className="text-lg text-gray-600 mb-8">To get started, please tell us what you're here for.</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card className="hover:shadow-xl transition-shadow cursor-pointer" onClick={() => handleRoleSelect('seeker')}>
                        <CardHeader className="items-center">
                            <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-4">
                                <Briefcase className="w-8 h-8" />
                            </div>
                            <CardTitle className="text-2xl">I'm looking for a job</CardTitle>
                            <CardDescription className="text-base">Find your next career opportunity.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Button variant="outline" className="w-full" disabled={isLoading}>
                                {isLoading ? <Loader2 className="animate-spin" /> : 'Continue as a Job Seeker'}
                            </Button>
                        </CardContent>
                    </Card>
                    
                    <Card className="hover:shadow-xl transition-shadow cursor-pointer" onClick={() => handleRoleSelect('employer')}>
                        <CardHeader className="items-center">
                            <div className="w-16 h-16 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mb-4">
                                <Building className="w-8 h-8" />
                            </div>
                            <CardTitle className="text-2xl">I'm hiring</CardTitle>
                            <CardDescription className="text-base">Post jobs and find top talent.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Button variant="outline" className="w-full" disabled={isLoading}>
                                {isLoading ? <Loader2 className="animate-spin" /> : 'Continue as an Employer'}
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
