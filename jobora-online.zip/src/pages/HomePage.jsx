
import React, { useState, useEffect, useCallback } from 'react';
import { Job } from '@/api/entities';
import { User } from '@/api/entities';
import { Subscription } from '@/api/entities';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Search, X, MapPin, Briefcase, Crown, AlertCircle, TrendingUp, Clock, Filter, RefreshCw } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';

import JobDetails from '../components/JobDetails';
import JobFilters from '../components/JobFilters';
import DirectRecruiterJobs from '../components/DirectRecruiterJobs';
import SubscriptionBanner from '../components/SubscriptionBanner';
import { fetchMultipleJobSources } from '@/api/functions';
import { toast } from 'sonner';

// Default job search suggestions
const defaultJobSuggestions = [
    'Software Engineer', 'Product Manager', 'Data Scientist', 'UX Designer',
    'Frontend Developer', 'Backend Developer', 'DevOps Engineer', 'Marketing Manager',
    'Sales Representative', 'Business Analyst', 'Project Manager', 'Full Stack Developer'
];

// Default location suggestions
const defaultLocationSuggestions = [
    'New York, NY', 'San Francisco, CA', 'Los Angeles, CA', 'Chicago, IL',
    'Austin, TX', 'Seattle, WA', 'Boston, MA', 'Denver, CO', 
    'Remote', 'Hybrid', 'Atlanta, GA', 'Miami, FL'
];

// Source logos
const sourceLogos = {
    LinkedIn: 'https://via.placeholder.com/24x24/0077B5/FFFFFF?text=Li',
    Indeed: 'https://via.placeholder.com/24x24/2557A7/FFFFFF?text=In',
    Glassdoor: 'https://via.placeholder.com/24x24/0CAA41/FFFFFF?text=Gd',
    Adzuna: 'https://via.placeholder.com/24x24/FF6B35/FFFFFF?text=Az',
    JOBORA: 'https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=JO',
};

export default function HomePage() {
    const [searchTerm, setSearchTerm] = useState('');
    const [searchLocation, setSearchLocation] = useState('');
    const [jobs, setJobs] = useState([]);
    const [selectedJob, setSelectedJob] = useState(null);
    const [isSearching, setIsSearching] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [searchError, setSearchError] = useState(null);
    const [searchExpanded, setSearchExpanded] = useState(false);
    const [locationExpanded, setLocationExpanded] = useState(false);
    const [isFiltersOpen, setIsFiltersOpen] = useState(false);
    const [recentSearches, setRecentSearches] = useState([]);
    const [suggestions, setSuggestions] = useState([]);
    const [locationSuggestions, setLocationSuggestions] = useState([]);
    const [currentUser, setCurrentUser] = useState(null);
    const [isSubscribed, setIsSubscribed] = useState(false);

    const navigate = useNavigate();
    const location = useLocation();

    const [filters, setFilters] = useState({
        job_type: 'all',
        experience_level: 'all',
        posted_within: 'all',
        remote_work: 'all',
    });

    const loadRecentSearches = () => {
        const searches = localStorage.getItem('recentSearches');
        if (searches) {
            setRecentSearches(JSON.parse(searches));
        }
    };

    // Main function to load jobs from both internal DB and external APIs
    const loadAllJobs = async (searchTerm = '', searchLocation = '') => {
        setIsSearching(true);
        setSearchError(null);
        try {
            console.log(`Searching for: "${searchTerm}" in "${searchLocation}"`);

            // Fetch from both sources concurrently
            const [internalJobs, externalJobsResponse] = await Promise.all([
                Job.list('-created_date', 200).catch(err => {
                    console.error("Internal DB fetch failed:", err);
                    return [];
                }),
                fetchMultipleJobSources({ searchTerm, searchLocation }).catch(err => {
                    console.error("External API fetch failed:", err);
                    toast.error("Could not fetch external jobs, showing internal listings.");
                    return { data: { jobs: [] } }; // Prevent crash on failure
                })
            ]);

            const externalJobs = externalJobsResponse.data?.jobs || [];
            console.log(`Loaded ${internalJobs.length} internal jobs and ${externalJobs.length} external jobs.`);

            // Combine, filter, and deduplicate
            let combinedJobs = [...internalJobs, ...externalJobs];

            const seenJobs = new Set();
            const uniqueJobs = combinedJobs.filter(job => {
                const key = `${job.title?.toLowerCase().trim()}|${job.company?.toLowerCase().trim()}`;
                if (seenJobs.has(key)) {
                    return false;
                }
                seenJobs.add(key);
                return true;
            });
            
            // Add source logos and prepare jobs for display
            const jobsWithLogos = uniqueJobs.map(job => ({
                ...job,
                source_logo: sourceLogos[job.source] || `https://via.placeholder.com/24x24/4F46E5/FFFFFF?text=${job.source?.charAt(0) || 'J'}`
            }));

            setJobs(jobsWithLogos);
            
            if (jobsWithLogos.length > 0) {
                setSelectedJob(jobsWithLogos[0]);
                toast.success(`Found ${jobsWithLogos.length} total jobs!`);
                setSearchError(null); // Clear any previous errors
            } else {
                setSelectedJob(null);
                setSearchError("No jobs found. Try different keywords or check back later.");
            }

        } catch (error) {
            console.error("Error loading all jobs:", error);
            setSearchError(`Failed to load jobs: ${error.message}`);
            setJobs([]);
            setSelectedJob(null);
            toast.error(`An error occurred: ${error.message}`);
        } finally {
            setIsSearching(false);
            setIsLoading(false); // Also set main loading to false for initial mount
        }
    };

    useEffect(() => {
        const generateSmartSuggestions = async () => {
            try {
                const user = await User.me();
                if (user?.skills?.length > 0) {
                    const skillBasedSuggestions = user.skills.slice(0, 4).map(skill => 
                        `${skill} Developer`
                    );
                    setSuggestions([...new Set([...skillBasedSuggestions, ...defaultJobSuggestions.slice(0, 8)])]);
                } else {
                    setSuggestions(defaultJobSuggestions.slice(0, 12));
                }
                
                setLocationSuggestions(defaultLocationSuggestions);
            } catch (error) {
                console.error("Error generating smart suggestions:", error);
                setSuggestions(defaultJobSuggestions.slice(0, 12));
                setLocationSuggestions(defaultLocationSuggestions);
            }
        };

        const loadInitialData = async () => {
            setIsLoading(true);
            try {
                const user = await User.me();
                setCurrentUser(user);

                if (user) {
                    const subscriptions = await Subscription.filter({ created_by: user.email }, '-created_date', 1);
                    const hasActiveSub = subscriptions.some(s => ['active', 'trial'].includes(s.status));
                    setIsSubscribed(hasActiveSub);
                }
                
                await loadAllJobs(); // Call the combined job loader
                
            } catch (error) {
                console.error("Error loading initial data (user or subscriptions):", error);
                // Continue to load jobs even if user/subscription data fails
                await loadAllJobs();
            } finally {
                // isLoading is set to false within loadAllJobs's finally block
            }
        };

        loadInitialData();
        loadRecentSearches();
        generateSmartSuggestions();
    }, []);

    const createSampleJobs = async () => {
        setIsSearching(true);
        setSearchError(null);
        try {
            console.log("Creating sample jobs...");
            
            const sampleJobs = [
                {
                    title: "Senior Software Engineer",
                    company: "TechCorp Solutions",
                    location: "San Francisco, CA",
                    description: "Join our team building next-generation cloud applications with React, Node.js, and AWS. Work with a talented team on products used by millions.",
                    job_type: "Full-time",
                    experience_level: "senior",
                    salary_range: "$120k - $160k",
                    status: "active",
                    is_internal: true,
                    source: "JOBORA"
                },
                {
                    title: "Product Manager",
                    company: "StartupXYZ",
                    location: "New York, NY",
                    description: "Lead product strategy for our fast-growing fintech startup. Work closely with engineering, design, and business teams.",
                    job_type: "Full-time",
                    experience_level: "mid",
                    salary_range: "$100k - $140k", // Fixed: Removed extra double quote
                    status: "active",
                    is_internal: true,
                    source: "JOBORA"
                },
                {
                    title: "UX Designer",
                    company: "Design Studio Pro",
                    location: "Remote",
                    description: "Create beautiful, user-friendly interfaces for web and mobile applications. Remote-first company with flexible hours.",
                    job_type: "Full-time",
                    experience_level: "mid",
                    salary_range: "$80k - $110k", // Fixed: Removed extra double quote
                    status: "active",
                    is_internal: true,
                    source: "JOBORA"
                },
                {
                    title: "Data Scientist",
                    company: "AI Innovations Inc",
                    location: "Boston, MA",
                    description: "Apply machine learning to solve real-world problems. Work with Python, TensorFlow, and large-scale data systems.",
                    job_type: "Full-time",
                    experience_level: "mid",
                    salary_range: "$110k - $150k",
                    status: "active",
                    is_internal: true,
                    source: "JOBORA"
                }
            ];

            for (const jobData of sampleJobs) {
                try {
                    await Job.create(jobData);
                } catch (error) {
                    console.error("Error creating sample job:", jobData.title, error);
                }
            }
            
            console.log("Finished creating sample jobs, reloading all jobs...");
            await loadAllJobs(); // Reload all jobs after creating samples
            
        } catch (error) {
            console.error("Error creating sample jobs:", error);
            setSearchError(`Failed to create sample jobs: ${error.message}`);
            toast.error(`Failed to create sample jobs: ${error.message}`);
        } finally {
            setIsSearching(false);
        }
    };

    // Search function
    const handleSearch = async (e) => {
        e.preventDefault();
        setSearchExpanded(false);
        setLocationExpanded(false);
        saveRecentSearch(searchTerm, searchLocation);
        await loadAllJobs(searchTerm, searchLocation);
    };

    const handleJobClick = (job) => {
        setSelectedJob(job);
    };

    const clearSearch = () => {
        setSearchTerm('');
        setSearchLocation('');
        setSearchError(null);
        setSearchExpanded(false);
        setLocationExpanded(false);
        setFilters({ job_type: 'all', experience_level: 'all', posted_within: 'all', remote_work: 'all' });
        loadAllJobs(); // Reload all jobs without search terms or filters
    };

    const saveRecentSearch = (term, location) => {
        if (!term && !location) return;
        const newSearch = { term, location, timestamp: new Date().toISOString() };
        let updatedSearches = [newSearch, ...recentSearches.filter(s => !(s.term === term && s.location === location))];
        updatedSearches = updatedSearches.slice(0, 5);
        setRecentSearches(updatedSearches);
        localStorage.setItem('recentSearches', JSON.stringify(updatedSearches));
    };

    const handleJobSearchFocus = () => {
        setSearchExpanded(true);
        setLocationExpanded(false);
    };

    const handleLocationSearchFocus = () => {
        setLocationExpanded(true);
        setSearchExpanded(false);
    };

    const handleSuggestionClick = (suggestion) => {
        setSearchTerm(suggestion);
        setSearchExpanded(false);
        if (searchLocation || suggestion) {
            setTimeout(() => {
                const form = document.querySelector('form');
                if (form) {
                    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                }
            }, 100);
        }
    };

    const handleLocationSuggestionClick = (location) => {
        setSearchLocation(location);
        setLocationExpanded(false);
        if (searchTerm || location) {
            setTimeout(() => {
                const form = document.querySelector('form');
                if (form) {
                    form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
                }
            }, 100);
        }
    };

    const handleApplyFilters = (newFilters) => {
        setFilters(newFilters);
        setIsFiltersOpen(false);
        // Filtering is now handled by the `displayedJobs` computation before rendering.
        // No need to re-fetch from API, as `jobs` already holds the comprehensive list.
    };

    const highlightMatch = (text, term) => {
        if (!term) return text;
        const parts = text.split(new RegExp(`(${term})`, 'gi'));
        return (
            <span>
                {parts.map((part, i) =>
                    part.toLowerCase() === term.toLowerCase() ? <strong key={i}>{part}</strong> : part
                )}
            </span>
        );
    };

    // Refresh jobs function
    const refreshJobs = async () => {
        await loadAllJobs();
    };

    // Filtering logic is now done on the frontend before rendering
    const displayedJobs = jobs.filter(job => {
        // Apply job_type filter
        if (filters.job_type !== 'all' && job.job_type && job.job_type.toLowerCase() !== filters.job_type.toLowerCase()) {
            return false;
        }
        // Apply experience_level filter
        if (filters.experience_level !== 'all' && job.experience_level && job.experience_level.toLowerCase() !== filters.experience_level.toLowerCase()) {
            return false;
        }
        // Apply remote_work filter
        if (filters.remote_work === 'remote') {
            if (!job.location?.toLowerCase().includes('remote')) return false;
        } else if (filters.remote_work === 'on-site') {
            if (job.location?.toLowerCase().includes('remote')) return false;
        }

        // Apply posted_within filter
        if (filters.posted_within !== 'all') {
            let jobDate;
            if (job.created_date) { // For internal jobs
                jobDate = new Date(job.created_date);
            } else if (job.posted_date) { // For external jobs (assuming this field exists and is ISO string)
                jobDate = new Date(job.posted_date);
            } else {
                // If no recognizable date field, assume it doesn't match the filter
                return false;
            }

            if (isNaN(jobDate.getTime())) { // Check for invalid date
                return false;
            }

            const now = new Date();
            const diffTime = Math.abs(now.getTime() - jobDate.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); // Difference in days

            if (filters.posted_within === '24h' && diffDays > 1) return false;
            if (filters.posted_within === '7d' && diffDays > 7) return false;
            if (filters.posted_within === '30d' && diffDays > 30) return false;
        }

        return true;
    });

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {!isSubscribed && currentUser && (
                <SubscriptionBanner currentUser={currentUser} />
            )}

            <header className="bg-white shadow-sm p-4 sticky top-0 z-20">
                <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center gap-4">
                    <form onSubmit={handleSearch} className="flex flex-col sm:flex-row w-full gap-3">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                            <Input
                                type="text"
                                placeholder="Job title, keywords, or company"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                onFocus={handleJobSearchFocus}
                                className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            />
                            {searchTerm && (
                                <button
                                    type="button"
                                    onClick={() => setSearchTerm('')}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                >
                                    <X size={18} />
                                </button>
                            )}

                            <AnimatePresence>
                                {searchExpanded && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        transition={{ duration: 0.1 }}
                                        className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-64 overflow-y-auto z-20"
                                    >
                                        {recentSearches.length > 0 && (
                                            <div className="p-3 border-b border-gray-100">
                                                <p className="text-xs font-medium text-gray-500 mb-2">Recent Searches</p>
                                                {recentSearches.slice(0, 3).map((searchItem, index) => (
                                                    <button
                                                        key={index}
                                                        type="button"
                                                        onClick={() => handleSuggestionClick(searchItem.term)}
                                                        className="flex items-center gap-2 w-full text-left px-2 py-1 hover:bg-gray-50 rounded text-sm"
                                                    >
                                                        <Clock className="w-3 h-3 text-gray-400" />
                                                        {searchItem.term} {searchItem.location && `(${searchItem.location})`}
                                                    </button>
                                                ))}
                                            </div>
                                        )}
                                        <div className="p-3">
                                            <p className="text-xs font-medium text-gray-500 mb-2">Popular Jobs</p>
                                            {suggestions.map((suggestion, index) => (
                                                <button
                                                    key={index}
                                                    type="button"
                                                    onClick={() => handleSuggestionClick(suggestion)}
                                                    className="flex items-center gap-2 w-full text-left px-2 py-1 hover:bg-gray-50 rounded text-sm"
                                                >
                                                    <TrendingUp className="w-3 h-3 text-green-500" />
                                                    {suggestion}
                                                </button>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>

                        <div className="relative flex-1">
                            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                            <Input
                                type="text"
                                placeholder="Location (e.g., New York, Remote)"
                                value={searchLocation}
                                onChange={(e) => setSearchLocation(e.target.value)}
                                onFocus={handleLocationSearchFocus}
                                className="pl-10 pr-4 py-2 w-full rounded-md border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                            />
                            {searchLocation && (
                                <button
                                    type="button"
                                    onClick={() => setSearchLocation('')}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                >
                                    <X size={18} />
                                </button>
                            )}

                            <AnimatePresence>
                                {locationExpanded && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -10 }}
                                        transition={{ duration: 0.1 }}
                                        className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-64 overflow-y-auto z-20"
                                    >
                                        <div className="p-3">
                                            <p className="text-xs font-medium text-gray-500 mb-2">Popular Locations</p>
                                            {locationSuggestions.map((loc, index) => (
                                                <button
                                                    key={index}
                                                    type="button"
                                                    onClick={() => handleLocationSuggestionClick(loc)}
                                                    className="flex items-center gap-2 w-full text-left px-2 py-1 hover:bg-gray-50 rounded text-sm"
                                                >
                                                    <MapPin className="w-3 h-3 text-blue-500" />
                                                    {loc}
                                                </button>
                                            ))}
                                        </div>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>

                        <Button type="submit" className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md flex items-center justify-center" disabled={isSearching}>
                            {isSearching ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                            Search
                        </Button>
                        <Sheet open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
                            <SheetTrigger asChild>
                                <Button variant="outline" className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md flex items-center justify-center">
                                    <Filter className="mr-2 h-4 w-4" /> Filters
                                </Button>
                            </SheetTrigger>
                            <SheetContent className="w-[350px] sm:w-[400px]">
                                <SheetHeader>
                                    <SheetTitle>Filter Jobs</SheetTitle>
                                    <SheetDescription>
                                        Refine your search to find the perfect job.
                                    </SheetDescription>
                                </SheetHeader>
                                <JobFilters 
                                    initialFilters={filters}
                                    onApplyFilters={handleApplyFilters}
                                    isSubscribed={isSubscribed}
                                />
                            </SheetContent>
                        </Sheet>
                        {(searchTerm || searchLocation || filters.job_type !== 'all' || filters.experience_level !== 'all' || filters.posted_within !== 'all' || filters.remote_work !== 'all') && (
                            <Button type="button" variant="ghost" onClick={clearSearch} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-md flex items-center justify-center">
                                <X className="mr-2 h-4 w-4" /> Clear
                            </Button>
                        )}
                    </form>
                </div>

                {(searchExpanded || locationExpanded) && (
                    <div 
                        className="fixed inset-0 z-10" 
                        onClick={() => {
                            setSearchExpanded(false);
                            setLocationExpanded(false);
                        }}
                    />
                )}
            </header>

            <main className="flex-1 max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row gap-6 w-full">
                <div className="w-full lg:w-1/4 space-y-6 hidden lg:block">
                    {currentUser && jobs.length > 0 && <DirectRecruiterJobs jobs={jobs} onJobSelect={handleJobClick} />}
                </div>

                <div className="w-full lg:w-3/5 flex flex-col lg:flex-row gap-6">
                    <div className="w-full lg:w-2/5 xl:w-1/2 bg-white rounded-lg shadow-md p-4 overflow-y-auto max-h-[calc(100vh-160px)]">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xl font-bold text-gray-800">Job Listings</h2>
                            <Badge variant="outline" className="text-xs">
                                {displayedJobs.length} jobs
                            </Badge>
                        </div>
                        
                        {isSearching ? (
                            <div className="flex justify-center items-center h-64">
                                <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
                                <span className="ml-2 text-gray-600">Loading jobs...</span>
                            </div>
                        ) : searchError ? (
                            <div className="text-center py-8 text-red-500 flex flex-col items-center">
                                <AlertCircle className="h-12 w-12 mb-2" />
                                <p className="text-lg font-semibold">{searchError}</p>
                                <div className="flex gap-2 mt-4">
                                    <Button onClick={refreshJobs} variant="outline" disabled={isSearching}>
                                        {isSearching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                                        Refresh Jobs
                                    </Button>
                                    <Button onClick={createSampleJobs} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={isSearching}>
                                        {isSearching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                                        Load Sample Jobs
                                    </Button>
                                </div>
                            </div>
                        ) : displayedJobs.length === 0 ? (
                            <div className="text-center py-8 text-gray-500 flex flex-col items-center">
                                <Search className="h-12 w-12 mb-2" />
                                <p className="text-lg font-semibold">No jobs available</p>
                                <p className="text-sm mb-4">Let's add some jobs to get started!</p>
                                <div className="flex gap-2">
                                    <Button onClick={refreshJobs} variant="outline" disabled={isSearching}>
                                        {isSearching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />}
                                        Refresh Jobs
                                    </Button>
                                    <Button onClick={createSampleJobs} className="bg-blue-600 hover:bg-blue-700 text-white" disabled={isSearching}>
                                        {isSearching ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                                        Load Sample Jobs
                                    </Button>
                                </div>
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {displayedJobs.map((job) => (
                                    <Card
                                        key={job.id || job.url}
                                        className={`cursor-pointer hover:shadow-lg transition-shadow duration-200 ${selectedJob?.id === job.id || selectedJob?.url === job.url ? 'border-2 border-indigo-500 bg-indigo-50' : 'border border-gray-200'}`}
                                        onClick={() => handleJobClick(job)}
                                    >
                                        <CardContent className="p-4">
                                            <div className="flex items-start mb-2">
                                                <img src={job.source_logo} alt={job.source} className="w-6 h-6 mr-3 object-contain rounded" />
                                                <div className="flex-1 min-w-0">
                                                    <h3 className="text-lg font-semibold text-gray-900 truncate">{highlightMatch(job.title, searchTerm)}</h3>
                                                    <p className="text-sm text-gray-600 truncate">{job.company}</p>
                                                </div>
                                                {job.is_external && job.source && (
                                                    <Badge variant="outline" className="text-xs bg-green-50 text-green-700">
                                                        {job.source}
                                                    </Badge>
                                                )}
                                            </div>
                                            <div className="flex items-center text-gray-500 text-sm mb-2">
                                                <MapPin className="mr-1 flex-shrink-0" size={16} /> 
                                                <span className="truncate">{highlightMatch(job.location, searchLocation)}</span>
                                                <Briefcase className="ml-4 mr-1 flex-shrink-0" size={16} /> 
                                                <span className="truncate">{job.job_type}</span>
                                            </div>
                                            <div className="flex flex-wrap gap-2 mb-3">
                                                {job.has_direct_contact && (
                                                    <Badge className="bg-yellow-100 text-yellow-800 text-xs">
                                                        <Crown className="w-3 h-3 mr-1" />
                                                        Direct Contact
                                                    </Badge>
                                                )}
                                                {job.salary_range && (
                                                    <Badge variant="outline" className="bg-green-100 text-green-700 text-xs">
                                                        {job.salary_range}
                                                    </Badge>
                                                )}
                                            </div>
                                            <p className="text-sm text-gray-700 line-clamp-2">{job.description}</p>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className="w-full lg:w-3/5 xl:w-1/2 bg-white rounded-lg shadow-md overflow-hidden">
                        {selectedJob ? (
                            <JobDetails job={selectedJob} sourceLogos={sourceLogos} currentUser={currentUser} isSubscribed={isSubscribed} />
                        ) : (
                            <div className="flex items-center justify-center h-full text-gray-500">
                                {isSearching ? (
                                    <Loader2 className="h-12 w-12 animate-spin text-indigo-600" />
                                ) : (
                                    <div className="text-center">
                                        <Search className="h-12 w-12 mx-auto mb-4 opacity-50" />
                                        <p className="text-lg">Select a job to view details</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </main>
        </div>
    );
}
