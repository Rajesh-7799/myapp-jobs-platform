import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Job } from '@/api/entities';
import { EasyApplication } from '@/api/entities';
import { EmployerBadge } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Building, Globe, Mail, Phone, MapPin, Calendar, Award, Briefcase, Users, Eye, Camera, Save, Edit3 } from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

export default function EmployerProfilePage() {
    const [user, setUser] = useState(null);
    const [badges, setBadges] = useState([]);
    const [jobs, setJobs] = useState([]);
    const [applications, setApplications] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isEditing, setIsEditing] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [profileData, setProfileData] = useState({
        company_name: '',
        company_website: '',
        company_description: '',
        industry: '',
        company_size: '',
        founded_year: '',
        location: '',
        phone: '',
        benefits: [],
        company_culture: '',
        social_media: {
            linkedin: '',
            twitter: '',
            facebook: ''
        }
    });

    useEffect(() => {
        loadEmployerData();
    }, []);

    const loadEmployerData = async () => {
        setIsLoading(true);
        try {
            const currentUser = await User.me();
            setUser(currentUser);

            // Load profile data
            setProfileData({
                company_name: currentUser.company_name || '',
                company_website: currentUser.company_website || '',
                company_description: currentUser.company_description || '',
                industry: currentUser.industry || '',
                company_size: currentUser.company_size || '',
                founded_year: currentUser.founded_year || '',
                location: currentUser.location || '',
                phone: currentUser.phone || '',
                benefits: currentUser.benefits || [],
                company_culture: currentUser.company_culture || '',
                social_media: currentUser.social_media || {
                    linkedin: '',
                    twitter: '',
                    facebook: ''
                }
            });

            // Load employer jobs
            const employerJobs = await Job.filter({ created_by: currentUser.email });
            setJobs(employerJobs);

            // Load applications for employer's jobs
            const allApplications = [];
            for (const job of employerJobs) {
                const jobApplications = await EasyApplication.filter({ job_id: job.id });
                allApplications.push(...jobApplications);
            }
            setApplications(allApplications);

            // Load badges
            const employerBadges = await EmployerBadge.filter({ employer_email: currentUser.email });
            setBadges(employerBadges);

            // Check and award new badges
            await checkAndAwardBadges(currentUser.email, employerJobs.length, allApplications.length);

        } catch (error) {
            console.error("Error loading employer data:", error);
            toast.error("Failed to load profile data");
        } finally {
            setIsLoading(false);
        }
    };

    const checkAndAwardBadges = async (employerEmail, jobCount, applicationCount) => {
        const badgeDefinitions = [
            { type: 'first_post', name: 'First Job Posted', description: 'Posted your first job!', icon: '🎯', threshold: 1 },
            { type: '10_posts', name: '10 Jobs Posted', description: 'Posted 10 jobs', icon: '📈', threshold: 10 },
            { type: '50_posts', name: '50 Jobs Posted', description: 'Posted 50 jobs', icon: '🚀', threshold: 50 },
            { type: '100_posts', name: '100 Jobs Posted', description: 'Posted 100 jobs', icon: '💯', threshold: 100 },
            { type: '500_posts', name: 'Premium Unlocked', description: 'Posted 500+ jobs - Premium features unlocked!', icon: '👑', threshold: 500 }
        ];

        for (const badge of badgeDefinitions) {
            if (jobCount >= badge.threshold) {
                // Check if badge already exists
                const existingBadges = await EmployerBadge.filter({ 
                    employer_email: employerEmail, 
                    badge_type: badge.type 
                });
                
                if (existingBadges.length === 0) {
                    await EmployerBadge.create({
                        employer_email: employerEmail,
                        badge_type: badge.type,
                        badge_name: badge.name,
                        badge_description: badge.description,
                        badge_icon: badge.icon,
                        earned_date: new Date().toISOString()
                    });
                    toast.success(`🎉 Badge earned: ${badge.name}!`);
                }
            }
        }
    };

    const handleLogoUpload = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        try {
            const { file_url } = await UploadFile({ file });
            await User.updateMyUserData({ company_logo_url: file_url });
            setUser(prev => ({ ...prev, company_logo_url: file_url }));
            toast.success("Company logo updated!");
        } catch (error) {
            console.error("Error uploading logo:", error);
            toast.error("Failed to upload logo");
        }
    };

    const handleSaveProfile = async () => {
        setIsSaving(true);
        try {
            await User.updateMyUserData(profileData);
            setUser(prev => ({ ...prev, ...profileData }));
            setIsEditing(false);
            toast.success("Profile updated successfully!");
        } catch (error) {
            console.error("Error saving profile:", error);
            toast.error("Failed to save profile");
        } finally {
            setIsSaving(false);
        }
    };

    const addBenefit = (benefit) => {
        if (benefit && !profileData.benefits.includes(benefit)) {
            setProfileData(prev => ({
                ...prev,
                benefits: [...prev.benefits, benefit]
            }));
        }
    };

    const removeBenefit = (benefitToRemove) => {
        setProfileData(prev => ({
            ...prev,
            benefits: prev.benefits.filter(benefit => benefit !== benefitToRemove)
        }));
    };

    if (isLoading) {
        return <div className="text-center p-10">Loading employer profile...</div>;
    }

    const stats = {
        totalJobs: jobs.length,
        activeJobs: jobs.filter(job => job.status === 'active').length,
        totalApplications: applications.length,
        totalViews: jobs.reduce((sum, job) => sum + (job.views_count || 0), 0)
    };

    return (
        <div className="max-w-6xl mx-auto space-y-6 p-4">
            {/* Header Section */}
            <Card>
                <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row items-start gap-6">
                        {/* Company Logo */}
                        <div className="relative">
                            <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                                <AvatarImage src={user?.company_logo_url} alt={profileData.company_name} />
                                <AvatarFallback className="text-2xl bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                                    {profileData.company_name?.charAt(0) || 'C'}
                                </AvatarFallback>
                            </Avatar>
                            <Button
                                size="icon"
                                variant="outline"
                                className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 bg-white"
                                onClick={() => document.getElementById('logo-upload').click()}
                            >
                                <Camera className="w-4 h-4" />
                            </Button>
                            <input
                                id="logo-upload"
                                type="file"
                                accept="image/*"
                                onChange={handleLogoUpload}
                                className="hidden"
                            />
                        </div>

                        {/* Company Info */}
                        <div className="flex-1">
                            <div className="flex items-start justify-between mb-4">
                                <div>
                                    <h1 className="text-3xl font-bold text-gray-900">
                                        {profileData.company_name || 'Your Company'}
                                    </h1>
                                    <p className="text-gray-600">{profileData.industry}</p>
                                    {profileData.location && (
                                        <p className="text-gray-500 flex items-center gap-1 mt-1">
                                            <MapPin className="w-4 h-4" />
                                            {profileData.location}
                                        </p>
                                    )}
                                </div>
                                <Button
                                    onClick={() => setIsEditing(!isEditing)}
                                    variant={isEditing ? "outline" : "default"}
                                >
                                    <Edit3 className="w-4 h-4 mr-2" />
                                    {isEditing ? 'Cancel' : 'Edit Profile'}
                                </Button>
                            </div>

                            {/* Badges */}
                            <div className="flex flex-wrap gap-2 mb-4">
                                {badges.map((badge, index) => (
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, scale: 0.9 }}
                                        animate={{ opacity: 1, scale: 1 }}
                                        transition={{ delay: index * 0.1 }}
                                    >
                                        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1">
                                            <span className="mr-1">{badge.badge_icon}</span>
                                            {badge.badge_name}
                                        </Badge>
                                    </motion.div>
                                ))}
                            </div>

                            {/* Stats */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div className="text-center p-3 bg-blue-50 rounded-lg">
                                    <div className="text-2xl font-bold text-blue-600">{stats.totalJobs}</div>
                                    <div className="text-sm text-gray-600">Jobs Posted</div>
                                </div>
                                <div className="text-center p-3 bg-green-50 rounded-lg">
                                    <div className="text-2xl font-bold text-green-600">{stats.activeJobs}</div>
                                    <div className="text-sm text-gray-600">Active Jobs</div>
                                </div>
                                <div className="text-center p-3 bg-purple-50 rounded-lg">
                                    <div className="text-2xl font-bold text-purple-600">{stats.totalApplications}</div>
                                    <div className="text-sm text-gray-600">Applications</div>
                                </div>
                                <div className="text-center p-3 bg-orange-50 rounded-lg">
                                    <div className="text-2xl font-bold text-orange-600">{stats.totalViews}</div>
                                    <div className="text-sm text-gray-600">Job Views</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Profile Form */}
            {isEditing && (
                <Card>
                    <CardHeader>
                        <CardTitle>Edit Company Profile</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium mb-1 block">Company Name</label>
                                <Input
                                    value={profileData.company_name}
                                    onChange={(e) => setProfileData(prev => ({...prev, company_name: e.target.value}))}
                                    placeholder="Your Company Name"
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium mb-1 block">Website</label>
                                <Input
                                    value={profileData.company_website}
                                    onChange={(e) => setProfileData(prev => ({...prev, company_website: e.target.value}))}
                                    placeholder="https://yourcompany.com"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className="text-sm font-medium mb-1 block">Industry</label>
                                <Input
                                    value={profileData.industry}
                                    onChange={(e) => setProfileData(prev => ({...prev, industry: e.target.value}))}
                                    placeholder="Technology, Healthcare, etc."
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium mb-1 block">Company Size</label>
                                <Input
                                    value={profileData.company_size}
                                    onChange={(e) => setProfileData(prev => ({...prev, company_size: e.target.value}))}
                                    placeholder="1-10, 11-50, 51-200, etc."
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium mb-1 block">Founded Year</label>
                                <Input
                                    value={profileData.founded_year}
                                    onChange={(e) => setProfileData(prev => ({...prev, founded_year: e.target.value}))}
                                    placeholder="2020"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-1 block">Company Description</label>
                            <Textarea
                                value={profileData.company_description}
                                onChange={(e) => setProfileData(prev => ({...prev, company_description: e.target.value}))}
                                placeholder="Tell job seekers about your company..."
                                rows={4}
                            />
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-1 block">Company Culture</label>
                            <Textarea
                                value={profileData.company_culture}
                                onChange={(e) => setProfileData(prev => ({...prev, company_culture: e.target.value}))}
                                placeholder="Describe your company culture, values, and work environment..."
                                rows={3}
                            />
                        </div>

                        <div>
                            <label className="text-sm font-medium mb-1 block">Benefits & Perks</label>
                            <div className="flex flex-wrap gap-2 mb-2">
                                {profileData.benefits.map((benefit, index) => (
                                    <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeBenefit(benefit)}>
                                        {benefit} ×
                                    </Badge>
                                ))}
                            </div>
                            <Input
                                placeholder="Add a benefit and press Enter"
                                onKeyPress={(e) => {
                                    if (e.key === 'Enter') {
                                        addBenefit(e.target.value);
                                        e.target.value = '';
                                    }
                                }}
                            />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm font-medium mb-1 block">Location</label>
                                <Input
                                    value={profileData.location}
                                    onChange={(e) => setProfileData(prev => ({...prev, location: e.target.value}))}
                                    placeholder="City, State"
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium mb-1 block">Phone</label>
                                <Input
                                    value={profileData.phone}
                                    onChange={(e) => setProfileData(prev => ({...prev, phone: e.target.value}))}
                                    placeholder="+1 (555) 123-4567"
                                />
                            </div>
                        </div>

                        <div className="flex justify-end gap-3">
                            <Button variant="outline" onClick={() => setIsEditing(false)}>
                                Cancel
                            </Button>
                            <Button onClick={handleSaveProfile} disabled={isSaving}>
                                {isSaving && <Save className="w-4 h-4 mr-2 animate-spin" />}
                                Save Profile
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Company Overview */}
            {!isEditing && (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-6">
                        {/* About Company */}
                        <Card>
                            <CardHeader>
                                <CardTitle>About {profileData.company_name || 'Our Company'}</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-gray-700 leading-relaxed">
                                    {profileData.company_description || 'No company description provided yet.'}
                                </p>
                                
                                {profileData.company_culture && (
                                    <div className="mt-4">
                                        <h4 className="font-semibold mb-2">Company Culture</h4>
                                        <p className="text-gray-600">{profileData.company_culture}</p>
                                    </div>
                                )}

                                {profileData.benefits.length > 0 && (
                                    <div className="mt-4">
                                        <h4 className="font-semibold mb-2">Benefits & Perks</h4>
                                        <div className="flex flex-wrap gap-2">
                                            {profileData.benefits.map((benefit, index) => (
                                                <Badge key={index} variant="outline">
                                                    {benefit}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {/* Recent Jobs */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Recent Job Postings</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {jobs.slice(0, 5).map((job) => (
                                    <div key={job.id} className="flex items-center justify-between p-3 border-b last:border-b-0">
                                        <div>
                                            <h4 className="font-medium">{job.title}</h4>
                                            <p className="text-sm text-gray-600">{job.location}</p>
                                        </div>
                                        <Badge variant={job.status === 'active' ? 'default' : 'secondary'}>
                                            {job.status}
                                        </Badge>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Company Info Sidebar */}
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle>Company Details</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                {profileData.industry && (
                                    <div className="flex items-center gap-2">
                                        <Briefcase className="w-4 h-4 text-gray-500" />
                                        <span className="text-sm">{profileData.industry}</span>
                                    </div>
                                )}
                                {profileData.company_size && (
                                    <div className="flex items-center gap-2">
                                        <Users className="w-4 h-4 text-gray-500" />
                                        <span className="text-sm">{profileData.company_size} employees</span>
                                    </div>
                                )}
                                {profileData.founded_year && (
                                    <div className="flex items-center gap-2">
                                        <Calendar className="w-4 h-4 text-gray-500" />
                                        <span className="text-sm">Founded {profileData.founded_year}</span>
                                    </div>
                                )}
                                {profileData.company_website && (
                                    <div className="flex items-center gap-2">
                                        <Globe className="w-4 h-4 text-gray-500" />
                                        <a href={profileData.company_website} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:underline">
                                            Company Website
                                        </a>
                                    </div>
                                )}
                                {profileData.phone && (
                                    <div className="flex items-center gap-2">
                                        <Phone className="w-4 h-4 text-gray-500" />
                                        <span className="text-sm">{profileData.phone}</span>
                                    </div>
                                )}
                            </CardContent>
                        </Card>

                        {/* Achievements */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Achievements</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {badges.map((badge, index) => (
                                        <div key={index} className="flex items-center gap-3 p-2 bg-yellow-50 rounded">
                                            <span className="text-2xl">{badge.badge_icon}</span>
                                            <div>
                                                <h4 className="font-medium text-sm">{badge.badge_name}</h4>
                                                <p className="text-xs text-gray-600">{badge.badge_description}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            )}
        </div>
    );
}