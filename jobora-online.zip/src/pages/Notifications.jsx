import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Bell, BellOff, Mail, Briefcase, MessageSquare, Settings, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

export default function NotificationsPage() {
    const [notifications, setNotifications] = useState([]);
    const [settings, setSettings] = useState({
        jobAlerts: true,
        messageAlerts: true,
        interviewReminders: true,
        applicationUpdates: true,
        emailNotifications: true,
        pushNotifications: true
    });

    useEffect(() => {
        // Mock notifications
        const mockNotifications = [
            {
                id: 1,
                type: 'job_match',
                title: 'New Job Match Found!',
                message: 'We found 3 new jobs matching your criteria: Senior React Developer',
                timestamp: '2 hours ago',
                read: false,
                icon: Briefcase
            },
            {
                id: 2,
                type: 'message',
                title: 'New Message from Google',
                message: 'Sarah Johnson sent you a message about the Software Engineer position',
                timestamp: '4 hours ago',
                read: false,
                icon: MessageSquare
            },
            {
                id: 3,
                type: 'application',
                title: 'Application Status Update',
                message: 'Your application to Microsoft has been reviewed',
                timestamp: '1 day ago',
                read: true,
                icon: Mail
            },
            {
                id: 4,
                type: 'reminder',
                title: 'Interview Reminder',
                message: 'Your interview with Meta is scheduled for tomorrow at 2 PM',
                timestamp: '2 days ago',
                read: true,
                icon: Bell
            }
        ];
        setNotifications(mockNotifications);
    }, []);

    const markAsRead = (id) => {
        setNotifications(prev => 
            prev.map(notif => 
                notif.id === id ? { ...notif, read: true } : notif
            )
        );
    };

    const deleteNotification = (id) => {
        setNotifications(prev => prev.filter(notif => notif.id !== id));
        toast.success('Notification deleted');
    };

    const markAllAsRead = () => {
        setNotifications(prev => prev.map(notif => ({ ...notif, read: true })));
        toast.success('All notifications marked as read');
    };

    const updateSetting = (key, value) => {
        setSettings(prev => ({ ...prev, [key]: value }));
        toast.success('Settings updated');
    };

    const unreadCount = notifications.filter(n => !n.read).length;

    const getTypeColor = (type) => {
        switch (type) {
            case 'job_match': return 'bg-blue-100 text-blue-800';
            case 'message': return 'bg-green-100 text-green-800';
            case 'application': return 'bg-purple-100 text-purple-800';
            case 'reminder': return 'bg-orange-100 text-orange-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-4">
            <div className="max-w-4xl mx-auto space-y-6">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
                        {unreadCount > 0 && (
                            <Badge className="bg-red-100 text-red-800">
                                {unreadCount} unread
                            </Badge>
                        )}
                    </div>
                    <Button onClick={markAllAsRead} variant="outline">
                        Mark all as read
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Notifications List */}
                    <div className="lg:col-span-2 space-y-3">
                        {notifications.length > 0 ? (
                            notifications.map((notif) => (
                                <motion.div
                                    key={notif.id}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                >
                                    <Card className={`${notif.read ? 'opacity-75' : ''} hover:shadow-md transition-shadow`}>
                                        <CardContent className="p-4">
                                            <div className="flex items-start justify-between">
                                                <div className="flex items-start gap-3">
                                                    <div className={`p-2 rounded-lg ${getTypeColor(notif.type)}`}>
                                                        <notif.icon className="w-4 h-4" />
                                                    </div>
                                                    <div className="flex-1">
                                                        <h3 className={`font-medium ${notif.read ? 'text-gray-600' : 'text-gray-900'}`}>
                                                            {notif.title}
                                                        </h3>
                                                        <p className="text-sm text-gray-600 mt-1">{notif.message}</p>
                                                        <span className="text-xs text-gray-400 mt-2 block">{notif.timestamp}</span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    {!notif.read && (
                                                        <Button
                                                            size="sm"
                                                            variant="ghost"
                                                            onClick={() => markAsRead(notif.id)}
                                                        >
                                                            Mark as read
                                                        </Button>
                                                    )}
                                                    <Button
                                                        size="sm"
                                                        variant="ghost"
                                                        onClick={() => deleteNotification(notif.id)}
                                                        className="text-red-600 hover:text-red-700"
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            ))
                        ) : (
                            <Card>
                                <CardContent className="p-8 text-center">
                                    <BellOff className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                                    <p className="text-gray-500">No notifications yet</p>
                                </CardContent>
                            </Card>
                        )}
                    </div>

                    {/* Settings Panel */}
                    <div className="lg:col-span-1">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2">
                                    <Settings className="w-5 h-5" />
                                    Notification Settings
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Job Alerts</p>
                                            <p className="text-sm text-gray-500">New job matches</p>
                                        </div>
                                        <Switch
                                            checked={settings.jobAlerts}
                                            onCheckedChange={(checked) => updateSetting('jobAlerts', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Messages</p>
                                            <p className="text-sm text-gray-500">New messages from recruiters</p>
                                        </div>
                                        <Switch
                                            checked={settings.messageAlerts}
                                            onCheckedChange={(checked) => updateSetting('messageAlerts', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Interview Reminders</p>
                                            <p className="text-sm text-gray-500">Upcoming interviews</p>
                                        </div>
                                        <Switch
                                            checked={settings.interviewReminders}
                                            onCheckedChange={(checked) => updateSetting('interviewReminders', checked)}
                                        />
                                    </div>
                                    
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="font-medium">Application Updates</p>
                                            <p className="text-sm text-gray-500">Status changes</p>
                                        </div>
                                        <Switch
                                            checked={settings.applicationUpdates}
                                            onCheckedChange={(checked) => updateSetting('applicationUpdates', checked)}
                                        />
                                    </div>
                                    
                                    <div className="border-t pt-4">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <p className="font-medium">Email Notifications</p>
                                                <p className="text-sm text-gray-500">Receive via email</p>
                                            </div>
                                            <Switch
                                                checked={settings.emailNotifications}
                                                onCheckedChange={(checked) => updateSetting('emailNotifications', checked)}
                                            />
                                        </div>
                                        
                                        <div className="flex items-center justify-between mt-4">
                                            <div>
                                                <p className="font-medium">Push Notifications</p>
                                                <p className="text-sm text-gray-500">Browser notifications</p>
                                            </div>
                                            <Switch
                                                checked={settings.pushNotifications}
                                                onCheckedChange={(checked) => updateSetting('pushNotifications', checked)}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}