
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Job } from '@/api/entities';
import { EasyApplication } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
    Loader2, Users, Briefcase, Eye, BarChart, MoreHorizontal, Plus, Edit, Trash2, Play, Pause, AlertCircle, CheckCircle, Award, DownloadCloud
} from 'lucide-react';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function EmployerDashboard() {
    const [currentUser, setCurrentUser] = useState(null);
    const [jobs, setJobs] = useState([]);
    const [applications, setApplications] = useState([]);
    const [stats, setStats] = useState({
        activeJobs: 0,
        totalJobs: 0,
        totalApplicants: 0,
        totalViews: 0
    });
    const [isLoading, setIsLoading] = useState(true);
    const [isPremium, setIsPremium] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const loadDashboardData = async () => {
            setIsLoading(true);
            try {
                const user = await User.me();
                setCurrentUser(user);
                console.log("Current user for dashboard:", user.email);

                // DEBUG: Fetch all jobs to diagnose filtering issues, then filter client-side
                const allJobs = await Job.list('-created_date', 200);
                console.log(`Found ${allJobs.length} total jobs. Filtering for user ${user.email}...`);

                const employerJobs = allJobs.filter(job => job.created_by === user.email);
                console.log(`Found ${employerJobs.length} jobs created by this user.`);

                // Load applications for employer's jobs
                const allApplications = [];
                if (employerJobs.length > 0) {
                    for (const job of employerJobs) {
                        try {
                            const jobApplications = await EasyApplication.filter({ job_id: job.id });
                            allApplications.push(...jobApplications);
                        } catch (error) {
                            console.log("No applications found for job:", job.id);
                        }
                    }
                }
                
                // Calculate applications_count for each job
                const jobApplicationsMap = new Map();
                allApplications.forEach(app => {
                    jobApplicationsMap.set(app.job_id, (jobApplicationsMap.get(app.job_id) || 0) + 1);
                });

                // Enhance employerJobs with application counts and ensure views_count is present
                const jobsWithCounts = employerJobs.map(job => ({
                    ...job,
                    applications_count: jobApplicationsMap.get(job.id) || 0,
                    views_count: job.views_count || 0
                }));

                setJobs(jobsWithCounts);
                setApplications(allApplications);

                // Calculate stats
                const activeJobs = jobsWithCounts.filter(job => job.status === 'active').length;
                const totalViews = jobsWithCounts.reduce((sum, job) => sum + (job.views_count || 0), 0);
                
                setStats({
                    activeJobs,
                    totalJobs: jobsWithCounts.length,
                    totalApplicants: allApplications.length,
                    totalViews
                });

                // Check if user qualifies for premium (500+ jobs posted)
                if (jobsWithCounts.length >= 500) {
                    setIsPremium(true);
                    if (!user.has_premium_from_posts) {
                        await User.updateMyUserData({ has_premium_from_posts: true });
                        toast.success("🎉 You've earned Premium features for posting 500+ jobs!");
                    }
                }
                
            } catch (error) {
                console.error("Error loading dashboard data:", error);
                toast.error("Failed to load dashboard data: " + error.message);
            } finally {
                setIsLoading(false);
            }
        };

        loadDashboardData();
    }, []);

    const handleJobStatusChange = async (jobId, newStatus) => {
        try {
            setIsLoading(true); // Indicate loading
            await Job.update(jobId, { status: newStatus });
            toast.success(`Job ${newStatus === 'active' ? 'activated' : 'paused'}!`);
            // To ensure UI reflects changes without a full page refresh,
            // we re-fetch the data or update state manually.
            // Since refreshKey was removed, a full reload is typically needed.
            // For now, reload the entire dashboard data
            const user = await User.me(); // Re-fetch user to ensure latest data
            const allJobs = await Job.list('-created_date', 200);
            const employerJobs = allJobs.filter(job => job.created_by === user.email);

            const allApplications = [];
            for (const job of employerJobs) {
                try {
                    const jobApplications = await EasyApplication.filter({ job_id: job.id });
                    allApplications.push(...jobApplications);
                } catch (error) { /* console.log("No applications for job:", job.id); */ }
            }
            const jobApplicationsMap = new Map();
            allApplications.forEach(app => {
                jobApplicationsMap.set(app.job_id, (jobApplicationsMap.get(app.job_id) || 0) + 1);
            });
            const jobsWithCounts = employerJobs.map(job => ({
                ...job,
                applications_count: jobApplicationsMap.get(job.id) || 0,
                views_count: job.views_count || 0
            }));
            setJobs(jobsWithCounts);

            setIsLoading(false); // End loading
        } catch (error) {
            console.error("Error updating job status:", error);
            toast.error("Failed to update job status");
            setIsLoading(false); // End loading on error
        }
    };

    const handleDeleteJob = async (jobId) => {
        if (!confirm("Are you sure you want to delete this job posting?")) return;
        
        try {
            setIsLoading(true); // Indicate loading
            await Job.delete(jobId);
            toast.success("Job deleted successfully");
            // To ensure UI reflects changes without a full page refresh,
            // we re-fetch the data or update state manually.
            // Since refreshKey was removed, a full reload is typically needed.
            // For now, reload the entire dashboard data
            const user = await User.me(); // Re-fetch user to ensure latest data
            const allJobs = await Job.list('-created_date', 200);
            const employerJobs = allJobs.filter(job => job.created_by === user.email);

            const allApplications = [];
            for (const job of employerJobs) {
                try {
                    const jobApplications = await EasyApplication.filter({ job_id: job.id });
                    allApplications.push(...jobApplications);
                } catch (error) { /* console.log("No applications for job:", job.id); */ }
            }
            const jobApplicationsMap = new Map();
            allApplications.forEach(app => {
                jobApplicationsMap.set(app.job_id, (jobApplicationsMap.get(app.job_id) || 0) + 1);
            });
            const jobsWithCounts = employerJobs.map(job => ({
                ...job,
                applications_count: jobApplicationsMap.get(job.id) || 0,
                views_count: job.views_count || 0
            }));
            setJobs(jobsWithCounts);

            setIsLoading(false); // End loading
        } catch (error) {
            console.error("Error deleting job:", error);
            toast.error("Failed to delete job");
            setIsLoading(false); // End loading on error
        }
    };

    if (isLoading && jobs.length === 0) { // Only show full loading if no jobs loaded yet
        return (
            <div className="text-center p-10">
                <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
                <p>Loading your dashboard...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <header className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold">Employer Dashboard</h1>
                    <p className="text-gray-500">Manage your job postings and applicants.</p>
                </div>
                <div className="flex items-center gap-2">
                    {isPremium && (
                        <Badge className="bg-yellow-100 text-yellow-800 text-sm">
                            <Award className="w-4 h-4 mr-1" />
                            Premium Account
                        </Badge>
                    )}
                    <Button asChild variant="outline">
                        <Link to={createPageUrl('AdminScraper')}>
                            <DownloadCloud className="mr-2 h-4 w-4" />
                            Import Jobs
                        </Link>
                    </Button>
                    <Button onClick={() => navigate(createPageUrl("PostJob"))}>
                        <Plus className="mr-2 h-4 w-4" />
                        Post a Job
                    </Button>
                </div>
            </header>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
                        <Briefcase className="h-4 w-4 text-gray-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.activeJobs}</div>
                        <p className="text-xs text-gray-500">out of {stats.totalJobs} total jobs</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Applicants</CardTitle>
                        <Users className="h-4 w-4 text-gray-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.totalApplicants}</div>
                        <p className="text-xs text-gray-500">across all jobs</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Views</CardTitle>
                        <Eye className="h-4 w-4 text-gray-500" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold">{stats.totalViews}</div>
                        <p className="text-xs text-gray-500">on all your postings</p>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Applicant Analytics</CardTitle>
                        <BarChart className="h-4 w-4 text-gray-500" />
                    </CardHeader>
                    <CardContent>
                        <Link to={createPageUrl("Applicants")} className="text-sm font-semibold text-blue-600 hover:underline">
                            View Detailed Report &rarr;
                        </Link>
                    </CardContent>
                </Card>
            </div>

            {/* Job Postings Table */}
            <Card>
                <CardHeader>
                    <CardTitle>Your Job Postings</CardTitle>
                    <CardDescription>Manage your active and paused jobs.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[300px]">Job Title</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Applicants</TableHead>
                                <TableHead>Views</TableHead>
                                <TableHead>Posted On</TableHead>
                                <TableHead><span className="sr-only">Actions</span></TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading && jobs.length === 0 ? ( // Show loader inside table if data is initially loading
                                <TableRow>
                                    <TableCell colSpan="6" className="h-24 text-center">
                                        <Loader2 className="mx-auto h-6 w-6 animate-spin" />
                                    </TableCell>
                                </TableRow>
                            ) : jobs.length > 0 ? (
                                jobs.map((job) => (
                                    <TableRow key={job.id}>
                                        <TableCell className="font-medium">{job.title}</TableCell>
                                        <TableCell>
                                            <Badge
                                                variant={job.status === 'active' ? 'default' : 'outline'}
                                                className={job.status === 'active' ? 'bg-green-100 text-green-800' : ''}
                                            >
                                                {job.status === 'active' ? <CheckCircle className="mr-1 h-3 w-3" /> : <Pause className="mr-1 h-3 w-3" />}
                                                {job.status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell>{job.applications_count}</TableCell>
                                        <TableCell>{job.views_count}</TableCell>
                                        <TableCell>{new Date(job.created_date).toLocaleDateString()}</TableCell>
                                        <TableCell>
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" className="h-8 w-8 p-0">
                                                        <span className="sr-only">Open menu</span>
                                                        <MoreHorizontal className="h-4 w-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end">
                                                    <DropdownMenuItem onClick={() => navigate(createPageUrl(`Applicants?job_id=${job.id}`))}>
                                                        View Applicants
                                                    </DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => navigate(createPageUrl(`PostJob?edit=${job.id}`))}>
                                                        Edit
                                                    </DropdownMenuItem>
                                                    {job.status === 'active' ? (
                                                        <DropdownMenuItem onClick={() => handleJobStatusChange(job.id, 'paused')}>
                                                            Pause
                                                        </DropdownMenuItem>
                                                    ) : (
                                                        <DropdownMenuItem onClick={() => handleJobStatusChange(job.id, 'active')}>
                                                            Activate
                                                        </DropdownMenuItem>
                                                    )}
                                                    <DropdownMenuItem className="text-red-600" onClick={() => handleDeleteJob(job.id)}>
                                                        Delete
                                                    </DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan="6" className="py-10 text-center">
                                        <Briefcase className="mx-auto h-12 w-12 text-gray-400" />
                                        <h3 className="mt-2 text-lg font-medium">No Jobs Posted Yet</h3>
                                        <p className="mt-1 text-sm text-gray-500">
                                            Your posted jobs will appear here.
                                        </p>
                                        <div className="mt-6">
                                            <Button onClick={() => navigate(createPageUrl("PostJob"))}>
                                                <Plus className="mr-2 h-4 w-4" />
                                                Post Your First Job
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
