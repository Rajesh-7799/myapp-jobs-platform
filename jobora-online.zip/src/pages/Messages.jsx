
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mail, Send, Search, Building, Clock, Star, Plus, MessageCircle, Crown, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { User } from '@/api/entities';
import { Subscription } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';


export default function MessagesPage() {
    const [conversations, setConversations] = useState([]);
    const [selectedConversation, setSelectedConversation] = useState(null);
    const [newMessage, setNewMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            try {
                // Subscription check
                const user = await User.me();
                if (user) {
                    const subscriptions = await Subscription.filter({ created_by: user.email }, '-created_date', 1);
                    const hasActiveSub = subscriptions.some(s => ['active', 'trial'].includes(s.status));
                    setIsSubscribed(hasActiveSub);
                }

                // Mock conversations (keeping this as is for now)
                const mockConversations = [
                    {
                        id: 1,
                        company: 'Google',
                        recruiter: 'Sarah Johnson',
                        role: 'Senior Software Engineer',
                        lastMessage: 'Thanks for your interest! We would like to schedule an interview.',
                        timestamp: '2 hours ago',
                        unread: 2,
                        status: 'active'
                    },
                    {
                        id: 2,
                        company: 'Microsoft',
                        recruiter: 'Mike Chen',
                        role: 'Product Manager',
                        lastMessage: 'Could you provide more details about your experience with Azure?',
                        timestamp: '1 day ago',
                        unread: 0,
                        status: 'pending'
                    },
                    {
                        id: 3,
                        company: 'Meta',
                        recruiter: 'Lisa Rodriguez',
                        role: 'Full Stack Developer',
                        lastMessage: 'Great! Looking forward to our call tomorrow.',
                        timestamp: '3 days ago',
                        unread: 1,
                        status: 'scheduled'
                    }
                ];
                setConversations(mockConversations);
                if (mockConversations.length > 0) {
                    setSelectedConversation(mockConversations[0]);
                }
            } catch (error) {
                console.error("Error loading page data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        loadData();
    }, []);

    const filteredConversations = conversations.filter(conv =>
        conv.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        conv.recruiter.toLowerCase().includes(searchTerm.toLowerCase()) ||
        conv.role.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getStatusColor = (status) => {
        switch (status) {
            case 'active': return 'bg-green-100 text-green-800';
            case 'pending': return 'bg-yellow-100 text-yellow-800';
            case 'scheduled': return 'bg-blue-100 text-blue-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const handleSendMessage = (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !isSubscribed) return;
        
        // Mock sending message
        console.log('Sending message:', newMessage);
        setNewMessage('');
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-full pt-16">
                <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 p-4">
            <div className="max-w-7xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                    <h1 className="text-3xl font-bold text-gray-900">Messages</h1>
                    <Button 
                        className="bg-blue-600 hover:bg-blue-700" 
                        disabled={!isSubscribed}
                        title={!isSubscribed ? "Upgrade to send new messages" : ""}
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        New Message
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
                    {/* Conversations List */}
                    <div className="lg:col-span-1">
                        <Card className="h-full">
                            <CardHeader className="pb-3">
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                    <Input
                                        placeholder="Search conversations..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="pl-10"
                                    />
                                </div>
                            </CardHeader>
                            <CardContent className="p-0 overflow-y-auto">
                                <div className="space-y-1">
                                    {filteredConversations.map((conv) => (
                                        <motion.div
                                            key={conv.id}
                                            initial={{ opacity: 0, y: 10 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            className={`p-4 cursor-pointer border-b transition-colors ${
                                                selectedConversation?.id === conv.id
                                                    ? 'bg-blue-50 border-blue-200'
                                                    : 'hover:bg-gray-50'
                                            }`}
                                            onClick={() => setSelectedConversation(conv)}
                                        >
                                            <div className="flex items-start justify-between mb-2">
                                                <div className="flex items-center gap-2">
                                                    <Building className="w-4 h-4 text-gray-500" />
                                                    <span className="font-semibold text-sm">{conv.company}</span>
                                                    {conv.unread > 0 && (
                                                        <Badge className="bg-red-100 text-red-800 text-xs">
                                                            {conv.unread}
                                                        </Badge>
                                                    )}
                                                </div>
                                                <Badge className={`text-xs ${getStatusColor(conv.status)}`}>
                                                    {conv.status}
                                                </Badge>
                                            </div>
                                            <p className="text-sm text-gray-600 mb-1">{conv.role}</p>
                                            <p className="text-sm text-gray-500 mb-1">with {conv.recruiter}</p>
                                            <p className="text-xs text-gray-400 truncate">{conv.lastMessage}</p>
                                            <div className="flex items-center gap-1 mt-2">
                                                <Clock className="w-3 h-3 text-gray-400" />
                                                <span className="text-xs text-gray-400">{conv.timestamp}</span>
                                            </div>
                                        </motion.div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Chat Area */}
                    <div className="lg:col-span-2">
                        <Card className="h-full flex flex-col">
                            {selectedConversation ? (
                                <>
                                    <CardHeader className="border-b">
                                        <div className="flex items-center justify-between">
                                            <div>
                                                <CardTitle className="text-lg">{selectedConversation.company}</CardTitle>
                                                <p className="text-sm text-gray-600">{selectedConversation.role} • {selectedConversation.recruiter}</p>
                                            </div>
                                            <Badge className={`${getStatusColor(selectedConversation.status)}`}>
                                                {selectedConversation.status}
                                            </Badge>
                                        </div>
                                    </CardHeader>
                                    
                                    <CardContent className="flex-1 p-6 overflow-y-auto">
                                        <div className="space-y-4">
                                            {/* Mock messages */}
                                            <div className="flex justify-start">
                                                <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
                                                    <p className="text-sm">Hi! I saw your application for the {selectedConversation.role} position. Your background looks impressive!</p>
                                                    <span className="text-xs text-gray-500 mt-1 block">Yesterday 2:30 PM</span>
                                                </div>
                                            </div>
                                            <div className="flex justify-end">
                                                <div className="bg-blue-600 text-white rounded-lg p-3 max-w-xs">
                                                    <p className="text-sm">Thank you! I'm very excited about this opportunity and would love to discuss further.</p>
                                                    <span className="text-xs text-blue-200 mt-1 block">Yesterday 3:15 PM</span>
                                                </div>
                                            </div>
                                            <div className="flex justify-start">
                                                <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
                                                    <p className="text-sm">{selectedConversation.lastMessage}</p>
                                                    <span className="text-xs text-gray-500 mt-1 block">{selectedConversation.timestamp}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                    
                                    <div className="p-4 border-t">
                                        {!isSubscribed ? (
                                            <div className="text-center p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                                <Crown className="w-6 h-6 mx-auto mb-2 text-yellow-600" />
                                                <h4 className="font-semibold text-yellow-800">Unlock Unlimited Messaging</h4>
                                                <p className="text-sm text-yellow-700 mb-3">Upgrade to Premium to reply to recruiters and send new messages.</p>
                                                <Button asChild size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-white">
                                                    <Link to={createPageUrl('Profile') + '#subscription'}>Upgrade Now</Link>
                                                </Button>
                                            </div>
                                        ) : (
                                            <form onSubmit={handleSendMessage} className="flex gap-3">
                                                <Input
                                                    value={newMessage}
                                                    onChange={(e) => setNewMessage(e.target.value)}
                                                    placeholder="Type your message..."
                                                    className="flex-1"
                                                />
                                                <Button type="submit" disabled={!newMessage.trim()}>
                                                    <Send className="w-4 h-4" />
                                                </Button>
                                            </form>
                                        )}
                                    </div>
                                </>
                            ) : (
                                <div className="flex-1 flex items-center justify-center">
                                    <div className="text-center">
                                        <MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                                        <p className="text-gray-500">Select a conversation to start messaging</p>
                                    </div>
                                </div>
                            )}
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}
