import React, { useState, useEffect } from 'react';
import { EasyApplication } from '@/api/entities';
import { Job } from '@/api/entities';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Users, Download, ExternalLink, Mail, Phone, Linkedin, Globe, Calendar, FileText } from 'lucide-react';
import { toast } from 'sonner';

export default function ApplicantsPage() {
    const [applications, setApplications] = useState([]);
    const [jobs, setJobs] = useState([]);
    const [filteredApplications, setFilteredApplications] = useState([]);
    const [selectedJob, setSelectedJob] = useState('all');
    const [selectedStatus, setSelectedStatus] = useState('all');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        loadApplications();
    }, []);

    useEffect(() => {
        filterApplications();
    }, [applications, selectedJob, selectedStatus]);

    const loadApplications = async () => {
        setIsLoading(true);
        try {
            const user = await User.me();
            
            // Get all jobs posted by this employer
            const employerJobs = await Job.filter({ created_by: user.email });
            setJobs(employerJobs);

            // Get all applications for these jobs
            const allApplications = [];
            for (const job of employerJobs) {
                const jobApplications = await EasyApplication.filter({ job_id: job.id });
                allApplications.push(...jobApplications);
            }
            
            setApplications(allApplications);
        } catch (error) {
            console.error("Error loading applications:", error);
            toast.error("Failed to load applications");
        } finally {
            setIsLoading(false);
        }
    };

    const filterApplications = () => {
        let filtered = applications;
        
        if (selectedJob !== 'all') {
            filtered = filtered.filter(app => app.job_id === selectedJob);
        }
        
        if (selectedStatus !== 'all') {
            filtered = filtered.filter(app => app.status === selectedStatus);
        }
        
        setFilteredApplications(filtered);
    };

    const updateApplicationStatus = async (applicationId, newStatus, notes = '') => {
        try {
            await EasyApplication.update(applicationId, { 
                status: newStatus,
                employer_notes: notes 
            });
            toast.success("Application status updated");
            loadApplications(); // Refresh data
        } catch (error) {
            console.error("Error updating application:", error);
            toast.error("Failed to update application status");
        }
    };

    const getJobTitle = (jobId) => {
        const job = jobs.find(j => j.id === jobId);
        return job ? job.title : 'Unknown Job';
    };

    if (isLoading) {
        return <div className="text-center p-10">Loading applications...</div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Job Applications</h1>
                    <p className="text-gray-600 mt-1">Review and manage candidate applications</p>
                </div>
                <Badge variant="outline" className="text-lg px-3 py-1">
                    {filteredApplications.length} applications
                </Badge>
            </div>

            {/* Filters */}
            <Card>
                <CardContent className="pt-6">
                    <div className="flex gap-4">
                        <div className="flex-1">
                            <label className="text-sm font-medium mb-1 block">Filter by Job</label>
                            <Select value={selectedJob} onValueChange={setSelectedJob}>
                                <SelectTrigger>
                                    <SelectValue placeholder="All Jobs" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Jobs ({applications.length})</SelectItem>
                                    {jobs.map(job => {
                                        const jobAppCount = applications.filter(app => app.job_id === job.id).length;
                                        return (
                                            <SelectItem key={job.id} value={job.id}>
                                                {job.title} ({jobAppCount})
                                            </SelectItem>
                                        );
                                    })}
                                </SelectContent>
                            </Select>
                        </div>
                        
                        <div className="flex-1">
                            <label className="text-sm font-medium mb-1 block">Filter by Status</label>
                            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                                <SelectTrigger>
                                    <SelectValue placeholder="All Statuses" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Statuses</SelectItem>
                                    <SelectItem value="submitted">New Applications</SelectItem>
                                    <SelectItem value="reviewed">Reviewed</SelectItem>
                                    <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                                    <SelectItem value="offered">Offered</SelectItem>
                                    <SelectItem value="rejected">Rejected</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Applications List */}
            {filteredApplications.length === 0 ? (
                <Card>
                    <CardContent className="text-center py-12">
                        <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <h3 className="text-lg font-medium mb-2">No applications yet</h3>
                        <p className="text-gray-600">
                            {applications.length === 0 
                                ? "When candidates apply to your jobs, they'll appear here."
                                : "No applications match your current filters."
                            }
                        </p>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-4">
                    {filteredApplications.map((application) => (
                        <Card key={application.id}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-lg">{application.applicant_name}</CardTitle>
                                        <CardDescription>
                                            Applied for: {getJobTitle(application.job_id)}
                                        </CardDescription>
                                        <div className="flex items-center gap-2 mt-2">
                                            <Badge variant={
                                                application.status === 'submitted' ? 'default' :
                                                application.status === 'reviewed' ? 'secondary' :
                                                application.status === 'interview_scheduled' ? 'outline' :
                                                application.status === 'offered' ? 'default' :
                                                'destructive'
                                            }>
                                                {application.status.replace('_', ' ')}
                                            </Badge>
                                            <span className="text-sm text-gray-500">
                                                <Calendar className="w-4 h-4 inline mr-1" />
                                                {new Date(application.application_date).toLocaleDateString()}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </CardHeader>
                            <CardContent>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {/* Applicant Info */}
                                    <div>
                                        <h4 className="font-semibold mb-3">Contact Information</h4>
                                        <div className="space-y-2">
                                            <div className="flex items-center gap-2">
                                                <Mail className="w-4 h-4 text-gray-500" />
                                                <a href={`mailto:${application.applicant_email}`} className="text-blue-600 hover:underline">
                                                    {application.applicant_email}
                                                </a>
                                            </div>
                                            {application.applicant_phone && (
                                                <div className="flex items-center gap-2">
                                                    <Phone className="w-4 h-4 text-gray-500" />
                                                    <a href={`tel:${application.applicant_phone}`} className="text-blue-600 hover:underline">
                                                        {application.applicant_phone}
                                                    </a>
                                                </div>
                                            )}
                                            {application.linkedin_url && (
                                                <div className="flex items-center gap-2">
                                                    <Linkedin className="w-4 h-4 text-gray-500" />
                                                    <a href={application.linkedin_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                                                        LinkedIn Profile
                                                    </a>
                                                </div>
                                            )}
                                            {application.portfolio_url && (
                                                <div className="flex items-center gap-2">
                                                    <Globe className="w-4 h-4 text-gray-500" />
                                                    <a href={application.portfolio_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                                                        Portfolio
                                                    </a>
                                                </div>
                                            )}
                                        </div>

                                        {application.skills && application.skills.length > 0 && (
                                            <div className="mt-4">
                                                <h4 className="font-semibold mb-2">Skills</h4>
                                                <div className="flex flex-wrap gap-2">
                                                    {application.skills.map((skill, index) => (
                                                        <Badge key={index} variant="outline" className="text-xs">
                                                            {skill}
                                                        </Badge>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        {application.experience_years && (
                                            <div className="mt-4">
                                                <h4 className="font-semibold mb-2">Experience</h4>
                                                <p className="text-sm text-gray-600">{application.experience_years} years</p>
                                            </div>
                                        )}
                                    </div>

                                    {/* Actions */}
                                    <div>
                                        <h4 className="font-semibold mb-3">Actions</h4>
                                        <div className="space-y-3">
                                            {application.resume_url && (
                                                <Button variant="outline" className="w-full justify-start" asChild>
                                                    <a href={application.resume_url} target="_blank" rel="noopener noreferrer">
                                                        <FileText className="w-4 h-4 mr-2" />
                                                        View Resume
                                                    </a>
                                                </Button>
                                            )}

                                            <div>
                                                <label className="text-sm font-medium mb-1 block">Update Status</label>
                                                <Select 
                                                    value={application.status} 
                                                    onValueChange={(value) => updateApplicationStatus(application.id, value)}
                                                >
                                                    <SelectTrigger>
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="submitted">New Application</SelectItem>
                                                        <SelectItem value="reviewed">Reviewed</SelectItem>
                                                        <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                                                        <SelectItem value="offered">Offered</SelectItem>
                                                        <SelectItem value="rejected">Rejected</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Cover Letter */}
                                {application.cover_letter && (
                                    <div className="mt-6">
                                        <h4 className="font-semibold mb-2">Cover Letter</h4>
                                        <div className="bg-gray-50 p-4 rounded-lg">
                                            <p className="text-sm whitespace-pre-wrap">{application.cover_letter}</p>
                                        </div>
                                    </div>
                                )}

                                {/* Employer Notes */}
                                <div className="mt-6">
                                    <label className="text-sm font-medium mb-1 block">Your Notes</label>
                                    <Textarea
                                        value={application.employer_notes || ''}
                                        onChange={(e) => {
                                            // Auto-save notes after user stops typing
                                            const notes = e.target.value;
                                            setTimeout(() => {
                                                updateApplicationStatus(application.id, application.status, notes);
                                            }, 1000);
                                        }}
                                        placeholder="Add your notes about this candidate..."
                                        rows={3}
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}