import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Subscription } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { 
    MessageSquare, Send, Phone, Video, MoreHorizontal, 
    Search, Users, Crown, Loader2, Clock, CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import UpgradePrompt from '../components/UpgradePrompt';

const mockRecruiters = [
    {
        id: 1,
        name: "Sarah Johnson",
        company: "TechCorp Inc.",
        position: "Senior Recruiter",
        avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
        isOnline: true,
        lastMessage: "Thanks for your interest in the Senior Developer position!",
        lastMessageTime: "2 min ago",
        unreadCount: 2
    },
    {
        id: 2,
        name: "Michael Chen",
        company: "StartupHub",
        position: "Talent Acquisition Lead",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
        isOnline: false,
        lastMessage: "Could you share more details about your React experience?",
        lastMessageTime: "1 hour ago",
        unreadCount: 0
    },
    {
        id: 3,
        name: "Emily Rodriguez",
        company: "Global Solutions",
        position: "HR Director",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
        isOnline: true,
        lastMessage: "We'd like to schedule an interview with you.",
        lastMessageTime: "3 hours ago",
        unreadCount: 1
    }
];

const mockMessages = [
    {
        id: 1,
        senderId: 1,
        senderName: "Sarah Johnson",
        message: "Hi! I saw your profile and I'm impressed with your background.",
        timestamp: "2024-01-20T10:30:00Z",
        isRecruiter: true
    },
    {
        id: 2,
        senderId: "user",
        senderName: "You",
        message: "Thank you! I'm very interested in learning more about the position.",
        timestamp: "2024-01-20T10:32:00Z",
        isRecruiter: false
    },
    {
        id: 3,
        senderId: 1,
        senderName: "Sarah Johnson",
        message: "Great! The role is for a Senior Developer position at TechCorp. Are you currently looking for new opportunities?",
        timestamp: "2024-01-20T10:35:00Z",
        isRecruiter: true
    },
    {
        id: 4,
        senderId: "user",
        senderName: "You",
        message: "Yes, I am! Could you tell me more about the team and the tech stack?",
        timestamp: "2024-01-20T10:40:00Z",
        isRecruiter: false
    },
    {
        id: 5,
        senderId: 1,
        senderName: "Sarah Johnson",
        message: "Thanks for your interest in the Senior Developer position!",
        timestamp: "2024-01-20T11:00:00Z",
        isRecruiter: true
    }
];

export default function RecruiterChatPage() {
    const [selectedRecruiter, setSelectedRecruiter] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [isSubscribed, setIsSubscribed] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const checkSubscription = async () => {
            try {
                const user = await User.me();
                if (user) {
                    const subscriptions = await Subscription.filter({ created_by: user.email }, '-created_date', 1);
                    const hasActiveSub = subscriptions.some(s => ['active', 'trial'].includes(s.status));
                    setIsSubscribed(hasActiveSub);
                }
            } catch (error) {
                console.error("Error checking subscription:", error);
                setIsSubscribed(false);
            } finally {
                setIsLoading(false);
            }
        };

        checkSubscription();
    }, []);

    useEffect(() => {
        if (selectedRecruiter) {
            setMessages(mockMessages.filter(msg => msg.senderId === selectedRecruiter.id || msg.senderId === "user"));
        }
    }, [selectedRecruiter]);

    const handleSendMessage = () => {
        if (!newMessage.trim() || !selectedRecruiter) return;
        
        const message = {
            id: Date.now(),
            senderId: "user",
            senderName: "You",
            message: newMessage,
            timestamp: new Date().toISOString(),
            isRecruiter: false
        };
        
        setMessages(prev => [...prev, message]);
        setNewMessage('');
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-64">
                <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
            </div>
        );
    }

    if (!isSubscribed) {
        return (
            <UpgradePrompt 
                featureName="Recruiter Conversations"
                description="Connect directly with recruiters and hiring managers. Get personalized job opportunities and build professional relationships. Upgrade to Premium to start chatting."
            />
        );
    }

    const filteredRecruiters = mockRecruiters.filter(recruiter =>
        recruiter.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recruiter.company.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="h-[calc(100vh-120px)] flex bg-white rounded-lg border overflow-hidden">
            {/* Recruiters List */}
            <div className="w-1/3 border-r bg-gray-50 flex flex-col">
                <div className="p-4 border-b bg-white">
                    <div className="flex items-center gap-2 mb-3">
                        <Users className="w-5 h-5 text-purple-600" />
                        <h2 className="font-semibold text-gray-900">Recruiters</h2>
                        <Badge className="bg-purple-100 text-purple-800">
                            {mockRecruiters.length}
                        </Badge>
                    </div>
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <Input
                            placeholder="Search recruiters..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                    {filteredRecruiters.map((recruiter) => (
                        <motion.div
                            key={recruiter.id}
                            whileHover={{ backgroundColor: "#f8fafc" }}
                            onClick={() => setSelectedRecruiter(recruiter)}
                            className={`p-4 cursor-pointer border-b transition-colors ${
                                selectedRecruiter?.id === recruiter.id ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'
                            }`}
                        >
                            <div className="flex items-start gap-3">
                                <div className="relative">
                                    <Avatar className="w-12 h-12">
                                        <AvatarImage src={recruiter.avatar} alt={recruiter.name} />
                                        <AvatarFallback>{recruiter.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                    </Avatar>
                                    {recruiter.isOnline && (
                                        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                                    )}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-1">
                                        <h3 className="font-semibold text-sm text-gray-900 truncate">{recruiter.name}</h3>
                                        {recruiter.unreadCount > 0 && (
                                            <Badge className="bg-blue-600 text-white text-xs h-5 w-5 p-0 flex items-center justify-center rounded-full">
                                                {recruiter.unreadCount}
                                            </Badge>
                                        )}
                                    </div>
                                    <p className="text-xs text-gray-600 mb-1">{recruiter.position} at {recruiter.company}</p>
                                    <p className="text-xs text-gray-500 truncate">{recruiter.lastMessage}</p>
                                    <p className="text-xs text-gray-400 mt-1">{recruiter.lastMessageTime}</p>
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 flex flex-col">
                {selectedRecruiter ? (
                    <>
                        {/* Chat Header */}
                        <div className="p-4 border-b bg-white flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <div className="relative">
                                    <Avatar className="w-10 h-10">
                                        <AvatarImage src={selectedRecruiter.avatar} alt={selectedRecruiter.name} />
                                        <AvatarFallback>{selectedRecruiter.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                    </Avatar>
                                    {selectedRecruiter.isOnline && (
                                        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                                    )}
                                </div>
                                <div>
                                    <h3 className="font-semibold text-gray-900">{selectedRecruiter.name}</h3>
                                    <p className="text-sm text-gray-500">{selectedRecruiter.company}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                <Button size="icon" variant="ghost">
                                    <Phone className="w-4 h-4" />
                                </Button>
                                <Button size="icon" variant="ghost">
                                    <Video className="w-4 h-4" />
                                </Button>
                                <Button size="icon" variant="ghost">
                                    <MoreHorizontal className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                            <AnimatePresence>
                                {messages.map((message) => (
                                    <motion.div
                                        key={message.id}
                                        initial={{ opacity: 0, y: 20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className={`flex ${message.isRecruiter ? 'justify-start' : 'justify-end'}`}
                                    >
                                        <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                            message.isRecruiter 
                                                ? 'bg-white text-gray-800' 
                                                : 'bg-blue-600 text-white'
                                        }`}>
                                            <p className="text-sm">{message.message}</p>
                                            <p className={`text-xs mt-1 ${
                                                message.isRecruiter ? 'text-gray-500' : 'text-blue-100'
                                            }`}>
                                                {new Date(message.timestamp).toLocaleTimeString([], { 
                                                    hour: '2-digit', 
                                                    minute: '2-digit' 
                                                })}
                                            </p>
                                        </div>
                                    </motion.div>
                                ))}
                            </AnimatePresence>
                        </div>

                        {/* Message Input */}
                        <div className="p-4 border-t bg-white">
                            <div className="flex gap-2">
                                <Input
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    placeholder="Type your message..."
                                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                    className="flex-1"
                                />
                                <Button 
                                    onClick={handleSendMessage}
                                    disabled={!newMessage.trim()}
                                    className="bg-purple-600 hover:bg-purple-700"
                                >
                                    <Send className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    </>
                ) : (
                    <div className="flex-1 flex items-center justify-center bg-gray-50">
                        <div className="text-center text-gray-500">
                            <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p className="text-lg font-medium">Select a recruiter to start chatting</p>
                            <p className="text-sm">Connect with hiring managers and explore opportunities</p>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}